import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ToastContainer from './components/ToastContainer';
import ProPaywallModal from './components/ProPaywallModal';
import CheckoutModal from './components/CheckoutModal';
import AuthModal from './components/AuthModal';

import HomePage from './pages/HomePage';
import WhyMemeMarketingPage from './pages/WhyMemeMarketingPage';
import BrandVaultPage from './pages/BrandVaultPage';
import MemeLibraryPage from './pages/MemeLibraryPage';
import CampaignBuilderPage from './pages/CampaignBuilderPage';
import PricingPage from './pages/PricingPage';
import AboutPage from './pages/AboutPage';
import DashboardPage from './pages/DashboardPage';
import { recordWebsiteVisit } from './utils/analyticsStorage';
import { recordRemoteVisit } from './utils/feedbackStorage';

function AppContent() {
  const [activePage, setActivePage] = useState('home');

  // Track one opening of the website per browser session for the live demo analytics.
  useEffect(() => {
    recordWebsiteVisit();
    recordRemoteVisit(window.location.hash || '#home');
  }, []);

  // Handle browser back/forward or hash changes if any
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '');
      if (hash && ['home', 'why-meme-marketing', 'brand-vault', 'meme-library', 'campaign-builder', 'pricing', 'about', 'dashboard'].includes(hash)) {
        setActivePage(hash);
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const changePage = (pageId) => {
    setActivePage(pageId);
    window.location.hash = pageId;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F9FA] text-[#111111]">
      {/* Sticky Header */}
      <Navbar activePage={activePage} setActivePage={changePage} />

      {/* Main Page Content */}
      <main className="flex-1">
        {activePage === 'home' && <HomePage setActivePage={changePage} />}
        {activePage === 'why-meme-marketing' && <WhyMemeMarketingPage setActivePage={changePage} />}
        {activePage === 'brand-vault' && <BrandVaultPage setActivePage={changePage} />}
        {activePage === 'meme-library' && <MemeLibraryPage setActivePage={changePage} />}
        {activePage === 'campaign-builder' && <CampaignBuilderPage setActivePage={changePage} />}
        {activePage === 'pricing' && <PricingPage setActivePage={changePage} />}
        {activePage === 'about' && <AboutPage setActivePage={changePage} />}
        {activePage === 'dashboard' && <DashboardPage setActivePage={changePage} />}
      </main>

      {/* Footer */}
      <Footer setActivePage={changePage} />

      {/* Global Modals & Notifications */}
      <ToastContainer />
      <ProPaywallModal />
      <CheckoutModal />
      <AuthModal onNavigateToDashboard={() => changePage('dashboard')} />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
