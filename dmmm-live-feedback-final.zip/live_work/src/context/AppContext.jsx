import React, { createContext, useContext, useState, useEffect } from 'react';
import { INITIAL_SAVED_CAMPAIGNS, generateCampaignData } from '../data/campaignTemplates';
import { recordSubscription } from '../utils/analyticsStorage';

const AppContext = createContext();

export function AppProvider({ children }) {
  // Authentication state
  const [user, setUser] = useState(() => {
    try {
      const stored = localStorage.getItem('meme_user');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  // Pro status state
  const [isPro, setIsPro] = useState(() => {
    try {
      return localStorage.getItem('meme_is_pro') === 'true';
    } catch {
      return false;
    }
  });

  // Saved campaigns state
  const [savedCampaigns, setSavedCampaigns] = useState(() => {
    try {
      const stored = localStorage.getItem('meme_saved_campaigns');
      return stored ? JSON.parse(stored) : INITIAL_SAVED_CAMPAIGNS;
    } catch {
      return INITIAL_SAVED_CAMPAIGNS;
    }
  });

  // Active / Last generated campaign
  const [currentCampaign, setCurrentCampaign] = useState(() => {
    try {
      const stored = localStorage.getItem('meme_current_campaign');
      return stored ? JSON.parse(stored) : INITIAL_SAVED_CAMPAIGNS[0];
    } catch {
      return INITIAL_SAVED_CAMPAIGNS[0];
    }
  });

  // Preselected format when navigating from Meme Library to Campaign Builder
  const [selectedFormatForBuilder, setSelectedFormatForBuilder] = useState(null);

  // Campaign Wizard Draft Form (persisted across navigation)
  const [wizardDraft, setWizardDraft] = useState(() => {
    try {
      const stored = localStorage.getItem('meme_wizard_draft');
      return stored ? JSON.parse(stored) : {
        product: 'Campus Fuel Energy Drink',
        objective: 'Engagement',
        audience: 'College Students',
        personality: 'Funny',
        platform: 'Instagram',
        format: 'POV',
        step: 1
      };
    } catch {
      return {
        product: 'Campus Fuel Energy Drink',
        objective: 'Engagement',
        audience: 'College Students',
        personality: 'Funny',
        platform: 'Instagram',
        format: 'POV',
        step: 1
      };
    }
  });

  // Modals state
  const [showProModal, setShowProModal] = useState(false);
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [authModal, setAuthModal] = useState({ isOpen: false, mode: 'login' });

  // Toast notifications state
  const [toasts, setToasts] = useState([]);

  // Persist wizard draft
  useEffect(() => {
    try {
      localStorage.setItem('meme_wizard_draft', JSON.stringify(wizardDraft));
    } catch (e) {
      console.error('Error saving wizard draft', e);
    }
  }, [wizardDraft]);

  // Persist saved campaigns
  useEffect(() => {
    try {
      localStorage.setItem('meme_saved_campaigns', JSON.stringify(savedCampaigns));
    } catch (e) {
      console.error('Error saving campaigns', e);
    }
  }, [savedCampaigns]);

  // Persist current campaign
  useEffect(() => {
    try {
      localStorage.setItem('meme_current_campaign', JSON.stringify(currentCampaign));
    } catch (e) {
      console.error('Error saving current campaign', e);
    }
  }, [currentCampaign]);

  // Persist pro status
  useEffect(() => {
    try {
      localStorage.setItem('meme_is_pro', isPro ? 'true' : 'false');
    } catch (e) {
      console.error('Error saving pro status', e);
    }
  }, [isPro]);

  // Persist user
  useEffect(() => {
    try {
      if (user) {
        localStorage.setItem('meme_user', JSON.stringify(user));
      } else {
        localStorage.removeItem('meme_user');
      }
    } catch (e) {
      console.error('Error saving user', e);
    }
  }, [user]);

  // Toast helper
  const addToast = (text, type = 'info') => {
    const id = Date.now() + Math.random().toString();
    setToasts(prev => [...prev, { id, text, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  const removeToast = (id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Auth functions
  const login = (email, password, name = 'Marketing Lead') => {
    const newUser = {
      id: 'usr_' + Date.now(),
      name: name || email.split('@')[0],
      email: email,
      createdAt: new Date().toISOString()
    };
    setUser(newUser);
    setAuthModal({ isOpen: false, mode: 'login' });
    addToast(`Welcome back, ${newUser.name}!`, 'success');
  };

  const signup = (name, email, password) => {
    const newUser = {
      id: 'usr_' + Date.now(),
      name: name || 'Marketing Strategist',
      email: email,
      createdAt: new Date().toISOString()
    };
    setUser(newUser);
    setAuthModal({ isOpen: false, mode: 'login' });
    addToast(`Account created! Welcome to MEMEVERTISING, ${newUser.name}.`, 'success');
  };

  const logout = () => {
    setUser(null);
    addToast('Logged out of session.', 'info');
  };

  // Pro functions
  const openProPaywall = () => {
    setShowProModal(true);
  };

  const closeProPaywall = () => {
    setShowProModal(false);
  };

  const openCheckout = () => {
    setShowProModal(false);
    setShowCheckoutModal(true);
  };

  const closeCheckout = () => {
    setShowCheckoutModal(false);
  };

  const unlockPro = () => {
    const alreadyPro = isPro;
    setIsPro(true);
    if (!alreadyPro) {
      recordSubscription(999);
    }
    setShowCheckoutModal(false);
    setShowProModal(false);
    addToast('🎉 MEMEVERTISING PRO Unlocked! All analytics & evaluation tools are now active.', 'success');
  };

  const toggleProForDemo = () => {
    const newStatus = !isPro;
    setIsPro(newStatus);
    addToast(newStatus ? '⭐ PRO features enabled for demo testing.' : 'Free mode active.', 'info');
  };

  // Campaign management
  const saveCampaign = (campaignToSave) => {
    const camp = campaignToSave || currentCampaign;
    setSavedCampaigns(prev => {
      const exists = prev.some(c => c.id === camp.id);
      if (exists) {
        return prev.map(c => c.id === camp.id ? { ...camp, updatedAt: new Date().toISOString() } : c);
      }
      return [camp, ...prev];
    });
    addToast('Campaign saved to your dashboard.', 'success');
  };

  const deleteCampaign = (id) => {
    setSavedCampaigns(prev => prev.filter(c => c.id !== id));
    addToast('Campaign removed from saved list.', 'info');
  };

  const selectFormatAndNavigateToBuilder = (formatName) => {
    setSelectedFormatForBuilder(formatName);
    setWizardDraft(prev => ({
      ...prev,
      format: formatName,
      step: 6 // Jump to format selection or step 1 with format set
    }));
    addToast(`Format "${formatName}" preselected for Campaign Builder.`, 'info');
  };

  return (
    <AppContext.Provider
      value={{
        user,
        isPro,
        savedCampaigns,
        currentCampaign,
        setCurrentCampaign,
        saveCampaign,
        deleteCampaign,
        selectedFormatForBuilder,
        setSelectedFormatForBuilder,
        selectFormatAndNavigateToBuilder,
        wizardDraft,
        setWizardDraft,
        showProModal,
        openProPaywall,
        closeProPaywall,
        showCheckoutModal,
        openCheckout,
        closeCheckout,
        unlockPro,
        toggleProForDemo,
        authModal,
        setAuthModal,
        login,
        signup,
        logout,
        toasts,
        addToast,
        removeToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
