const STORAGE_KEY = 'meme_site_analytics_v1';

const DEFAULT_ANALYTICS = {
  visits: 0,
  adClicks: 0,
  subscriptions: 0,
  monthlyRevenue: 0,
  lastVisitAt: null,
};

function read() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return { ...DEFAULT_ANALYTICS, ...parsed };
  } catch {
    return { ...DEFAULT_ANALYTICS };
  }
}

function write(data) {
  const next = { ...DEFAULT_ANALYTICS, ...data };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    window.dispatchEvent(new CustomEvent('meme_site_analytics_updated', { detail: next }));
  } catch (e) {
    console.error('Unable to save site analytics', e);
  }
  return next;
}

export function getSiteAnalytics() {
  return read();
}

// Count one website opening per browser session. sessionStorage prevents React StrictMode
// from counting the same opening twice while still counting a new session later.
export function recordWebsiteVisit() {
  try {
    if (sessionStorage.getItem('meme_visit_recorded_v1') === 'true') return read();
    sessionStorage.setItem('meme_visit_recorded_v1', 'true');
  } catch {
    // If sessionStorage is unavailable, count the visit normally.
  }

  const current = read();
  return write({
    ...current,
    visits: current.visits + 1,
    lastVisitAt: new Date().toISOString(),
  });
}

// A/B metrics are intentionally small at launch and grow with site activity.
// They are demo/operational counters, not third-party advertising-platform data.
export function getDynamicAbMetrics() {
  const { visits, subscriptions } = read();
  const safeVisits = Math.max(0, Number(visits) || 0);
  const safeSubscriptions = Math.max(0, Number(subscriptions) || 0);

  const versionAReach = 5 + safeVisits * 2;
  const versionBReach = 8 + safeVisits * 3;
  const versionAClicks = 1 + safeVisits;
  const versionBClicks = 2 + safeVisits * 2;

  const versionAConversions = Math.floor(versionAClicks * 0.08);
  const versionBConversions = Math.floor(versionBClicks * 0.12);

  const monthlyRevenue = safeSubscriptions * 999;

  return {
    visits: safeVisits,
    subscriptions: safeSubscriptions,
    versionAReach,
    versionBReach,
    versionAClicks,
    versionBClicks,
    versionAConversions,
    versionBConversions,
    monthlyRevenue,
  };
}

export function recordAdClick() {
  const current = read();
  return write({ ...current, adClicks: current.adClicks + 1 });
}

export function recordSubscription(price = 999) {
  const current = read();
  const subscriptions = current.subscriptions + 1;
  return write({
    ...current,
    subscriptions,
    monthlyRevenue: current.monthlyRevenue + Number(price || 999),
  });
}

export function resetSiteAnalytics() {
  return write({ ...DEFAULT_ANALYTICS });
}
