import { FEEDBACK_WEB_APP_URL } from './feedbackConfig';

const STORAGE_KEY = 'dmmm_feedback_responses_v3';
const VISITOR_KEY = 'dmmm_visitor_id_v1';
const SESSION_KEY = 'dmmm_session_id_v1';

export const QUESTIONS = [
  { id: 'purchaseInterest', label: 'Would this meme make you interested in the product?', options: ['Yes', 'Maybe', 'No'] },
  { id: 'memorability', label: 'How memorable is the meme?', options: ['Very memorable', 'Somewhat memorable', 'Not memorable'] },
  { id: 'brandFit', label: 'How well does the meme fit the brand?', options: ['Strong fit', 'Okay fit', 'Poor fit'] },
];

function idFor(key) {
  try {
    let value = localStorage.getItem(key);
    if (!value) { value = crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`; localStorage.setItem(key, value); }
    return value;
  } catch { return crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`; }
}

export function getResponses() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); }
  catch { return []; }
}

export function saveLocalResponse(response) {
  const responses = getResponses();
  const item = { ...response, id: crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`, createdAt: new Date().toISOString() };
  localStorage.setItem(STORAGE_KEY, JSON.stringify([item, ...responses]));
  return item;
}

function postToWebApp(payload) {
  if (!FEEDBACK_WEB_APP_URL) return Promise.resolve({ configured: false });
  return new Promise((resolve) => {
    const target = `dmmm_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const iframe = document.createElement('iframe');
    iframe.name = target; iframe.style.display = 'none';
    document.body.appendChild(iframe);
    const form = document.createElement('form');
    form.method = 'POST'; form.action = FEEDBACK_WEB_APP_URL; form.target = target; form.style.display = 'none';
    Object.entries(payload).forEach(([key, value]) => { const input = document.createElement('input'); input.name = key; input.value = value ?? ''; form.appendChild(input); });
    document.body.appendChild(form);
    form.submit();
    setTimeout(() => { form.remove(); iframe.remove(); resolve({ configured: true }); }, 900);
  });
}

export async function submitRemoteResponse(response) {
  return postToWebApp({ mode: 'feedback', ...response, createdAt: new Date().toISOString() });
}

export async function recordRemoteVisit(page = window.location.hash || '#home') {
  return postToWebApp({
    mode: 'visit',
    visitorId: idFor(VISITOR_KEY),
    sessionId: idFor(SESSION_KEY),
    page,
    referrer: document.referrer || '',
    createdAt: new Date().toISOString(),
  });
}

export async function getRemoteResponses() {
  if (!FEEDBACK_WEB_APP_URL) return { configured: false, responses: [] };
  return new Promise((resolve) => {
    const callback = `dmmmFeedback_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const script = document.createElement('script');
    const timeout = setTimeout(() => { cleanup(); resolve({ configured: true, responses: [], error: 'Timed out while loading responses.' }); }, 10000);
    const cleanup = () => { clearTimeout(timeout); delete window[callback]; script.remove(); };
    window[callback] = (data) => { cleanup(); resolve({ configured: true, responses: Array.isArray(data?.responses) ? data.responses : [] }); };
    script.src = `${FEEDBACK_WEB_APP_URL}?mode=responses&callback=${callback}`;
    script.onerror = () => { cleanup(); resolve({ configured: true, responses: [], error: 'Could not connect to the feedback database.' }); };
    document.body.appendChild(script);
  });
}

export async function getRemoteVisits() {
  if (!FEEDBACK_WEB_APP_URL) return { configured: false, visits: [] };
  return new Promise((resolve) => {
    const callback = `dmmmVisits_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const script = document.createElement('script');
    const timeout = setTimeout(() => { cleanup(); resolve({ configured: true, visits: [], error: 'Timed out while loading visits.' }); }, 10000);
    const cleanup = () => { clearTimeout(timeout); delete window[callback]; script.remove(); };
    window[callback] = (data) => { cleanup(); resolve({ configured: true, visits: Array.isArray(data?.visits) ? data.visits : [] }); };
    script.src = `${FEEDBACK_WEB_APP_URL}?mode=visits&callback=${callback}`;
    script.onerror = () => { cleanup(); resolve({ configured: true, visits: [], error: 'Could not connect to visitor database.' }); };
    document.body.appendChild(script);
  });
}

export function clearResponses() { localStorage.removeItem(STORAGE_KEY); }

export function exportResponses(responses = getResponses()) {
  const blob = new Blob([JSON.stringify(responses, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'dmmm-feedback-responses.json'; a.click(); URL.revokeObjectURL(url);
}
