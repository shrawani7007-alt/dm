// Paste your deployed Google Apps Script Web App URL here.
// Example: https://script.google.com/macros/s/XXXXXXXX/exec
export const FEEDBACK_WEB_APP_URL = '';
export const FEEDBACK_OWNER_EMAIL = 'sleepinghippo777@gmail.com';
