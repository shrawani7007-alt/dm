// Web Audio API Sound Synthesizer & Meme FX Engine
// Generates authentic beats, sound effects, and dance rhythms client-side without external dependencies.

class MemeAudioEngine {
  constructor() {
    this.ctx = null;
    this.isPlaying = false;
    this.currentTrackId = null;
    this.activeNodes = [];
    this.intervalId = null;
  }

  init() {
    if (!this.ctx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioContext();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  stop() {
    this.isPlaying = false;
    this.currentTrackId = null;
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.activeNodes.forEach(node => {
      try {
        if (node.stop) node.stop();
        if (node.disconnect) node.disconnect();
      } catch (e) {
        // Node might have already finished
      }
    });
    this.activeNodes = [];
    window.dispatchEvent(new CustomEvent('meme_audio_state_change', {
      detail: { isPlaying: false, trackId: null }
    }));
  }

  // Play a specific sound effect or dance beat
  play(trackId) {
    this.init();
    this.stop(); // Stop any currently playing audio

    this.isPlaying = true;
    this.currentTrackId = trackId;

    window.dispatchEvent(new CustomEvent('meme_audio_state_change', {
      detail: { isPlaying: true, trackId }
    }));

    switch (trackId) {
      case 'brazilian-phonk':
        this.playBrazilianPhonk();
        break;
      case 'fahhhh-scream':
        this.playFahhhh();
        break;
      case 'scuba-dance':
        this.playScubaDance();
        break;
      case 'gucci-ravi-kishan':
        this.playGucciRaviKishan();
        break;
      case 'phir-hera-pheri':
        this.playPhirHeraPheri();
        break;
      case 'chin-tapak-dum-dum':
        this.playChinTapakDumDum();
        break;
      case 'piche-to-dekho':
        this.playPicheToDekho();
        break;
      case 'wah-shampy-wah':
        this.playWahShampyWah();
        break;
      case 'skibidi-toilet':
        this.playSkibidiToilet();
        break;
      case 'six-seven-trend':
        this.playSixSevenTrend();
        break;
      case 'drake-hotline':
        this.playDrakeHotline();
        break;
      case 'kinda-chic':
        this.playKindaChic();
        break;
      default:
        this.playBrazilianPhonk();
        break;
    }
  }

  // 1. BRAZILIAN PHONK (142 BPM Distorted Cowbells + Heavy 808 Bass Slide)
  playBrazilianPhonk() {
    const tempo = 60 / 142; // seconds per beat
    let step = 0;
    const cowbellNotes = [587.33, 587.33, 659.25, 587.33, 523.25, 493.88, 523.25, 440.00];

    const playLoop = () => {
      if (!this.isPlaying) return;
      const now = this.ctx.currentTime;

      // Heavy 808 Kick
      if (step % 2 === 0) {
        const kickOsc = this.ctx.createOscillator();
        const kickGain = this.ctx.createGain();
        kickOsc.type = 'triangle';
        kickOsc.frequency.setValueAtTime(140, now);
        kickOsc.frequency.exponentialRampToValueAtTime(38, now + 0.28);
        kickGain.gain.setValueAtTime(0.7, now);
        kickGain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);

        kickOsc.connect(kickGain);
        kickGain.connect(this.ctx.destination);
        kickOsc.start(now);
        kickOsc.stop(now + 0.35);
        this.activeNodes.push(kickOsc);
      }

      // Distorted Phonk Cowbell
      const noteFreq = cowbellNotes[step % cowbellNotes.length];
      const cowOsc1 = this.ctx.createOscillator();
      const cowOsc2 = this.ctx.createOscillator();
      const cowGain = this.ctx.createGain();

      cowOsc1.type = 'square';
      cowOsc1.frequency.setValueAtTime(noteFreq, now);
      cowOsc2.type = 'sawtooth';
      cowOsc2.frequency.setValueAtTime(noteFreq * 1.5, now);

      cowGain.gain.setValueAtTime(0.22, now);
      cowGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

      cowOsc1.connect(cowGain);
      cowOsc2.connect(cowGain);
      cowGain.connect(this.ctx.destination);

      cowOsc1.start(now);
      cowOsc2.start(now);
      cowOsc1.stop(now + 0.18);
      cowOsc2.stop(now + 0.18);

      step++;
    };

    playLoop();
    this.intervalId = setInterval(playLoop, (tempo / 2) * 1000);
  }

  // 2. FAHHHH! (Iconic reverb impact brass & vocal punch)
  playFahhhh() {
    const now = this.ctx.currentTime;

    // Brass Saw Chord
    const freqs = [110, 164.81, 220, 329.63];
    freqs.forEach(f => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, now);
      osc.frequency.exponentialRampToValueAtTime(f * 0.85, now + 1.2);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(3000, now);
      filter.frequency.exponentialRampToValueAtTime(400, now + 1.5);

      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 1.6);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 1.6);
      this.activeNodes.push(osc);
    });

    // Sub Boom
    const boom = this.ctx.createOscillator();
    const boomGain = this.ctx.createGain();
    boom.type = 'sine';
    boom.frequency.setValueAtTime(90, now);
    boom.frequency.exponentialRampToValueAtTime(25, now + 1.4);
    boomGain.gain.setValueAtTime(0.6, now);
    boomGain.gain.exponentialRampToValueAtTime(0.01, now + 1.5);

    boom.connect(boomGain);
    boomGain.connect(this.ctx.destination);
    boom.start(now);
    boom.stop(now + 1.5);

    setTimeout(() => this.stop(), 1800);
  }

  // 3. SCUBA DANCE (Bouncy Underwater Bubble House Beat)
  playScubaDance() {
    const tempo = 60 / 124;
    let step = 0;
    const bassline = [65.41, 73.42, 82.41, 65.41, 98.00, 87.31];

    const playLoop = () => {
      if (!this.isPlaying) return;
      const now = this.ctx.currentTime;

      // Submerged deep round bass
      const bFreq = bassline[step % bassline.length];
      const bassOsc = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();
      const bGain = this.ctx.createGain();

      bassOsc.type = 'sine';
      bassOsc.frequency.setValueAtTime(bFreq, now);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(450, now);
      filter.Q.value = 4;

      bGain.gain.setValueAtTime(0.4, now);
      bGain.gain.exponentialRampToValueAtTime(0.01, now + 0.28);

      bassOsc.connect(filter);
      filter.connect(bGain);
      bGain.connect(this.ctx.destination);
      bassOsc.start(now);
      bassOsc.stop(now + 0.28);

      // Bubble pop effect on offbeat
      if (step % 2 === 1) {
        const bubble = this.ctx.createOscillator();
        const bubGain = this.ctx.createGain();
        bubble.type = 'sine';
        bubble.frequency.setValueAtTime(400 + Math.random() * 300, now);
        bubble.frequency.exponentialRampToValueAtTime(1200 + Math.random() * 400, now + 0.12);

        bubGain.gain.setValueAtTime(0.2, now);
        bubGain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);

        bubble.connect(bubGain);
        bubGain.connect(this.ctx.destination);
        bubble.start(now);
        bubble.stop(now + 0.14);
      }

      step++;
    };

    playLoop();
    this.intervalId = setInterval(playLoop, (tempo / 2) * 1000);
  }

  // 4. GUCCI DANCE BY RAVI KISHAN (Bhojpuri Electro Dholak + Celebratory Lead)
  playGucciRaviKishan() {
    const tempo = 60 / 135;
    let step = 0;
    const leadNotes = [523.25, 587.33, 659.25, 783.99, 659.25, 587.33, 523.25, 440.00];

    const playLoop = () => {
      if (!this.isPlaying) return;
      const now = this.ctx.currentTime;

      // Dhol thump (Base percussion)
      const dhol = this.ctx.createOscillator();
      const dholGain = this.ctx.createGain();
      dhol.type = 'sine';
      dhol.frequency.setValueAtTime(160, now);
      dhol.frequency.exponentialRampToValueAtTime(45, now + 0.18);
      dholGain.gain.setValueAtTime(0.55, now);
      dholGain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);

      dhol.connect(dholGain);
      dholGain.connect(this.ctx.destination);
      dhol.start(now);
      dhol.stop(now + 0.2);

      // Desi Electro Synth Lead
      const lFreq = leadNotes[step % leadNotes.length];
      const leadOsc = this.ctx.createOscillator();
      const leadGain = this.ctx.createGain();
      leadOsc.type = 'sawtooth';
      leadOsc.frequency.setValueAtTime(lFreq, now);

      leadGain.gain.setValueAtTime(0.18, now);
      leadGain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);

      leadOsc.connect(leadGain);
      leadGain.connect(this.ctx.destination);
      leadOsc.start(now);
      leadOsc.stop(now + 0.15);

      step++;
    };

    playLoop();
    this.intervalId = setInterval(playLoop, (tempo / 2) * 1000);
  }

  // 5. PHIR HERA PHERI (Ka-ching cash register + Babu Rao scheme suspense)
  playPhirHeraPheri() {
    const now = this.ctx.currentTime;

    // Cash Register "Ka-Ching!" Chimes
    const chime1 = this.ctx.createOscillator();
    const chime2 = this.ctx.createOscillator();
    const cGain = this.ctx.createGain();

    chime1.type = 'sine';
    chime1.frequency.setValueAtTime(987.77, now); // B5
    chime1.frequency.setValueAtTime(1318.51, now + 0.08); // E6

    chime2.type = 'triangle';
    chime2.frequency.setValueAtTime(1975.53, now + 0.08);

    cGain.gain.setValueAtTime(0.35, now);
    cGain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);

    chime1.connect(cGain);
    chime2.connect(cGain);
    cGain.connect(this.ctx.destination);

    chime1.start(now);
    chime2.start(now);
    chime1.stop(now + 0.8);
    chime2.stop(now + 0.8);

    // Comedy Hera Pheri Bassline Loop
    const tempo = 60 / 120;
    let step = 0;
    const heraNotes = [130.81, 146.83, 164.81, 174.61, 196.00, 164.81];

    const playLoop = () => {
      if (!this.isPlaying) return;
      const t = this.ctx.currentTime;
      const hOsc = this.ctx.createOscillator();
      const hGain = this.ctx.createGain();
      hOsc.type = 'triangle';
      hOsc.frequency.setValueAtTime(heraNotes[step % heraNotes.length], t);

      hGain.gain.setValueAtTime(0.3, t);
      hGain.gain.exponentialRampToValueAtTime(0.01, t + 0.2);

      hOsc.connect(hGain);
      hGain.connect(this.ctx.destination);
      hOsc.start(t);
      hOsc.stop(t + 0.2);
      step++;
    };

    setTimeout(() => {
      if (this.isPlaying) {
        this.intervalId = setInterval(playLoop, (tempo / 2) * 1000);
      }
    }, 250);
  }

  // 6. CHIN TAPAK DUM DUM (Magic Chime + Punchy Dum Dum Dhol Percussion)
  playChinTapakDumDum() {
    const now = this.ctx.currentTime;

    // Magical Chime Glissando
    const chimes = [523.25, 659.25, 783.99, 1046.50, 1318.51];
    chimes.forEach((f, i) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, now + i * 0.06);
      gain.gain.setValueAtTime(0.25, now + i * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.06 + 0.4);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now + i * 0.06);
      osc.stop(now + i * 0.06 + 0.4);
    });

    // Dum - Dum deep punch percussion hits
    const playDum = (delayTime, pitch) => {
      const dNow = now + delayTime;
      const dOsc = this.ctx.createOscillator();
      const dGain = this.ctx.createGain();
      dOsc.type = 'sine';
      dOsc.frequency.setValueAtTime(pitch, dNow);
      dOsc.frequency.exponentialRampToValueAtTime(42, dNow + 0.22);
      dGain.gain.setValueAtTime(0.5, dNow);
      dGain.gain.exponentialRampToValueAtTime(0.01, dNow + 0.25);

      dOsc.connect(dGain);
      dGain.connect(this.ctx.destination);
      dOsc.start(dNow);
      dOsc.stop(dNow + 0.25);
    };

    playDum(0.45, 170); // "Chin"
    playDum(0.70, 160); // "Tapak"
    playDum(0.95, 200); // "Dum"
    playDum(1.20, 190); // "Dum!"

    // Auto-loop the groove
    setTimeout(() => {
      if (this.isPlaying) {
        this.playChinTapakDumDum();
      }
    }, 1800);
  }

  // 7. PICHE TO DEKHO (Cheeky Voice Pitch Hook & Whoosh)
  playPicheToDekho() {
    const now = this.ctx.currentTime;

    // Playful vocal formant-like whistle
    const vocalPitches = [440, 554.37, 659.25, 554.37, 880];
    vocalPitches.forEach((p, idx) => {
      const vOsc = this.ctx.createOscillator();
      const vGain = this.ctx.createGain();
      vOsc.type = 'triangle';
      vOsc.frequency.setValueAtTime(p, now + idx * 0.12);
      vGain.gain.setValueAtTime(0.28, now + idx * 0.12);
      vGain.gain.exponentialRampToValueAtTime(0.01, now + idx * 0.12 + 0.16);

      vOsc.connect(vGain);
      vGain.connect(this.ctx.destination);
      vOsc.start(now + idx * 0.12);
      vOsc.stop(now + idx * 0.12 + 0.16);
    });

    // Swift Whoosh sound
    const noiseBuffer = this.ctx.createBuffer(1, this.ctx.sampleRate * 0.35, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < noiseBuffer.length; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = this.ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(500, now + 0.6);
    filter.frequency.exponentialRampToValueAtTime(3500, now + 0.9);

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(0.2, now + 0.6);
    noiseGain.gain.exponentialRampToValueAtTime(0.01, now + 0.95);

    whiteNoise.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(this.ctx.destination);
    whiteNoise.start(now + 0.6);

    setTimeout(() => {
      if (this.isPlaying) {
        this.playPicheToDekho();
      }
    }, 1600);
  }

  // 8. WAH SHAMPY WAH (Dhol Celebration & Confetti Cheer)
  playWahShampyWah() {
    const tempo = 60 / 130;
    let step = 0;

    const playLoop = () => {
      if (!this.isPlaying) return;
      const now = this.ctx.currentTime;

      // Heavy Bhangra Dhol roll
      const dhol = this.ctx.createOscillator();
      const dGain = this.ctx.createGain();
      dhol.type = 'triangle';
      dhol.frequency.setValueAtTime(step % 3 === 0 ? 190 : 120, now);
      dhol.frequency.exponentialRampToValueAtTime(50, now + 0.16);
      dGain.gain.setValueAtTime(0.45, now);
      dGain.gain.exponentialRampToValueAtTime(0.01, now + 0.18);

      dhol.connect(dGain);
      dGain.connect(this.ctx.destination);
      dhol.start(now);
      dhol.stop(now + 0.18);

      // High snap
      const snap = this.ctx.createOscillator();
      const sGain = this.ctx.createGain();
      snap.type = 'sine';
      snap.frequency.setValueAtTime(1400, now + 0.08);
      sGain.gain.setValueAtTime(0.18, now + 0.08);
      sGain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
      snap.connect(sGain);
      sGain.connect(this.ctx.destination);
      snap.start(now + 0.08);
      snap.stop(now + 0.16);

      step++;
    };

    playLoop();
    this.intervalId = setInterval(playLoop, (tempo / 2) * 1000);
  }

  // 9. SKIBIDI TOILET (Hyper-speed bop bop bounce)
  playSkibidiToilet() {
    const tempo = 60 / 136;
    let step = 0;
    const bopPitches = [180, 220, 260, 220, 300, 360, 280, 200];

    const playLoop = () => {
      if (!this.isPlaying) return;
      const now = this.ctx.currentTime;

      const p = bopPitches[step % bopPitches.length];
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(p, now);
      osc.frequency.exponentialRampToValueAtTime(p * 0.7, now + 0.1);

      gain.gain.setValueAtTime(0.28, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.11);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.11);

      step++;
    };

    playLoop();
    this.intervalId = setInterval(playLoop, (tempo / 2) * 1000);
  }

  // 10. 6-7 NUMBER VIRAL SYNTH
  playSixSevenTrend() {
    const now = this.ctx.currentTime;
    const chords = [261.63, 329.63, 392.00, 523.25]; // C Major 7th
    chords.forEach((c) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(c, now);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 1.2);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 1.2);
    });

    setTimeout(() => {
      if (this.isPlaying) {
        this.playSixSevenTrend();
      }
    }, 1400);
  }

  // 11. DRAKE HOTLINE
  playDrakeHotline() {
    const tempo = 60 / 100;
    let step = 0;

    const playLoop = () => {
      if (!this.isPlaying) return;
      const now = this.ctx.currentTime;

      // 808 Warm Kick
      if (step % 2 === 0) {
        const k = this.ctx.createOscillator();
        const kg = this.ctx.createGain();
        k.type = 'sine';
        k.frequency.setValueAtTime(110, now);
        k.frequency.exponentialRampToValueAtTime(32, now + 0.28);
        kg.gain.setValueAtTime(0.5, now);
        kg.gain.exponentialRampToValueAtTime(0.01, now + 0.3);

        k.connect(kg);
        kg.connect(this.ctx.destination);
        k.start(now);
        k.stop(now + 0.3);
      }

      // Smooth Snap
      if (step % 2 === 1) {
        const s = this.ctx.createOscillator();
        const sg = this.ctx.createGain();
        s.type = 'triangle';
        s.frequency.setValueAtTime(1200, now);
        sg.gain.setValueAtTime(0.18, now);
        sg.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

        s.connect(sg);
        sg.connect(this.ctx.destination);
        s.start(now);
        s.stop(now + 0.08);
      }

      step++;
    };

    playLoop();
    this.intervalId = setInterval(playLoop, (tempo / 2) * 1000);
  }

  // 12. KINDA CHIC (Lofi Demure Harp)
  playKindaChic() {
    const now = this.ctx.currentTime;
    const harpNotes = [440.00, 554.37, 659.25, 830.61, 987.77];
    harpNotes.forEach((n, idx) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(n, now + idx * 0.15);
      gain.gain.setValueAtTime(0.2, now + idx * 0.15);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.15 + 0.6);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now + idx * 0.15);
      osc.stop(now + idx * 0.15 + 0.6);
    });

    setTimeout(() => {
      if (this.isPlaying) {
        this.playKindaChic();
      }
    }, 2000);
  }
}

export const memeAudio = new MemeAudioEngine();
