// Persistent Cross-Client Interaction & Brand Popularity Storage Engine
// Stores real cumulative Likes, Comments, Views, and Shares in localStorage
// Broadcasts updates instantly across browser tabs & windows via BroadcastChannel and Storage Events
// Calculates dynamic Brand Popularity scores so customers can view verified popularity in real time.

const STORAGE_KEY = 'meme_actual_interactions_v4';
const BRAND_STATS_KEY = 'meme_brand_popularity_v2';

// Seed base interactions for realistic live baseline counts
const INITIAL_CAMPAIGN_INTERACTIONS = {
  // Campaign 1: Campus Fuel (Energy Drink x Demure / Brazilian Phonk)
  camp_demo_01: {
    brandId: 'brand_campus_fuel',
    brandName: 'Campus Fuel Energy',
    posterUrl: '/posters/ad_poster_campus_fuel.jpg',
    views: 24890,
    likes: 12,
    shares: 6,
    likedByMe: false,
    savedByMe: false,
    comments: []
  },

  // Campaign 2: Hera Invest (Phir Hera Pheri x Fintech)
  camp_hera_pheri: {
    brandId: 'brand_hera_invest',
    brandName: 'Hera Invest Fintech',
    posterUrl: '/posters/ad_poster_phir_hera_pheri.jpg',
    views: 38420,
    likes: 8,
    shares: 3,
    likedByMe: false,
    savedByMe: false,
    comments: []
  },

  // Campaign 3: Swagwar Apparel (Ravi Kishan Gucci Dance x Streetwear)
  camp_ravi_kishan: {
    brandId: 'brand_swagwar',
    brandName: 'Swagwar Apparel',
    posterUrl: '/posters/ad_poster_ravi_kishan_gucci.jpg',
    views: 31750,
    likes: 17,
    shares: 8,
    likedByMe: false,
    savedByMe: false,
    comments: []
  },

  // Campaign 4: Chin Tapak Dum Dum (Quick Commerce)
  camp_chin_tapak: {
    brandId: 'brand_instant_dum',
    brandName: 'DumDum Delivery',
    posterUrl: '/posters/ad_poster_campus_fuel.jpg',
    views: 29100,
    likes: 5,
    shares: 5,
    likedByMe: false,
    savedByMe: false,
    comments: []
  }
};

// AI-generated social-proof baseline data.
// This is simulated engagement for the demo UI, not scraped from real users or live platforms.
const AI_MIN_COUNT = 0;
const AI_MAX_LIKES = 19;
const AI_MAX_SHARES = 9;

const AI_BASELINE_STATS = {
  camp_demo_01: { views: 24890, likes: 12, shares: 6 },
  camp_hera_pheri: { views: 38420, likes: 8, shares: 3 },
  camp_ravi_kishan: { views: 31750, likes: 17, shares: 8 },
  camp_chin_tapak: { views: 29100, likes: 5, shares: 5 }
};

function normalizeInteractionRecord(campaignId, record = {}) {
  const baseline = AI_BASELINE_STATS[campaignId] || { views: 1420, likes: 9, shares: 4 };
  return {
    ...record,
    views: Math.max(0, Number(record.views) || 0, baseline.views),
    likes: Math.min(AI_MAX_LIKES, Math.max(0, Number(record.likes) || 0, baseline.likes)),
    shares: Math.min(AI_MAX_SHARES, Math.max(0, Number(record.shares) || 0, baseline.shares)),
    comments: Array.isArray(record.comments) ? record.comments : []
  };
}

// Cross-tab broadcast channel
let broadcastChannel = null;
try {
  if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
    broadcastChannel = new BroadcastChannel('meme_social_proof_channel');
    broadcastChannel.onmessage = (event) => {
      if (event.data && event.data.type === 'SYNC_INTERACTIONS') {
        window.dispatchEvent(new CustomEvent('meme_interactions_updated', { detail: event.data.payload }));
      }
    };
  }
} catch (e) {
  console.warn('BroadcastChannel not supported or restricted', e);
}

// Storage listener fallback for other windows/tabs
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key === STORAGE_KEY && e.newValue) {
      try {
        const parsed = JSON.parse(e.newValue);
        window.dispatchEvent(new CustomEvent('meme_interactions_updated', { detail: parsed }));
      } catch (err) {
        // ignore json parse errors
      }
    }
  });
}

export function getAllCampaignInteractions() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const seeded = Object.fromEntries(
        Object.entries(INITIAL_CAMPAIGN_INTERACTIONS).map(([id, record]) => [id, normalizeInteractionRecord(id, record)])
      );
      localStorage.setItem(STORAGE_KEY, JSON.stringify(seeded));
      return seeded;
    }
    const parsed = JSON.parse(raw);
    const normalized = Object.fromEntries(
      Object.entries(parsed).map(([id, record]) => [id, normalizeInteractionRecord(id, record)])
    );
    localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
    return normalized;
  } catch (e) {
    console.error('Error reading interactions from storage', e);
    return { ...INITIAL_CAMPAIGN_INTERACTIONS };
  }
}

export function saveAllCampaignInteractions(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    
    // Broadcast to other open browser tabs
    if (broadcastChannel) {
      broadcastChannel.postMessage({ type: 'SYNC_INTERACTIONS', payload: data });
    }
    
    // Dispatch in current window
    window.dispatchEvent(new CustomEvent('meme_interactions_updated', { detail: data }));
  } catch (e) {
    console.error('Error saving interactions to storage', e);
  }
}

export function getCampaignInteractions(campaignId) {
  const all = getAllCampaignInteractions();
  const id = campaignId || 'camp_demo_01';
  
  if (!all[id]) {
    // Generate fresh organic record for custom generated campaigns
    all[id] = normalizeInteractionRecord(id, {
      brandId: 'brand_' + id,
      brandName: 'Custom Meme Ad',
      views: 1420,
      likes: 9,
      shares: 4,
      likedByMe: false,
      savedByMe: false,
      comments: []
    });
    saveAllCampaignInteractions(all);
  }
  return all[id];
}

// Increment view count whenever the ad/poster is opened
export function recordActualView(campaignId) {
  const all = getAllCampaignInteractions();
  const id = campaignId || 'camp_demo_01';
  const current = all[id] || getCampaignInteractions(id);
  current.views = (current.views || 0) + 1;
  all[id] = current;
  saveAllCampaignInteractions(all);
  return current;
}

// Toggle like and update cumulative likes across all customers
export function toggleActualLike(campaignId) {
  const all = getAllCampaignInteractions();
  const id = campaignId || 'camp_demo_01';
  const current = all[id] || getCampaignInteractions(id);
  
  if (current.likedByMe) {
    current.likedByMe = false;
    current.likes = Math.max(0, (current.likes || 0) - 1);
  } else {
    current.likedByMe = true;
    current.likes = Math.min(AI_MAX_LIKES, (current.likes || 0) + 1);
  }

  all[id] = current;
  saveAllCampaignInteractions(all);
  return current;
}

// Toggle bookmark/save
export function toggleActualSave(campaignId) {
  const all = getAllCampaignInteractions();
  const id = campaignId || 'camp_demo_01';
  const current = all[id] || getCampaignInteractions(id);
  current.savedByMe = !current.savedByMe;
  all[id] = current;
  saveAllCampaignInteractions(all);
  return current;
}

// Store a real user-entered comment locally. No generated comments are added.
export function addActualComment(campaignId, text, author = 'You') {
  const cleanText = String(text || '').trim();
  if (!cleanText) return getCampaignInteractions(campaignId);

  const all = getAllCampaignInteractions();
  const id = campaignId || 'camp_demo_01';
  const current = all[id] || getCampaignInteractions(id);
  const comment = {
    id: `comment_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    author: author || 'You',
    text: cleanText,
    createdAt: new Date().toISOString()
  };

  current.comments = Array.isArray(current.comments) ? [...current.comments, comment] : [comment];
  all[id] = current;
  saveAllCampaignInteractions(all);
  return current;
}

// Record a share in the local demo dataset
export function recordActualShare(campaignId, platform = 'link') {
  const all = getAllCampaignInteractions();
  const id = campaignId || 'camp_demo_01';
  const current = all[id] || getCampaignInteractions(id);
  current.shares = Math.min(AI_MAX_SHARES, (current.shares || 0) + 1);
  all[id] = current;
  saveAllCampaignInteractions(all);
  return current;
}

// Get dynamic Brand Popularity Leaderboard calculated from the local AI-generated demo dataset
export function getBrandPopularityLeaderboard() {
  const all = getAllCampaignInteractions();
  const brands = [
    {
      id: 'camp_hera_pheri',
      brand: 'Hera Invest',
      industry: 'Fintech & Wealth',
      product: 'Titanium Wealth Card & High-Yield App',
      memeHook: 'Phir Hera Pheri (21 Din Me Paisa Double)',
      badge: '🏆 #1 Top Trending',
      posterImage: '/posters/ad_poster_phir_hera_pheri.jpg',
      headline: 'No 21-Din Schemes. Real Compounding ROI.',
      stamp: 'BABU RAO APPROVED • 100% TRANSPARENT',
      interactions: all['camp_hera_pheri'] || getCampaignInteractions('camp_hera_pheri')
    },
    {
      id: 'camp_demo_01',
      brand: 'Campus Fuel',
      industry: 'Energy & Beverage',
      product: 'Ultra-Neon Clean Energy Drink',
      memeHook: 'Very Demure / Brazilian Phonk Beat',
      badge: '⚡ High Virality',
      posterImage: '/posters/ad_poster_campus_fuel.jpg',
      headline: 'Unstoppable Focus • Zero 8 AM Crash',
      stamp: 'VERY DEMURE, KINDA ENERGIZED',
      interactions: all['camp_demo_01'] || getCampaignInteractions('camp_demo_01')
    },
    {
      id: 'camp_ravi_kishan',
      brand: 'Swagwar Apparel',
      industry: 'Streetwear & Kicks',
      product: 'Metallic Neon Street High-Tops',
      memeHook: 'Ravi Kishan Gucci Dance Swagger',
      badge: '🕺 Desi Pop Icon',
      posterImage: '/posters/ad_poster_ravi_kishan_gucci.jpg',
      headline: 'Zindagi Jhandwa, Style Ghamandwa',
      stamp: 'GUCCI STEP READY • 100% DESI SWAGGER',
      interactions: all['camp_ravi_kishan'] || getCampaignInteractions('camp_ravi_kishan')
    },
    {
      id: 'camp_chin_tapak',
      brand: 'DumDum Delivery',
      industry: 'Quick Commerce',
      product: '10-Minute Craving Delivery',
      memeHook: 'Chin Tapak Dum Dum Magic',
      badge: '🪄 Viral Audio King',
      posterImage: '/posters/ad_poster_campus_fuel.jpg',
      headline: 'Solve Midnight Cravings: Chin Tapak Dum Dum',
      stamp: 'INSTANT 10-MIN RESOLUTION',
      interactions: all['camp_chin_tapak'] || getCampaignInteractions('camp_chin_tapak')
    }
  ];

  // Calculate composite popularity score = (Likes * 4) + (Comments * 8) + (Shares * 5) + (Views * 0.05)
  return brands.map(b => {
    const l = b.interactions.likes || 0;
    const c = (b.interactions.comments || []).length;
    const s = b.interactions.shares || 0;
    const v = b.interactions.views || 0;
    const popularityScore = Math.round(l * 4 + c * 8 + s * 5 + v * 0.05);

    return {
      ...b,
      popularityScore,
      likesCount: l,
      commentsCount: c,
      sharesCount: s,
      viewsCount: v
    };
  }).sort((a, b) => b.popularityScore - a.popularityScore);
}
