// Brand Vault case studies — Educational summaries based on real-world marketing patterns
// Important: No fabricated campaign performance metrics; purely strategic & educational analysis

export const CASE_STUDIES = [
  {
    id: 'zomato',
    brand: 'Zomato',
    industry: 'Food',
    targetAudience: 'Urban Millennials & Gen Z Foodies',
    marketingObjective: 'Engagement & Top-of-Mind Recall',
    marketingStyle: 'Relatable',
    tagline: 'When the stomach speaks louder than self-control',
    accentColor: '#E23744',
    badge: 'Food Delivery Legend',
    approach: 'Zomato masters situational humor around late-night cravings, office hunger, diet failures, and weekend food binging. Rather than shouting discounts, they turn everyday hunger dilemmas into cultural conversation starters.',
    keyLesson: 'Make the product part of the joke, not an afterthought.',
    examples: [
      '“You said no junk food from Monday. Good thing today is Friday.”',
      'Push notification at 11:42 PM: “Biryani doesn’t ask silly questions. Biryani understands.”',
      'Billboards with two simple sentences reflecting internal monologue vs hunger reality.'
    ],
    dos: [
      'Leverage micro-moments like salary day or rain cravings',
      'Keep visual layout ultra-minimal so the copy punches hard',
      'Integrate the ordering action as the punchline resolution'
    ],
    donts: [
      'Do not force corporate jargon into informal food banter',
      'Do not interrupt urgent hunger distress with complex jokes'
    ]
  },
  {
    id: 'duolingo',
    brand: 'Duolingo',
    industry: 'Education',
    targetAudience: 'Digital Natives & Language Learners',
    marketingObjective: 'Brand Awareness & App Re-engagement',
    marketingStyle: 'Chaotic',
    tagline: 'The guilt-trip green owl you can never escape',
    accentColor: '#58CC02',
    badge: 'Chaotic Mascot Masterclass',
    approach: 'Duolingo weaponized their infamous push notifications by personifying Duo the Owl on TikTok and Instagram as an obsessive, slightly unhinged mascot who stalks users until they do their Spanish lesson.',
    keyLesson: 'Lean fearlessly into community memes about your own brand quirks.',
    examples: [
      'Duo the Owl showing up outside someone’s window holding a flashcard',
      'Duo crying to pop songs because someone lost their 42-day streak',
      'TikTok comments roasting celebrities with passive-aggressive language lessons'
    ],
    dos: [
      'Empower a mascot or character to speak with unapologetic edge',
      'Acknowledge user pain points (e.g. guilt over forgotten streaks) with humor',
      'Engage dynamically in comment sections within minutes of trending pop events'
    ],
    donts: [
      'Do not sanitize chaotic humor with corporate PR approvals',
      'Do not forget to remind users what the actual core product does'
    ]
  },
  {
    id: 'netflix',
    brand: 'Netflix',
    industry: 'Entertainment',
    targetAudience: 'Streaming Enthusiasts & Pop Culture Junkies',
    marketingObjective: 'Audience Retention & Show Discovery',
    marketingStyle: 'Topical',
    tagline: 'Screen-grabbing moments into instant viral templates',
    accentColor: '#E50914',
    badge: 'Content-Native Virality',
    approach: 'Netflix treats their vast content catalog as an infinite meme sandbox. Instead of running generic trailers, their social team clips micro-expressions and relatable character dilemmas to comment on everyday adult life.',
    keyLesson: 'Your own product assets are the strongest source of authentic memes.',
    examples: [
      'Freeze-frame of a character staring blankly: “Me agreeing to plans I have no intention of attending”',
      'Comparing season 1 innocence to season 4 exhaustion as Monday morning metaphors',
      'Subtitled screenshot mashups creating alternate comedic storylines'
    ],
    dos: [
      'Repurpose existing high-res footage into recognizable relatable formats',
      'Time drops with premiere weekends when audience excitement is peak',
      'Tag actors and encourage conversational fan-theory threads'
    ],
    donts: [
      'Do not spoil crucial plot turns just for a quick cheap laugh',
      'Do not hijack dark tragic scenes for frivolous retail sales'
    ]
  },
  {
    id: 'spotify',
    brand: 'Spotify',
    industry: 'Tech',
    targetAudience: 'Music & Podcast Streamers Globally',
    marketingObjective: 'Community Building & Viral User Sharing',
    marketingStyle: 'Personalized',
    tagline: 'Data-driven self-deprecation that users love to share',
    accentColor: '#1DB954',
    badge: 'Data Storytelling Pioneer',
    approach: 'Spotify turned user listening data into social currency. Through Wrapped and outdoor billboard campaigns, they playfully called out bizarre user habits, niche playlist titles, and embarrassing musical guilty pleasures.',
    keyLesson: 'Users love memes where they themselves are the humorous subject.',
    examples: [
      'Billboard: “To the person who listened to ‘Sorry’ 42 times on Valentine’s Day: What did you do?”',
      'Playlist memes matching hyper-specific emotional states like “staring at ceiling at 3 AM”',
      'Spotify Wrapped badges celebrating being in the top 0.05% of moody indie listeners'
    ],
    dos: [
      'Turn anonymized aggregate behavior into punchy witty copy',
      'Provide users with beautiful, ready-to-share social badges',
      'Celebrate musical eccentricity rather than shaming it'
    ],
    donts: [
      'Do not violate user privacy comfort boundaries',
      'Do not overcomplicate chart visuals on mobile screens'
    ]
  },
  {
    id: 'amul',
    brand: 'Amul',
    industry: 'FMCG',
    targetAudience: 'Multi-generational Indian Public',
    marketingObjective: 'Cultural Relevance & Enduring Affinity',
    marketingStyle: 'Cultural',
    tagline: 'The original topical cartoon meme since 1966',
    accentColor: '#1E3A8A',
    badge: 'Heritage Topical Pioneer',
    approach: 'Decades before the internet existed, Amul pioneered meme marketing through topical billboard illustrations featuring the polka-dot Amul Girl, reacting with wordplay to national news, cricket, cinema, and politics within 24 hours.',
    keyLesson: 'Consistency and clever wordplay build multi-decade brand reverence.',
    examples: [
      'Reacting to cinematic milestones with buttery pun taglines like “Makhan Ka Don”',
      'Celebrating historic space rover landings with “Butter on the Moon” illustrations',
      'Warm humorous takes on sports tournament victories published overnight'
    ],
    dos: [
      'Maintain distinctive, instantly recognizable visual character and font',
      'React within the 24-hour topical cultural cycle',
      'Keep tone lighthearted, respectful, and unifying across age groups'
    ],
    donts: [
      'Do not take divisive political sides that alienate customer segments',
      'Do not abandon the core mascot for fleeting aesthetic fads'
    ]
  },
  {
    id: 'ryanair',
    brand: 'Ryanair',
    industry: 'Travel',
    targetAudience: 'Budget Travelers & Gen Z Backpacker Crowd',
    marketingObjective: 'Brand Awareness & Expectation Setting',
    marketingStyle: 'Self-aware',
    tagline: 'You paid €9.99 for a flight, don’t expect a massage',
    accentColor: '#0D47A1',
    badge: 'Radical Self-Awareness',
    approach: 'Instead of defensively defending their bare-bones budget model, Ryanair embraced it with ruthless self-awareness on Twitter and TikTok, roasting complaints about legroom, windowless seats, and extra baggage fees.',
    keyLesson: 'Address customer gripes with self-aware humor to disarm criticism.',
    examples: [
      'Passenger asks: “Where is my window?” Ryanair replies with a red circle around their ticket price: “€12”',
      'TikTok video putting cartoon eyes on an airplane reacting to passengers clapping upon landing',
      'Roasting luxury airline travelers for paying 10x more for the same altitude cloud view'
    ],
    dos: [
      'Own your exact market positioning with zero pretension',
      'Use fast-paced creator video edits directly in airplane cabins',
      'Remind passengers of the core undeniable value: rock-bottom price'
    ],
    donts: [
      'Never joke about flight safety, maintenance, or cancellations',
      'Do not be genuinely mean-spirited to individuals in legitimate distress'
    ]
  }
];

export const MARKETER_RULES = [
  {
    rule: 'Rule 01: Product as the Punchline',
    summary: 'The meme must collapse into meaninglessness if you swap out your product. If the meme works equally well for 50 other brands, you bought someone else’s laugh.',
    tag: 'Relevance'
  },
  {
    rule: 'Rule 02: Respect the Meme Lifecycle',
    summary: 'Meme trends decay within 5 to 14 days. Running a brand approval chain that takes 3 weeks guarantees you will deploy a dead meme.',
    tag: 'Agility'
  },
  {
    rule: 'Rule 03: Never Over-Explain the Joke',
    summary: 'The social audience values high context. Adding corporate disclaimers or spelling out the punchline destroys the social currency that made the format funny.',
    tag: 'Restraint'
  },
  {
    rule: 'Rule 04: Views ≠ Conversion Velocity',
    summary: '10 million impressions without an explicit bridge to consideration or trial is just expensive noise. Always track downstream intent.',
    tag: 'Analytics'
  },
  {
    rule: 'Rule 05: Check Cultural Cross-Currents',
    summary: 'A meme template born in gaming subcultures may carry unspoken offensive or ironic connotations. Always perform context risk analysis before scaling.',
    tag: 'Safety'
  },
  {
    rule: 'Rule 06: Protect the Core Value Proposition',
    summary: 'Self-deprecation is charming only when your primary service is functional. Don’t joke about your flaws if customers are currently experiencing real product failure.',
    tag: 'Brand Fit'
  }
];
