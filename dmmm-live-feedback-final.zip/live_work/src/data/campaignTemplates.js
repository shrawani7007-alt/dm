// Campaign generator engine and fallback demo templates

export function generateCampaignData(inputs) {
  const product = inputs.product?.trim() || 'Energy Drink';
  const objective = inputs.objective || 'Engagement';
  const audience = inputs.audience || 'College Students';
  const personality = inputs.personality || 'Funny';
  const platform = inputs.platform || 'Instagram';
  const format = inputs.format || 'POV';

  // Format-specific generators
  let concept = '';
  let headline = '';
  let caption = '';
  let cta = '';
  let hashtags = [];
  let strategy = '';
  let visualBadge = '';

  const cleanProduct = product;
  const isVideoPlatform = platform === 'TikTok' || platform === 'YouTube Shorts' || platform === 'Instagram';

  switch (format) {
    case 'Kinda Chic':
    case 'Kinda Chic (Demure)':
      visualBadge = '✨ Very Demure • Kinda Chic';
      concept = `See how I elevate my daily routine? Not shouting. Not chaotic. Very mindful, very cutesy, kinda chic with ${cleanProduct}.`;
      headline = `Very demure. Very mindful. The clean upgrade you needed.`;
      caption = `Notice how we don't do loud obnoxious ads? Very considerate of your feed. Very tasteful. Very ${cleanProduct}. 🎀✨ Tag someone who needs some demure energy today.`;
      cta = `Sip and stay demure.`;
      hashtags = ['#VeryDemure', '#VeryMindful', '#KindaChic', '#CleanAesthetic', '#Upgrade'];
      strategy = `Leverage satirical understated luxury to create contrast against loud aggressive feed advertising. ${cleanProduct} becomes a badge of refined composure.`;
      break;

    case 'Jimothy the Raccoon':
    case 'Jimothy the Raccoon (Dance Loop)':
    case 'Jimothy Raccoon':
      visualBadge = '🦝 Jimothy Grooves in Circles';
      concept = `Me and the squad spinning in a pure serotonin circle because ${cleanProduct} just solved the entire semester's stress in 10 seconds.`;
      headline = `Spinning through the week on pure good vibes.`;
      caption = `Pedro Pedro Pedro Pedro Pe! 🦝 When attendance was saved, deadline was met, and the fridge is fully stocked with ${cleanProduct}. Drop a 🦝 if you feel the groove!`;
      cta = `Join the victory spin.`;
      hashtags = ['#JimothyTheRaccoon', '#PedroPedro', '#GrooveState', '#PureSerotonin', '#EnergyBoost'];
      strategy = `Harness dopamine-loop retention. The spinning raccoon visual hooks users on short-form feeds while associating ${cleanProduct} with celebratory euphoria.`;
      break;

    case 'Ravi Kishan Dance':
    case 'Ravi Kishan Dance Swagger':
      visualBadge = '🕺 Zindagi Jhandwa • Swagger On';
      concept = `Zindagi jhandwa, fir bhi conversion ghamandwa! When Monday morning unleashes pure chaos, but you crack open ${cleanProduct} with unapologetic Bollywood dance swagger.`;
      headline = `Ae babu! Bring high-voltage swagger to your daily hustle.`;
      caption = `Chaos will come and go, but your swagger remains non-negotiable. 🔥💃 Powered by ${cleanProduct}. Tag a friend who never loses their swag!`;
      cta = `Ae babu, grab your boost!`;
      hashtags = ['#RaviKishanDance', '#ZindagiJhandwa', '#DesiSwag', '#UnstoppableEnergy', '#BollywoodVibes'];
      strategy = `Tap into beloved cultural mass-appeal cinema swagger. Unapologetic confidence and catchy Desi punchlines trigger exceptional quote-shares and peer tagging.`;
      break;

    case 'POV':
      visualBadge = 'POV: 8 AM lecture';
      concept = `POV: Your 8 AM lecture started... but your brain didn't. You're clutching your bag wondering how human beings function at dawn, until ${cleanProduct} turns the cognitive lights back on.`;
      headline = `Energy for the lecture you definitely weren't ready for.`;
      caption = `When attendance is 75% mandatory but your battery is sitting at 4%. ⚡ Tag someone who is currently staring blankly into their textbook.`;
      cta = `Grab your boost before the first bell.`;
      hashtags = ['#CollegeLife', '#POV', '#CampusEnergy', '#MemeMarketing', '#BrainFogFix'];
      strategy = `Ground the meme in a high-friction universal moment (forced morning alertness). Establish ${cleanProduct} as the hero resolution rather than an intrusive ad, optimized for ${platform} ${isVideoPlatform ? 'reels/short-form loop retention' : 'carousel punch'}.`;
      break;

    case 'Drake':
      visualBadge = 'Old Way vs New Way';
      concept = `Contrasts the exhausting, antiquated routine that ${audience} endures with the frictionless, refreshing upgrade provided by ${cleanProduct}.`;
      headline = `Why struggle with the past when ${cleanProduct} is right here?`;
      caption = `Top panel: Pretending your tired old routine still works. ❌ Bottom panel: Leveling up with ${cleanProduct} in seconds. 🚀`;
      cta = `Make the switch today.`;
      hashtags = ['#LevelUp', '#WorkSmarter', '#NoMoreExcuses', '#GameChanger', '#Upgrade'];
      strategy = `Use the unmistakable Drake approval contrast to position the legacy alternative as unnecessarily painful and ${cleanProduct} as the effortless modern choice.`;
      break;

    case 'Distracted Boyfriend':
      visualBadge = 'The Irresistible Upgrade';
      concept = `Depicts the ${audience} mind helplessly turning its attention toward ${cleanProduct} while their current boring solution looks on in disbelief.`;
      headline = `Once you discover ${cleanProduct}, there's no looking back.`;
      caption = `We don't blame you for looking. Some upgrades are simply too obvious to ignore. 👀✨`;
      cta = `Experience the hype firsthand.`;
      hashtags = ['#DistractedByQuality', '#NewObsession', '#NextLevel', '#MustTry'];
      strategy = `Capitalize on lighthearted peer banter and curiosity gap. Visually label the passing temptation as the standout feature of ${cleanProduct}.`;
      break;

    case 'Expectation vs Reality':
      visualBadge = 'Expectation vs Reality';
      concept = `Contrasts the cinematic dream of flawless productivity with the humorous, chaotic reality of everyday life — saved at the buzzer by ${cleanProduct}.`;
      headline = `Aesthetic plans vs the actual hustle. We've got your back.`;
      caption = `Expectation: 5 AM morning routine, green smoothie, zero distractions. Reality: 3 alarms snoozed, mismatched socks, but powered by ${cleanProduct}. 😅`;
      cta = `Power your real routine.`;
      hashtags = ['#ExpectationVsReality', '#RelatableDaily', '#HustleReal', '#NoFilter'];
      strategy = `Build high empathy through radical authenticity. When brands admit daily life is messy, ${audience} loyalty increases dramatically.`;
      break;

    case 'Before vs After':
      visualBadge = 'Instant Transformation';
      concept = `A stark, comedic visual timeline tracking the psychological state of ${audience} prior to discovering ${cleanProduct} versus their energized state after.`;
      headline = `The 10-minute turnaround your daily schedule needed.`;
      caption = `Before: Drained, unmotivated, 17 unanswered pings. After: Focused, unstoppable, sipping ${cleanProduct}. 🔥`;
      cta = `Start your after-state now.`;
      hashtags = ['#BeforeAndAfter', '#Transformation', '#PeakPerformance', '#DailyGrind'];
      strategy = `Clear visual payoff with direct problem-to-benefit mapping. Ideal for high conversion rates on ${platform}.`;
      break;

    case 'Starter Pack':
      visualBadge = 'Official Starter Pack';
      concept = `A hyper-curated 4-element starter pack pinpointing the exact survival kit of ${audience}, anchoring ${cleanProduct} as the non-negotiable core prop.`;
      headline = `The ultimate survival kit for surviving this week.`;
      caption = `If this starter pack feels uncomfortably accurate, you definitely need another ${cleanProduct} on standby. 🎒⚡`;
      cta = `Complete your pack now.`;
      hashtags = ['#StarterPack', '#RelatableVibes', '#Essentials', '#VibeCheck'];
      strategy = `Spurs natural comment-tagging because viewers recognize their exact friends in the archetype, generating organic social amplification.`;
      break;

    case 'This Is Fine':
      visualBadge = 'This Is Fine';
      concept = `The classic burning room scenario reflecting deadlines or stress spiraling out of control, contrasted with the calm peace of mind delivered by ${cleanProduct}.`;
      headline = `When everything is on fire, but you already have ${cleanProduct}.`;
      caption = `Room is burning, inbox has 489 unread messages, but you're chilling with ${cleanProduct} because your priorities are locked in. 🔥☕`;
      cta = `Keep your cool with us.`;
      hashtags = ['#ThisIsFine', '#DeadlineSeason', '#StayCalm', '#EmergencyBoost'];
      strategy = `Validates user stress through dark comedic catharsis while immediately providing tangible reassurance through product utility.`;
      break;

    case 'Surprised Pikachu':
      visualBadge = 'Predictable Consequences';
      concept = `Chronicles the exact self-sabotaging behavior that ${audience} commits daily, followed by hilarious feigned shock when exhaustion hits — resolved by ${cleanProduct}.`;
      headline = `Surprised you need ${cleanProduct} after staying up till 4 AM?`;
      caption = `Action: Ignores bedtime. Action: Promises to wake up refreshed. Result: Shocked Pikachu face at 7:30 AM. 😮 Fix it before your morning meeting!`;
      cta = `Wake up for real.`;
      hashtags = ['#SurprisedPikachu', '#SelfSabotage', '#MorningStruggles', '#InstantEnergy'];
      strategy = `Ironic self-callout creates zero defensiveness and maximum shareability across group chats.`;
      break;

    case 'Phir Hera Pheri':
    case 'Phir Hera Pheri (21 Din Me Paisa Double)':
      visualBadge = '💰 21 Din Me Paisa Double';
      concept = `Zor zor se bolke sabko scheme mat bata! When competitors promise 21-day false overnight miracles, but ${cleanProduct} delivers real compounding results.`;
      headline = `No 21-Din Schemes. Just Pure Real Compounding Value.`;
      caption = `Yeh Baburao ka style hai! 💰 When they said it would take 3 months, but ${cleanProduct} solves it in 21 minutes. Tag your scheme master squad! 😂`;
      cta = `Yeh Baburao ka style hai — Grab Yours.`;
      hashtags = ['#PhirHeraPheri', '#21DinMePaisaDouble', '#BaburaoStyle', '#RealResults', '#DesiMemes'];
      strategy = `Deploy legendary Bollywood humor with 100% recognition. Connects the comical fear of empty promises with the genuine, verified reliability of ${cleanProduct}.`;
      break;

    case 'Chin Tapak Dum Dum':
      visualBadge = '🪄 Chin Tapak Dum Dum';
      concept = `Deadlines mounting, stress spiraling, zero mental bandwidth left... 🪄 Chin Tapak Dum Dum! ${cleanProduct} arrives and the entire problem vanishes into thin air.`;
      headline = `Marketing chaos vanished in one tap: Chin Tapak Dum Dum!`;
      caption = `Ek chutki mein confusion gayab? Absolutely! Chin Tapak Dum Dum with ${cleanProduct} and watch the magic happen. 🪄✨ Drop a 🪄 if you need this magic today!`;
      cta = `Dum Dum your workload now.`;
      hashtags = ['#ChinTapakDumDum', '#MagicVanish', '#ReelTrending', '#InstantRelief', '#MemeMagic'];
      strategy = `Ride the peak audio-trend momentum on Instagram Reels and TikTok. Transforms ${cleanProduct} into a playful magical wand solving consumer frustration.`;
      break;

    case 'Piche Dekho Piche':
    case 'Piche To Dekho':
      visualBadge = '👀 Piche To Dekho!';
      concept = `Piche to dekho, piche dekho piche! Your competitors and old legacy habits are running miles behind you while you cruise ahead with ${cleanProduct}.`;
      headline = `Piche to dekho! Your legacy routine is crying behind you.`;
      caption = `Turn around and see how far ahead you are. 🏃💨 Legacy alternatives are still buffering while you operate on ${cleanProduct}. Tag someone who needs to catch up!`;
      cta = `Turn around & upgrade.`;
      hashtags = ['#PicheToDekho', '#PicheDekhoPiche', '#ChallengerBrand', '#CatchUp', '#ViralHook'];
      strategy = `Use playful irreverence to establish category dominance. Perfect challenger brand positioning showing legacy habits struggling in the rearview mirror.`;
      break;

    case 'Wah Shampy Wah':
    case 'Wah Shampy Wah!':
      visualBadge = '🏆 Wah Shampy Wah!';
      concept = `Wah Shampy Wah! When the team expected modest numbers, but ${cleanProduct} crushed every single KPI and shattered all previous engagement records.`;
      headline = `Wah Shampy Wah! The campaign just broke every milestone.`;
      caption = `Shaandar Shampy shaandar! 🏆 When your product drop turns into a celebratory Bhangra session because ${cleanProduct} delivered pure perfection. Celebration mode ON!`;
      cta = `Join the winners circle.`;
      hashtags = ['#WahShampyWah', '#Shaandar', '#BigWin', '#CelebrationVibes', '#DholRoll'];
      strategy = `Inject exuberant Punjabi celebration and triumph. Elevates customer victories into infectious community pride, boosting quote-shares and peer referrals.`;
      break;

    case 'Skibidi Toilet':
      visualBadge = '🚽 Skibidi Bop Bop Yes Yes';
      concept = `Skibidi bop bop yes yes! Before the morning brainrot takes over your 8 AM presentation, drink ${cleanProduct} and restore high-definition cognitive clarity.`;
      headline = `Skibidi bop bop yes yes! Defeat the brainrot in 0.2s.`;
      caption = `When the feed is running at 1000 mph and your brain is at 0.1%. Resuscitate your focus with ${cleanProduct} before the cameramen take over. 🚽⚡`;
      cta = `Escape the brainrot now.`;
      hashtags = ['#SkibidiToilet', '#SkibidiBopBop', '#GenAlpha', '#AttentionGrabber', '#BrainrotCure'];
      strategy = `Ultra-fast sub-0.3 second feed-stopping power. Captures Gen Z & Gen Alpha visual literacy while providing immediate real-world relief.`;
      break;

    case '6-7':
    case '6-7 Viral Score':
      visualBadge = '🔢 The 6-7 Mystery Index';
      concept = `Why settle for an average 6-7 when ${cleanProduct} pushes your performance score straight to a verified 10/10?`;
      headline = `Cracking the 6-7 code: Why average is no longer acceptable.`;
      caption = `Most daily options cap out at a weak 6-7. ${cleanProduct} broke the ceiling and landed a solid 10/10 across all benchmarks. Where does your current habit rank? 🔢👇`;
      cta = `Upgrade to a 10/10 score.`;
      hashtags = ['#SixSeven', '#ViralIndex', '#ScoreTen', '#NoMoreAverage', '#PerformanceCheck'];
      strategy = `Ignites comment-section debates and tier-ranking discussions. Pushes high organic engagement algorithms on Instagram and X.`;
      break;

    default:
      visualBadge = 'POV: Relatable Moment';
      concept = `A relatable cultural twist showcasing how ${cleanProduct} transforms ordinary moments for ${audience}.`;
      headline = `The smart upgrade you didn't know you needed.`;
      caption = `When the daily hustle demands better solutions. Powered by ${cleanProduct}. ⚡`;
      cta = `Check it out today.`;
      hashtags = ['#SmartChoice', '#MemeMarketing', '#DailyUpgrade'];
      strategy = `Deliver the core proposition through lighthearted, high-engagement storytelling tailored for ${platform}.`;
  }

  // Calculate M² Score based on audience, personality and format fit
  let baseAttention = 8.0;
  let baseRelatability = 8.5;
  let baseBrandFit = 8.0;
  let baseTrendRelevance = 7.5;
  let baseShareability = 8.5;
  let baseMessageClarity = 8.0;

  if (audience === 'College Students' || audience === 'Gen Z') {
    baseRelatability += 0.5;
    baseShareability += 0.5;
  }
  if (personality === 'Funny' || personality === 'Chaotic') {
    baseAttention += 0.6;
    baseShareability += 0.4;
  }
  if (personality === 'Professional') {
    baseMessageClarity += 0.8;
    baseTrendRelevance -= 0.5;
  }

  const attentionScore = Math.min(10, Math.max(6, +(baseAttention).toFixed(1)));
  const relatabilityScore = Math.min(10, Math.max(6, +(baseRelatability).toFixed(1)));
  const brandFitScore = Math.min(10, Math.max(6, +(baseBrandFit).toFixed(1)));
  const trendScore = Math.min(10, Math.max(6, +(baseTrendRelevance).toFixed(1)));
  const shareabilityScore = Math.min(10, Math.max(6, +(baseShareability).toFixed(1)));
  const clarityScore = Math.min(10, Math.max(6, +(baseMessageClarity).toFixed(1)));

  const overallScore = +((attentionScore + relatabilityScore + brandFitScore + trendScore + shareabilityScore + clarityScore) / 6).toFixed(1);

  // Risk dimensions
  const riskCheck = [
    {
      dimension: 'Brand Fit',
      status: personality === 'Chaotic' ? 'MODERATE' : 'LOW',
      color: personality === 'Chaotic' ? 'orange' : 'green',
      assessment: personality === 'Chaotic'
        ? 'Edgier humor requires strict boundary checks to prevent diluting premium brand equity.'
        : 'The comedic tone directly reinforces the product value proposition without creating brand confusion.'
    },
    {
      dimension: 'Audience Misunderstanding',
      status: 'LOW',
      color: 'green',
      assessment: `The ${format} premise is deeply rooted in universal ${audience} vernacular with minimal ambiguity.`
    },
    {
      dimension: 'Trend Dependency',
      status: (format === 'Surprised Pikachu' || format === 'Drake') ? 'LOW' : 'MODERATE',
      color: (format === 'Surprised Pikachu' || format === 'Drake') ? 'green' : 'orange',
      assessment: 'The format operates as an evergreen situational template, insulating the campaign from sudden meme decay.'
    },
    {
      dimension: 'Product Clarity',
      status: 'LOW',
      color: 'green',
      assessment: `${cleanProduct} is positioned directly as the solution to the tension, avoiding the "remembered the meme, forgot the product" trap.`
    },
    {
      dimension: 'Context Risk',
      status: 'LOW',
      color: 'green',
      assessment: 'No sensitive cultural, political, or polarizing tropes detected in the primary hook or caption structure.'
    }
  ];

  // A/B Test comparisons (Traditional Ad vs Meme Ad)
  const abTest = {
    versionA: {
      name: 'Version A: Traditional Ad',
      description: 'Standard product photo with functional benefit headlines and corporate CTA.',
      reach: 50000,
      clicks: 750,
      ctr: '1.5%',
      conversions: 45,
      convRate: '6.0%',
      revenue: 22500,
      roi: '125%',
      viralityIndex: '1.1x'
    },
    versionB: {
      name: `Version B: ${format} Meme Ad`,
      description: `Situational relatable meme featuring ${cleanProduct} as punchline hero.`,
      reach: 124000,
      clicks: 4340,
      ctr: '3.5%',
      conversions: 347,
      convRate: '8.0%',
      revenue: 173500,
      roi: '1635%',
      viralityIndex: '3.8x'
    }
  };

  return {
    id: 'camp_' + Date.now(),
    createdAt: new Date().toISOString(),
    product: cleanProduct,
    objective,
    audience,
    personality,
    platform,
    format,
    visualBadge,
    concept,
    headline,
    caption,
    cta,
    hashtags,
    strategy,
    m2Score: {
      overall: overallScore,
      attention: attentionScore,
      relatability: relatabilityScore,
      brandFit: brandFitScore,
      trendRelevance: trendScore,
      shareability: shareabilityScore,
      messageClarity: clarityScore,
      insights: [
        `High organic share velocity expected among ${audience} due to natural situational alignment.`,
        `Product integration occurs before second 3, reducing brand attribution drop-off.`,
        `Low risk of audience fatigue due to situational rather than meme-slang reliance.`
      ]
    },
    riskCheck,
    roiDefaults: {
      budget: 10000,
      reach: 50000,
      engagementRate: 5.0,
      ctr: 3.0,
      conversionRate: 10.0,
      aov: 500
    },
    abTest
  };
}

export const INITIAL_SAVED_CAMPAIGNS = [
  {
    id: 'camp_demo_01',
    createdAt: '2026-09-24T14:30:00Z',
    product: 'Campus Fuel Energy Drink',
    objective: 'Engagement',
    audience: 'College Students',
    personality: 'Funny',
    platform: 'Instagram',
    format: 'POV',
    visualBadge: 'POV: 8 AM lecture',
    concept: 'POV: Your 8 AM lecture started... but your brain didn’t. You’re clutching your bag wondering how human beings function at dawn, until Campus Fuel turns the cognitive lights back on.',
    headline: 'Energy for the lecture you definitely weren’t ready for.',
    caption: 'When attendance is mandatory but your energy isn’t. ⚡ Grab your cold can before the professor locks the door. #CampusEnergy',
    cta: 'Grab your boost before the first bell.',
    hashtags: ['#CollegeLife', '#POV', '#CampusEnergy', '#MemeMarketing'],
    strategy: 'Use a familiar college moment, make the product the natural solution, then adapt the edit for short-form video loops on Instagram Reels.',
    m2Score: {
      overall: 8.2,
      attention: 8.0,
      relatability: 9.0,
      brandFit: 8.0,
      trendRelevance: 7.0,
      shareability: 8.0,
      messageClarity: 9.0,
      insights: [
        'Exceptional relatability for 18-24 demographic during semester exam phases.',
        'Clear punchline delivery ensures brand recall matches humor recall.',
        'High organic save & DM share rate in campus group chats.'
      ]
    },
    riskCheck: [
      { dimension: 'Brand Fit', status: 'LOW', color: 'green', assessment: 'Natural fit for fast-moving beverage positioning.' },
      { dimension: 'Audience Misunderstanding', status: 'LOW', color: 'green', assessment: '8 AM lecture struggles are universally understood across universities.' },
      { dimension: 'Trend Dependency', status: 'LOW', color: 'green', assessment: 'POV is a permanent structural format rather than a fleeting sound trend.' },
      { dimension: 'Product Clarity', status: 'LOW', color: 'green', assessment: 'Cold can cracking open serves as the immediate cognitive savior.' },
      { dimension: 'Context Risk', status: 'LOW', color: 'green', assessment: 'Harmless situational humor with zero polarizing or offensive connotations.' }
    ],
    roiDefaults: { budget: 10000, reach: 50000, engagementRate: 5.0, ctr: 3.0, conversionRate: 10.0, aov: 500 },
    status: 'Ready'
  },
  {
    id: 'camp_demo_02',
    createdAt: '2026-09-22T10:15:00Z',
    product: 'Campus Fest Late-Night Pass',
    objective: 'Event',
    audience: 'Young Professionals',
    personality: 'Chaotic',
    platform: 'X',
    format: 'This Is Fine',
    visualBadge: 'This Is Fine',
    concept: 'When tomorrow morning is your quarterly board presentation, but headlining DJ tickets just dropped for Friday night and you are already in the group chat booking passes.',
    headline: 'Sleep is temporary. Headline sets are permanent.',
    caption: 'Me looking at my calendar meeting invites while typing “YES I AM IN” to the Saturday VIP pass. 🔥🎟️',
    cta: 'Secure your pass before early bird ends.',
    hashtags: ['#FestSeason', '#ThisIsFine', '#Nightlife', '#WeekendVibes'],
    strategy: 'Leverage self-aware deadline tension to accelerate ticket FOMO and immediate checkout conversions on X.',
    m2Score: {
      overall: 7.9,
      attention: 8.5,
      relatability: 8.2,
      brandFit: 7.5,
      trendRelevance: 7.0,
      shareability: 8.8,
      messageClarity: 7.4,
      insights: [
        'Virality score spikes on Thursdays and Fridays when weekend anticipation peaks.',
        'Strong quote-tweet and meme repost affinity among young corporate crowd.'
      ]
    },
    riskCheck: [
      { dimension: 'Brand Fit', status: 'LOW', color: 'green', assessment: 'Festivals thrive on reckless excitement and spontaneity.' },
      { dimension: 'Audience Misunderstanding', status: 'LOW', color: 'green', assessment: 'Clear ironical contrast between work responsibility and festival euphoria.' },
      { dimension: 'Trend Dependency', status: 'LOW', color: 'green', assessment: 'This Is Fine is an iconic internet staple.' },
      { dimension: 'Product Clarity', status: 'MODERATE', color: 'orange', assessment: 'Ensure event dates and ticketing links are pinned clearly in first reply.' },
      { dimension: 'Context Risk', status: 'LOW', color: 'green', assessment: 'Mild lighthearted work-life balance humor.' }
    ],
    roiDefaults: { budget: 25000, reach: 120000, engagementRate: 6.2, ctr: 4.1, conversionRate: 7.5, aov: 1200 },
    status: 'In Review'
  },
  {
    id: 'camp_demo_03',
    createdAt: '2026-09-20T18:45:00Z',
    product: 'ThreadCraft Oversized Hoodies',
    objective: 'Product Launch',
    audience: 'Fashion Audience',
    personality: 'Cool',
    platform: 'TikTok',
    format: 'Starter Pack',
    visualBadge: 'Streetwear Starter Pack',
    concept: 'The “I only drink oat milk and listen to unreleased SoundCloud demos” Autumn Starter Pack featuring vintage headphones, wireframe glasses, and ThreadCraft Heavyweight Fleece.',
    headline: 'You don’t just wear the hoodie. You wear the subculture.',
    caption: 'Tag the friend who owns literally every single item in this photo. Autumn drop 01 is now live in limited batch.',
    cta: 'Shop the Autumn Capsule.',
    hashtags: ['#StarterPack', '#StreetwearDrop', '#Aesthetic', '#OversizedFit'],
    strategy: 'Use niche cultural markers to confer insider status on early buyers, motivating high organic TikTok story reposts.',
    m2Score: {
      overall: 8.5,
      attention: 8.8,
      relatability: 8.9,
      brandFit: 8.7,
      trendRelevance: 8.4,
      shareability: 8.6,
      messageClarity: 7.8,
      insights: [
        'Aesthetic starter packs trigger high comment-section debates and tagging.',
        'High conversion correlation when paired with limited-inventory urgency.'
      ]
    },
    riskCheck: [
      { dimension: 'Brand Fit', status: 'LOW', color: 'green', assessment: 'Direct aesthetic alignment with high-fashion streetwear norms.' },
      { dimension: 'Audience Misunderstanding', status: 'LOW', color: 'green', assessment: 'Niche visual cues land effortlessly with fashion-conscious demographic.' },
      { dimension: 'Trend Dependency', status: 'MODERATE', color: 'orange', assessment: 'Aesthetic micro-trends evolve quickly; update accessories seasonally.' },
      { dimension: 'Product Clarity', status: 'LOW', color: 'green', assessment: 'Hoodie is hero centerpiece in high visual resolution.' },
      { dimension: 'Context Risk', status: 'LOW', color: 'green', assessment: 'Zero controversial elements.' }
    ],
    roiDefaults: { budget: 15000, reach: 75000, engagementRate: 7.0, ctr: 3.8, conversionRate: 8.5, aov: 1800 },
    status: 'Ready'
  }
];
