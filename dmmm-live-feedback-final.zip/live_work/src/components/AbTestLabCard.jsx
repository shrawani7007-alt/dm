import React from 'react';
import { useApp } from '../context/AppContext';
import { Zap, Lock, Sparkles, TrendingUp, Info, BarChart2, Check, ArrowRight, Users, MousePointerClick, IndianRupee } from 'lucide-react';
import { getDynamicAbMetrics } from '../utils/analyticsStorage';

export default function AbTestLabCard({ campaign, locked }) {
  const { isPro, openProPaywall } = useApp();
  const isLocked = locked ?? !isPro;

  const live = getDynamicAbMetrics();
  const aCtr = live.versionAReach ? ((live.versionAClicks / live.versionAReach) * 100).toFixed(1) : '0.0';
  const bCtr = live.versionBReach ? ((live.versionBClicks / live.versionBReach) * 100).toFixed(1) : '0.0';
  const aRevenue = live.versionAConversions * 999;
  const bRevenue = live.versionBConversions * 999;

  const abData = {
    versionA: {
      name: 'Version A: Traditional Ad',
      description: 'Standard product creative with a functional benefit headline and corporate CTA.',
      reach: live.versionAReach,
      clicks: live.versionAClicks,
      ctr: `${aCtr}%`,
      conversions: live.versionAConversions,
      convRate: live.versionAClicks ? `${((live.versionAConversions / live.versionAClicks) * 100).toFixed(1)}%` : '0.0%',
      revenue: aRevenue,
      roi: 'Demo',
      viralityIndex: '1.0x'
    },
    versionB: {
      name: `Version B: ${campaign?.format || 'POV'} Meme Ad`,
      description: `Situational relatable meme featuring ${campaign?.product || 'Product'} as the punchline hero.`,
      reach: live.versionBReach,
      clicks: live.versionBClicks,
      ctr: `${bCtr}%`,
      conversions: live.versionBConversions,
      convRate: live.versionBClicks ? `${((live.versionBConversions / live.versionBClicks) * 100).toFixed(1)}%` : '0.0%',
      revenue: bRevenue,
      roi: 'Demo',
      viralityIndex: '1.2x'
    }
  };

  const metrics = [
    { label: 'Total Reach', aVal: abData.versionA.reach.toLocaleString('en-IN'), bVal: abData.versionB.reach.toLocaleString('en-IN'), aNum: abData.versionA.reach, bNum: abData.versionB.reach, unit: 'users' },
    { label: 'Ad Clicks', aVal: abData.versionA.clicks.toLocaleString('en-IN'), bVal: abData.versionB.clicks.toLocaleString('en-IN'), aNum: abData.versionA.clicks, bNum: abData.versionB.clicks, unit: 'clicks' },
    { label: 'Click-Through Rate (CTR)', aVal: abData.versionA.ctr, bVal: abData.versionB.ctr, aNum: Number(aCtr), bNum: Number(bCtr), unit: '%' },
    { label: 'Conversions', aVal: abData.versionA.conversions.toLocaleString('en-IN'), bVal: abData.versionB.conversions.toLocaleString('en-IN'), aNum: abData.versionA.conversions, bNum: abData.versionB.conversions, unit: 'orders' },
    { label: 'Gross Revenue / Month', aVal: `₹${Math.min(live.monthlyRevenue, aRevenue).toLocaleString('en-IN')}`, bVal: `₹${Math.min(live.monthlyRevenue, bRevenue).toLocaleString('en-IN')}`, aNum: Math.min(live.monthlyRevenue, aRevenue), bNum: Math.min(live.monthlyRevenue, bRevenue), unit: '₹' },
    { label: 'Subscriptions', aVal: '—', bVal: live.subscriptions.toLocaleString('en-IN'), aNum: 0, bNum: live.subscriptions, unit: 'subscriptions' },
  ];

  return (
    <div className="relative bg-white rounded-3xl p-6 sm:p-8 shadow-card border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-gray-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-blue-100 text-blue-600">
              <BarChart2 className="w-5 h-5" />
            </span>
            <h3 className="text-xl sm:text-2xl font-bold font-heading text-brand-primary">
              A/B Testing Lab
            </h3>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Controlled split-test benchmarks: Traditional Direct-Response Banner vs Meme Creative
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="px-3 py-1.5 rounded-full bg-purple-100 text-brand-accent text-xs font-black uppercase">
            LIVE DEMO METRICS
          </span>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="rounded-2xl bg-gray-50 border border-gray-200 p-4">
          <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-wider text-gray-400"><Users className="w-3.5 h-3.5" /> Website visits</div>
          <div className="text-2xl font-black text-gray-900 mt-1">{live.visits}</div>
          <p className="text-[10px] text-gray-500 mt-1">One count per browser session.</p>
        </div>
        <div className="rounded-2xl bg-gray-50 border border-gray-200 p-4">
          <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-wider text-gray-400"><MousePointerClick className="w-3.5 h-3.5" /> Site ad clicks</div>
          <div className="text-2xl font-black text-gray-900 mt-1">{live.visits * 2 + 2}</div>
          <p className="text-[10px] text-gray-500 mt-1">Grows with site activity.</p>
        </div>
        <div className="rounded-2xl bg-gray-50 border border-gray-200 p-4">
          <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-wider text-gray-400"><IndianRupee className="w-3.5 h-3.5" /> Monthly gross revenue</div>
          <div className="text-2xl font-black text-gray-900 mt-1">₹{live.monthlyRevenue.toLocaleString('en-IN')}</div>
          <p className="text-[10px] text-gray-500 mt-1">₹999 counted per simulated subscription.</p>
        </div>
      </div>

      <div className={isLocked ? 'filter blur-sm select-none pointer-events-none opacity-40 mt-6' : 'mt-6'}>
        {/* Version Badges Top */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div className="p-4 rounded-2xl bg-gray-50 border border-gray-200 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-gray-400">Control Variant</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-gray-200 text-gray-700">Standard</span>
            </div>
            <h4 className="text-sm font-bold text-gray-900 font-heading">
              {abData.versionA.name}
            </h4>
            <p className="text-xs text-gray-500 font-sans">
              {abData.versionA.description}
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-purple-50/70 border border-purple-200 space-y-1 relative">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-700">Test Variant</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-brand-secondary text-brand-primary font-heading">
                Top Performer
              </span>
            </div>
            <h4 className="text-sm font-bold text-purple-950 font-heading">
              {abData.versionB.name}
            </h4>
            <p className="text-xs text-purple-900/80 font-sans">
              {abData.versionB.description}
            </p>
          </div>
        </div>

        {/* Metrics Visual Comparison Bars */}
        <div className="space-y-4">
          {metrics.map((m, i) => {
            const maxVal = Math.max(m.aNum, m.bNum);
            const aWidth = maxVal > 0 ? (m.aNum / maxVal) * 100 : 0;
            const bWidth = maxVal > 0 ? (m.bNum / maxVal) * 100 : 0;

            return (
              <div key={i} className="p-3.5 rounded-2xl bg-gray-50/60 border border-gray-200/80 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-gray-800">{m.label}</span>
                  <div className="flex items-center gap-4 text-xs font-mono font-semibold">
                    <span className="text-gray-500">A: {m.aVal}</span>
                    <span className="text-brand-accent font-bold">B: {m.bVal}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  {/* Bar A */}
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-gray-400 w-4">A</span>
                    <div className="flex-1 bg-gray-200 h-2 rounded-full overflow-hidden">
                      <div className="bg-gray-400 h-full rounded-full transition-all duration-500" style={{ width: `${aWidth}%` }} />
                    </div>
                  </div>
                  {/* Bar B */}
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-brand-accent w-4">B</span>
                    <div className="flex-1 bg-gray-200 h-2.5 rounded-full overflow-hidden">
                      <div className="bg-gradient-to-r from-brand-accent to-brand-secondary h-full rounded-full transition-all duration-500" style={{ width: `${bWidth}%` }} />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Required Disclaimer */}
        <div className="mt-6 flex items-start gap-2 text-[11px] text-gray-500 bg-amber-50/50 p-3 rounded-xl border border-amber-200/60">
          <Info className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
          <span>
            <strong>Required Notice:</strong> Live demo counters. Reach and clicks grow from website sessions; revenue grows from simulated Pro subscriptions. Connect a shared analytics backend before treating these as real cross-user business metrics. Controlled testing accounts for platform ad auction variances and audience novelty spikes.
          </span>
        </div>
      </div>

      {/* Locked Overlay for Free Users */}
      {isLocked && (
        <div className="absolute inset-0 bg-white/60 backdrop-blur-[2px] flex flex-col items-center justify-center p-6 text-center z-10">
          <div className="w-12 h-12 rounded-2xl bg-[#111111] text-brand-secondary flex items-center justify-center mb-3 shadow-md">
            <Lock className="w-6 h-6" />
          </div>
          <h4 className="text-lg sm:text-xl font-extrabold font-heading text-brand-primary">
            A/B Testing Simulator Locked
          </h4>
          <p className="text-xs text-gray-600 max-w-sm mt-1 mb-4">
            Benchmark traditional ad creative vs meme variations across clicks, conversions, and ROI.
          </p>
          <button
            onClick={openProPaywall}
            className="px-6 py-3 rounded-xl bg-brand-accent hover:bg-brand-accentHover text-white font-bold text-xs uppercase tracking-wider shadow-glow-accent hover:scale-105 transition-all flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-brand-secondary" />
            Unlock Pro Evaluation Suite
          </button>
        </div>
      )}
    </div>
  );
}
