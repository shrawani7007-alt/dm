import React, { useState, useEffect } from 'react';
import { memeAudio } from '../utils/memeAudioEngine';
import { TRENDING_MEME_ASSETS } from '../data/trendingStickers';
import { useApp } from '../context/AppContext';
import { 
  Volume2, VolumeX, Play, Square, Music, Sparkles, 
  Flame, Zap, Radio, Disc, Disc3, ShieldAlert 
} from 'lucide-react';

export default function MemeAudioDanceSoundboard({ onSelectAsset }) {
  const { addToast } = useApp();
  const [activeTrack, setActiveTrack] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState(TRENDING_MEME_ASSETS[0]);
  const [bpmPulse, setBpmPulse] = useState(false);

  // Listen to audio engine events
  useEffect(() => {
    const handleAudioChange = (e) => {
      setIsPlaying(e.detail.isPlaying);
      setActiveTrack(e.detail.trackId);
    };

    window.addEventListener('meme_audio_state_change', handleAudioChange);
    return () => {
      window.removeEventListener('meme_audio_state_change', handleAudioChange);
      memeAudio.stop();
    };
  }, []);

  // Visual pulse on beat
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setBpmPulse(prev => !prev);
    }, 450);
    return () => clearInterval(interval);
  }, [isPlaying]);

  const handlePlayToggle = (asset) => {
    setSelectedAsset(asset);
    if (activeTrack === asset.id && isPlaying) {
      memeAudio.stop();
      addToast(`Stopped ${asset.name} audio`, 'info');
    } else {
      memeAudio.play(asset.id);
      addToast(`🎵 Playing ${asset.name}! Watch the dance animation.`, 'success');
      if (onSelectAsset) {
        onSelectAsset(asset);
      }
    }
  };

  const handleStopAll = () => {
    memeAudio.stop();
    addToast('Audio stopped', 'info');
  };

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-card border border-gray-200 space-y-6">
      
      {/* Soundboard Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-5">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-purple-50 text-brand-accent text-xs font-bold uppercase tracking-wider border border-purple-200">
            <Radio className="w-3.5 h-3.5 animate-pulse text-red-500" />
            Live Web Audio & Dance FX Engine
          </div>
          <h2 className="text-2xl sm:text-3xl font-black font-heading text-brand-primary">
            Meme Sound Effects & Viral Dances
          </h2>
          <p className="text-xs sm:text-sm text-gray-600 font-sans">
            Synthesized real beats & sound effects: Brazilian Phonk, FAHHHH!, Scuba Dance, Gucci Ravi Kishan, Phir Hera Pheri, Chin Tapak Dum Dum, and more.
          </p>
        </div>

        {isPlaying && (
          <button
            onClick={handleStopAll}
            className="flex-shrink-0 px-4 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 font-bold text-xs flex items-center gap-2 border border-red-200 transition-colors"
          >
            <Square className="w-4 h-4 fill-current" />
            <span>Stop Sound FX</span>
          </button>
        )}
      </div>

      {/* Interactive Active Dance & Beat Visualizer Stage */}
      <div className="relative rounded-3xl bg-[#111111] p-6 sm:p-8 text-white overflow-hidden border border-gray-800 shadow-elevated">
        <div className="absolute inset-0 bg-[radial-gradient(#333_1px,transparent_1px)] [background-size:16px_16px] opacity-40" />

        <div className="relative z-10 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          
          {/* Left: Dancing Character Animation Stage */}
          <div className="md:col-span-4 flex flex-col items-center justify-center p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md text-center">
            
            {/* Animated Dance Avatar */}
            <div className={`w-24 h-24 rounded-full flex items-center justify-center text-5xl mb-3 shadow-glow-yellow transition-all duration-300 ${
              isPlaying ? (
                selectedAsset.id === 'brazilian-phonk' ? 'animate-pulse scale-110 bg-green-500/20 border-2 border-green-400' :
                selectedAsset.id === 'scuba-dance' ? 'animate-bounce scale-110 bg-cyan-500/20 border-2 border-cyan-400' :
                selectedAsset.id === 'gucci-ravi-kishan' ? 'animate-spin-slow scale-115 bg-pink-500/20 border-2 border-pink-400' :
                selectedAsset.id === 'phir-hera-pheri' ? 'animate-float scale-110 bg-amber-500/20 border-2 border-amber-400' :
                selectedAsset.id === 'chin-tapak-dum-dum' ? 'animate-pulse scale-115 bg-purple-500/20 border-2 border-purple-400' :
                selectedAsset.id === 'skibidi-toilet' ? 'animate-spin scale-110 bg-orange-500/20 border-2 border-orange-400' :
                'animate-bounce scale-105 bg-white/10'
              ) : 'bg-white/5 opacity-70'
            }`}>
              <span>{selectedAsset.emoji}</span>
            </div>

            <span className="font-heading font-black text-lg text-white">
              {selectedAsset.name}
            </span>
            <span className="text-[11px] font-mono text-brand-secondary mt-0.5">
              {selectedAsset.danceMove || 'Signature Dance Groove'}
            </span>

            {/* Live Audio Equalizer Waveform Bars */}
            <div className="flex items-center gap-1 mt-4 h-6">
              {[40, 75, 95, 60, 85, 100, 70, 50, 90, 65, 80, 45].map((height, i) => (
                <div
                  key={i}
                  className={`w-1 rounded-full transition-all duration-150 ${
                    isPlaying ? 'bg-gradient-to-t from-brand-accent to-brand-secondary' : 'bg-gray-700 h-1.5'
                  }`}
                  style={{
                    height: isPlaying ? `${bpmPulse ? height : height * 0.45}%` : '4px'
                  }}
                />
              ))}
            </div>

          </div>

          {/* Right: Sound Metadata & Marketing Context */}
          <div className="md:col-span-8 space-y-4 text-left">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-brand-secondary text-brand-primary">
                {selectedAsset.tag}
              </span>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-white/10 text-gray-300">
                {selectedAsset.bpm}
              </span>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-purple-900/60 text-purple-200 border border-purple-700/50">
                {selectedAsset.soundtrackType}
              </span>
            </div>

            <h3 className="text-xl sm:text-2xl font-black font-heading text-white">
              "{selectedAsset.posterHeadline}"
            </h3>

            <p className="text-xs sm:text-sm text-gray-300 font-sans leading-relaxed">
              {selectedAsset.description}
            </p>

            <div className="p-3.5 rounded-2xl bg-white/10 border border-white/15 text-xs text-amber-200 italic">
              {selectedAsset.quote}
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => handlePlayToggle(selectedAsset)}
                className={`px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all ${
                  isPlaying && activeTrack === selectedAsset.id
                    ? 'bg-red-500 hover:bg-red-600 text-white shadow-lg'
                    : 'bg-brand-secondary hover:bg-brand-secondaryHover text-brand-primary shadow-glow-yellow'
                }`}
              >
                {isPlaying && activeTrack === selectedAsset.id ? (
                  <>
                    <Square className="w-4 h-4 fill-current" />
                    <span>Pause Audio</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>Play Sound & Dance</span>
                  </>
                )}
              </button>

              <span className="text-[11px] text-gray-400 font-mono">
                {isPlaying && activeTrack === selectedAsset.id ? '● Audio Active in Browser' : '○ Standby'}
              </span>
            </div>

          </div>

        </div>
      </div>

      {/* Grid of All Meme Sound & Dance Triggers */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-gray-500 uppercase tracking-wider px-1">
          <span>Tap Any Sound Effect / Dance to Play & Sync:</span>
          <span>{TRENDING_MEME_ASSETS.length} Meme FX Ready</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {TRENDING_MEME_ASSETS.map((asset) => {
            const isThisPlaying = isPlaying && activeTrack === asset.id;
            const isSelected = selectedAsset.id === asset.id;

            return (
              <button
                key={asset.id}
                onClick={() => handlePlayToggle(asset)}
                className={`p-3.5 rounded-2xl border text-left transition-all duration-200 flex flex-col justify-between group relative overflow-hidden ${
                  isThisPlaying
                    ? 'bg-purple-900 text-white border-purple-500 shadow-glow-accent scale-[1.02]'
                    : isSelected
                    ? 'bg-purple-50/70 border-brand-accent/50 text-gray-900'
                    : 'bg-gray-50/80 hover:bg-white hover:border-gray-300 text-gray-900 border-gray-200'
                }`}
              >
                {isThisPlaying && (
                  <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-brand-secondary animate-ping" />
                )}

                <div className="flex items-start justify-between gap-1 mb-2">
                  <span className="text-2xl">{asset.emoji}</span>
                  <span className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded ${
                    isThisPlaying ? 'bg-brand-secondary text-brand-primary' : 'bg-gray-200 text-gray-700'
                  }`}>
                    {asset.bpm}
                  </span>
                </div>

                <div>
                  <h4 className="font-bold text-xs font-heading leading-tight truncate">
                    {asset.name}
                  </h4>
                  <p className={`text-[10px] mt-0.5 truncate ${
                    isThisPlaying ? 'text-purple-200' : 'text-gray-500'
                  }`}>
                    {asset.danceMove || asset.tag}
                  </p>
                </div>

                <div className="mt-2.5 pt-2 border-t border-gray-200/40 flex items-center justify-between text-[10px] font-bold">
                  <span className={isThisPlaying ? 'text-brand-secondary' : 'text-brand-accent'}>
                    {isThisPlaying ? 'Playing...' : 'Play Sound'}
                  </span>
                  {isThisPlaying ? (
                    <Square className="w-3 h-3 fill-current text-brand-secondary" />
                  ) : (
                    <Play className="w-3 h-3 fill-current text-gray-400 group-hover:text-brand-accent" />
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

    </div>
  );
}
