import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Mail, Lock, User, ArrowRight, Sparkles } from 'lucide-react';

export default function AuthModal({ onNavigateToDashboard }) {
  const { authModal, setAuthModal, login, signup } = useApp();
  const [mode, setMode] = useState(authModal.mode || 'login'); // 'login' | 'signup'

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  });
  const [errors, setErrors] = useState({});

  if (!authModal.isOpen) return null;

  const handleClose = () => {
    setAuthModal({ isOpen: false, mode: 'login' });
    setErrors({});
  };

  const validate = () => {
    const errs = {};
    if (mode === 'signup' && !formData.name.trim()) {
      errs.name = 'Full name is required';
    }
    if (!formData.email.trim()) {
      errs.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errs.email = 'Please enter a valid email';
    }
    if (!formData.password) {
      errs.password = 'Password is required';
    } else if (formData.password.length < 4) {
      errs.password = 'Password must be at least 4 characters';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    if (mode === 'login') {
      login(formData.email, formData.password, formData.name);
    } else {
      signup(formData.name, formData.email, formData.password);
    }

    if (onNavigateToDashboard) {
      onNavigateToDashboard();
    }
  };

  const fillDemoUser = () => {
    setFormData({
      name: 'Alex Rivera',
      email: 'alex.rivera@growthmarketing.io',
      password: 'demoPassword123'
    });
    setErrors({});
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-md transition-opacity"
        onClick={handleClose}
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-elevated border border-gray-100 overflow-hidden z-10 animate-slide-up my-auto">
        {/* Header */}
        <div className="p-6 pb-4 bg-[#111111] text-white relative">
          <button
            onClick={handleClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-accent/30 text-purple-200 text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5 text-brand-secondary" />
            MEME MARKETING WORKSPACE
          </div>

          <h3 className="text-2xl font-bold font-heading">
            {mode === 'login' ? 'Welcome Back' : 'Create Your Account'}
          </h3>
          <p className="text-xs text-gray-400 mt-1 font-sans">
            {mode === 'login' 
              ? 'Access your saved campaigns, risk reports & analytics' 
              : 'Start building meme campaigns that drive actual business ROI'}
          </p>

          {/* Mode Switch Tabs */}
          <div className="grid grid-cols-2 mt-4 p-1 rounded-xl bg-white/10 text-xs font-semibold">
            <button
              type="button"
              onClick={() => { setMode('login'); setErrors({}); }}
              className={`py-2 rounded-lg transition-all ${
                mode === 'login' ? 'bg-white text-brand-primary shadow-sm' : 'text-gray-300 hover:text-white'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => { setMode('signup'); setErrors({}); }}
              className={`py-2 rounded-lg transition-all ${
                mode === 'signup' ? 'bg-white text-brand-primary shadow-sm' : 'text-gray-300 hover:text-white'
              }`}
            >
              Create Account
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {mode === 'signup' && (
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                Full Name
              </label>
              <div className="relative">
                <User className="absolute left-3.5 top-3.5 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="e.g. Alex Rivera"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className={`w-full pl-10 pr-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-brand-accent transition-all ${
                    errors.name ? 'border-brand-danger bg-red-50/30' : 'border-gray-200 bg-gray-50/50'
                  }`}
                />
              </div>
              {errors.name && <p className="text-xs text-brand-danger mt-1">{errors.name}</p>}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-3.5 w-4 h-4 text-gray-400" />
              <input
                type="email"
                placeholder="name@company.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className={`w-full pl-10 pr-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-brand-accent transition-all ${
                  errors.email ? 'border-brand-danger bg-red-50/30' : 'border-gray-200 bg-gray-50/50'
                }`}
              />
            </div>
            {errors.email && <p className="text-xs text-brand-danger mt-1">{errors.email}</p>}
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-gray-400" />
              <input
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className={`w-full pl-10 pr-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-brand-accent transition-all ${
                  errors.password ? 'border-brand-danger bg-red-50/30' : 'border-gray-200 bg-gray-50/50'
                }`}
              />
            </div>
            {errors.password && <p className="text-xs text-brand-danger mt-1">{errors.password}</p>}
          </div>

          {/* 1-Click Demo Auto-fill Helper */}
          <button
            type="button"
            onClick={fillDemoUser}
            className="w-full py-2 px-3 rounded-xl bg-purple-50 hover:bg-purple-100 text-brand-accent text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-brand-accent" />
            Auto-fill Demo Credentials
          </button>

          {/* Submit */}
          <button
            type="submit"
            className="w-full py-3.5 px-6 rounded-2xl bg-brand-primary hover:bg-black text-white font-bold text-sm shadow-md hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 mt-2"
          >
            <span>{mode === 'login' ? 'Sign In to Dashboard' : 'Create Free Account'}</span>
            <ArrowRight className="w-4 h-4 text-brand-secondary" />
          </button>

          <p className="text-[11px] text-gray-400 text-center pt-1">
            Demo prototype session • Data stored locally in browser
          </p>
        </form>
      </div>
    </div>
  );
}
