import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Menu, X, Sparkles, User, LogOut, LayoutDashboard, PlusCircle, 
  Crown, Compass, Library, HelpCircle, Tag, ShieldCheck 
} from 'lucide-react';

export default function Navbar({ activePage, setActivePage }) {
  const { user, isPro, logout, setAuthModal, openCheckout } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'why-meme-marketing', label: 'Why Meme Marketing' },
    { id: 'brand-vault', label: 'Brand Vault' },
    { id: 'meme-library', label: 'Meme Library' },
    { id: 'campaign-builder', label: 'Create Campaign', isAction: true },
    { id: 'pricing', label: 'Pricing' },
    { id: 'about', label: 'About' },
  ];

  const handleNavClick = (pageId) => {
    setActivePage(pageId);
    setMobileMenuOpen(false);
    setUserDropdownOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-[#F8F9FA]/90 backdrop-blur-md border-b border-gray-200/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleNavClick('home')}
              className="flex items-center gap-2.5 text-left group focus:outline-none"
            >
              <div className="w-10 h-10 rounded-2xl bg-brand-primary text-white flex items-center justify-center font-black font-heading text-xl shadow-md group-hover:bg-brand-accent transition-colors">
                M<span className="text-brand-secondary text-sm ml-0.5">²</span>
              </div>
              <div>
                <span className="text-xl sm:text-2xl font-black font-heading tracking-tight text-brand-primary group-hover:text-brand-accent transition-colors block leading-none">
                  MEMEVERTISING
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest text-brand-subtle block mt-0.5">
                  Meme Marketing Platform
                </span>
              </div>
            </button>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-1.5">
            {navLinks.map((link) => {
              const isActive = activePage === link.id;
              if (link.isAction) {
                return (
                  <button
                    key={link.id}
                    onClick={() => handleNavClick(link.id)}
                    className={`ml-1 px-4 py-2 rounded-full font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 ${
                      isActive
                        ? 'bg-brand-accent text-white shadow-glow-accent'
                        : 'bg-brand-primary text-white hover:bg-brand-accent hover:shadow-glow-accent'
                    }`}
                  >
                    <PlusCircle className="w-3.5 h-3.5 text-brand-secondary" />
                    {link.label}
                  </button>
                );
              }
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold tracking-wide transition-all ${
                    isActive
                      ? 'text-brand-accent bg-purple-50 font-bold'
                      : 'text-gray-700 hover:text-black hover:bg-gray-100/70'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* Right Action Cluster */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Pro Status Badge */}
            {isPro ? (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-purple-900 to-brand-primary text-white text-xs font-bold shadow-sm border border-purple-400/30">
                <Crown className="w-3.5 h-3.5 text-brand-secondary fill-current" />
                <span className="tracking-wide">PRO ACTIVE</span>
              </div>
            ) : (
              <button
                onClick={openCheckout}
                className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-brand-secondary hover:bg-brand-secondaryHover text-brand-primary text-xs font-black tracking-wider shadow-sm hover:scale-[1.03] active:scale-[0.98] transition-all"
              >
                <Sparkles className="w-3.5 h-3.5" />
                GET PRO
              </button>
            )}

            {/* User Login / Profile */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2.5 p-1.5 pr-3 rounded-full border border-gray-200 bg-white hover:border-gray-300 hover:shadow-sm transition-all text-left"
                >
                  <div className="w-8 h-8 rounded-full bg-brand-accent text-white flex items-center justify-center text-xs font-bold">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="hidden md:block">
                    <p className="text-xs font-bold text-gray-900 leading-none">{user.name}</p>
                    <p className="text-[10px] text-gray-500 mt-0.5">{isPro ? 'Pro Member' : 'Free Tier'}</p>
                  </div>
                </button>

                {/* Dropdown Menu */}
                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-elevated border border-gray-100 py-2 z-50 animate-slide-up">
                    <div className="px-4 py-2 border-b border-gray-100">
                      <p className="text-xs font-bold text-gray-900 truncate">{user.name}</p>
                      <p className="text-[11px] text-gray-500 truncate">{user.email}</p>
                      <span className="inline-block mt-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-brand-accent">
                        {isPro ? 'Pro Strategy Account' : 'Free Explorer Account'}
                      </span>
                    </div>

                    <button
                      onClick={() => handleNavClick('dashboard')}
                      className="w-full text-left px-4 py-2.5 text-xs font-semibold text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                    >
                      <LayoutDashboard className="w-4 h-4 text-brand-accent" />
                      Campaign Dashboard
                    </button>

                    <button
                      onClick={() => handleNavClick('campaign-builder')}
                      className="w-full text-left px-4 py-2.5 text-xs font-semibold text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                    >
                      <PlusCircle className="w-4 h-4 text-brand-secondary" />
                      Create New Campaign
                    </button>

                    <button
                      onClick={() => {
                        logout();
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2.5 text-xs font-semibold text-brand-danger hover:bg-red-50 flex items-center gap-2 border-t border-gray-100 mt-1"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setAuthModal({ isOpen: true, mode: 'login' })}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-gray-700 hover:text-black hover:bg-gray-100 transition-colors"
                >
                  Log In
                </button>
                <button
                  onClick={() => setAuthModal({ isOpen: true, mode: 'signup' })}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-[#111111] text-white hover:bg-brand-accent transition-colors shadow-sm"
                >
                  Sign Up
                </button>
              </div>
            )}
          </div>

          {/* Mobile Hamburger Toggle */}
          <div className="flex items-center gap-2 xl:hidden">
            {isPro && (
              <span className="px-2 py-1 rounded-full bg-brand-primary text-brand-secondary text-[10px] font-black">
                PRO
              </span>
            )}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-2xl bg-white border border-gray-200 text-gray-800 hover:bg-gray-50 transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-white border-b border-gray-200 px-4 pt-3 pb-6 space-y-2 shadow-elevated animate-slide-up">
          <div className="grid grid-cols-1 gap-1">
            {navLinks.map((link) => {
              const isActive = activePage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`w-full text-left px-4 py-3 rounded-xl text-sm font-bold transition-colors flex items-center justify-between ${
                    isActive
                      ? 'bg-purple-50 text-brand-accent'
                      : 'text-gray-800 hover:bg-gray-100'
                  }`}
                >
                  <span>{link.label}</span>
                  {link.isAction && (
                    <span className="px-2 py-0.5 rounded-full bg-brand-accent text-white text-[10px] font-extrabold uppercase">
                      New
                    </span>
                  )}
                </button>
              );
            })}

            {user ? (
              <>
                <button
                  onClick={() => handleNavClick('dashboard')}
                  className="w-full text-left px-4 py-3 rounded-xl text-sm font-bold text-gray-800 hover:bg-gray-100 flex items-center gap-2"
                >
                  <LayoutDashboard className="w-4 h-4 text-brand-accent" />
                  Dashboard ({user.name})
                </button>
                <button
                  onClick={() => {
                    logout();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-left px-4 py-3 rounded-xl text-sm font-bold text-brand-danger hover:bg-red-50 flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </>
            ) : (
              <div className="pt-2 grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    setAuthModal({ isOpen: true, mode: 'login' });
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-3 rounded-xl text-xs font-bold text-center border border-gray-200 text-gray-800 hover:bg-gray-50"
                >
                  Log In
                </button>
                <button
                  onClick={() => {
                    setAuthModal({ isOpen: true, mode: 'signup' });
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-3 rounded-xl text-xs font-bold text-center bg-brand-primary text-white"
                >
                  Sign Up
                </button>
              </div>
            )}

            {!isPro && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  openCheckout();
                }}
                className="w-full mt-3 py-3.5 px-4 rounded-xl bg-brand-secondary text-brand-primary font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm"
              >
                <Sparkles className="w-4 h-4" />
                Unlock Pro (₹999/mo)
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
