import React, { useState } from 'react';
import { CheckCircle2, Send, ShieldCheck } from 'lucide-react';
import { QUESTIONS, saveLocalResponse, submitRemoteResponse } from '../utils/feedbackStorage';

export default function FeedbackPanel({ campaignName = 'Featured Meme Campaign' }) {
  const [answers, setAnswers] = useState({});
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (Object.keys(answers).length !== QUESTIONS.length || submitting) return;
    setSubmitting(true);
    const response = { campaign: campaignName, respondentEmail: email.trim(), ...answers };
    saveLocalResponse(response);
    await submitRemoteResponse(response);
    setSubmitting(false);
    setSubmitted(true);
  };

  if (submitted) return (
    <div className="rounded-3xl bg-white border border-emerald-200 p-8 text-center shadow-card">
      <CheckCircle2 className="w-11 h-11 text-emerald-600 mx-auto mb-3" />
      <h3 className="text-xl font-black font-heading">Your response has been recorded</h3>
      <p className="text-sm text-gray-500 mt-2">Thank you for taking a few seconds to help with this research.</p>
      <button onClick={() => { setAnswers({}); setEmail(''); setSubmitted(false); }} className="mt-5 text-sm font-bold text-brand-accent">Submit another response</button>
    </div>
  );

  return (
    <form onSubmit={submit} className="rounded-3xl bg-white border border-gray-200 shadow-card overflow-hidden">
      <div className="bg-brand-primary text-white p-6 sm:p-8">
        <span className="text-[10px] uppercase tracking-[0.22em] font-black text-brand-secondary">MEMEVERTISING • FEEDBACK</span>
        <h3 className="text-2xl sm:text-3xl font-black font-heading mt-2">Help us understand the meme.</h3>
        <p className="text-sm text-gray-300 mt-2">Three quick questions. Your response is stored for campaign analysis.</p>
      </div>
      <div className="p-6 sm:p-8 space-y-7">
        {QUESTIONS.map((q, index) => (
          <fieldset key={q.id} className="space-y-3">
            <legend className="text-sm font-bold text-gray-900"><span className="text-brand-accent mr-2">{index + 1}.</span>{q.label}</legend>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {q.options.map((option) => (
                <label key={option} className={`cursor-pointer rounded-xl border px-4 py-3 text-sm font-semibold transition ${answers[q.id] === option ? 'border-brand-accent bg-purple-50 text-brand-accent' : 'border-gray-200 hover:border-gray-400'}`}>
                  <input className="sr-only" type="radio" name={q.id} value={option} checked={answers[q.id] === option} onChange={() => setAnswers(a => ({ ...a, [q.id]: option }))} />
                  {option}
                </label>
              ))}
            </div>
          </fieldset>
        ))}
        <div>
          <label className="text-sm font-bold text-gray-900" htmlFor="feedback-email">Email <span className="font-normal text-gray-400">(optional)</span></label>
          <input id="feedback-email" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className="mt-2 w-full rounded-xl border border-gray-200 px-4 py-3 text-sm outline-none focus:border-brand-accent" />
        </div>
        <div className="flex items-center gap-2 text-[11px] text-gray-500"><ShieldCheck className="w-4 h-4 text-emerald-600" /> Your response is used for aggregated campaign analysis.</div>
        <button type="submit" disabled={Object.keys(answers).length !== QUESTIONS.length || submitting} className="w-full py-3.5 rounded-xl bg-brand-primary text-white font-black flex items-center justify-center gap-2 disabled:opacity-40 hover:bg-brand-accent transition">
          <Send className="w-4 h-4" /> {submitting ? 'Submitting…' : 'Submit Feedback'}
        </button>
      </div>
    </form>
  );
}
