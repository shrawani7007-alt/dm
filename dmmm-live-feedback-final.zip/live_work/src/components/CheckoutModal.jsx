import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, Sparkles, CheckCircle2, ShieldCheck, QrCode, CreditCard, 
  Copy, Check, Clock, Smartphone, Zap, ArrowRight, Lock 
} from 'lucide-react';

export default function CheckoutModal() {
  const { showCheckoutModal, closeCheckout, unlockPro, addToast } = useApp();
  const [billingCycle, setBillingCycle] = useState('monthly'); // 'monthly' | 'annual'
  const [paymentMethod, setPaymentMethod] = useState('upi'); // 'upi' | 'card'
  const [isProcessing, setIsProcessing] = useState(false);
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [countdown, setCountdown] = useState(600); // 10 minutes

  const priceAmount = billingCycle === 'monthly' ? 999 : 799;
  const totalPrice = billingCycle === 'monthly' ? 999 : 9588;
  const upiId = 'memevertising.pro@okaxis';

  // Live countdown for QR code session
  useEffect(() => {
    if (!showCheckoutModal) return;
    const timer = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : 600));
    }, 1000);
    return () => clearInterval(timer);
  }, [showCheckoutModal]);

  if (!showCheckoutModal) return null;

  const minutes = Math.floor(countdown / 60).toString().padStart(2, '0');
  const seconds = (countdown % 60).toString().padStart(2, '0');

  const handleCopyUpi = () => {
    navigator.clipboard?.writeText(upiId);
    setCopiedUpi(true);
    addToast('UPI ID copied to clipboard: ' + upiId, 'info');
    setTimeout(() => setCopiedUpi(false), 2500);
  };

  const handleSimulatePayment = (methodUsed = 'UPI QR') => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      unlockPro();
      addToast(`🎉 Payment of ₹${totalPrice.toLocaleString('en-IN')} confirmed via ${methodUsed}! PRO Unlocked.`, 'success');
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/70 backdrop-blur-md transition-opacity"
        onClick={closeCheckout}
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-elevated border border-gray-100 overflow-hidden z-10 animate-slide-up my-auto max-h-[94vh] flex flex-col">
        
        {/* Modal Header */}
        <div className="p-6 bg-[#111111] text-white relative flex-shrink-0">
          <button
            onClick={closeCheckout}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 rounded-full bg-brand-secondary text-brand-primary text-[10px] font-black uppercase tracking-wider">
              OFFICIAL PRO UPGRADE
            </span>
            <span className="text-xs text-gray-400 font-mono">Instant Activation</span>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
            <div>
              <h2 className="text-2xl sm:text-3xl font-black font-heading text-white">
                MEMEVERTISING PRO
              </h2>
              <p className="text-xs text-gray-300 mt-0.5">
                Unlock M² Scoring, Pre-Flight Risk Audits, ROI Lab & PDF Reports
              </p>
            </div>

            <div className="text-left sm:text-right">
              <span className="text-3xl font-black font-heading text-brand-secondary">
                ₹{totalPrice.toLocaleString('en-IN')}
              </span>
              <span className="text-[11px] text-gray-400 block">
                {billingCycle === 'annual' ? 'Billed Annually' : 'Per Month'}
              </span>
            </div>
          </div>

          {/* Billing Cycle Switch */}
          <div className="mt-4 grid grid-cols-2 p-1 rounded-xl bg-white/10 text-xs font-semibold">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`py-2 rounded-lg transition-all ${
                billingCycle === 'monthly' ? 'bg-white text-brand-primary shadow-sm font-bold' : 'text-gray-300 hover:text-white'
              }`}
            >
              Monthly (₹999/mo)
            </button>
            <button
              onClick={() => setBillingCycle('annual')}
              className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                billingCycle === 'annual' ? 'bg-white text-brand-primary shadow-sm font-bold' : 'text-gray-300 hover:text-white'
              }`}
            >
              <span>Annual (₹799/mo)</span>
              <span className="text-[10px] bg-brand-secondary text-brand-primary px-1.5 py-0.2 rounded-full font-bold">Save 20%</span>
            </button>
          </div>
        </div>

        {/* Payment Method Tabs */}
        <div className="p-4 border-b border-gray-100 bg-gray-50 flex items-center justify-center gap-2 text-xs font-bold flex-shrink-0">
          <button
            onClick={() => setPaymentMethod('upi')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl transition-all ${
              paymentMethod === 'upi'
                ? 'bg-brand-accent text-white shadow-sm'
                : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-100'
            }`}
          >
            <QrCode className="w-4 h-4 text-brand-secondary" />
            <span>UPI QR Code (Instant Scan)</span>
          </button>

          <button
            onClick={() => setPaymentMethod('card')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl transition-all ${
              paymentMethod === 'card'
                ? 'bg-brand-accent text-white shadow-sm'
                : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-100'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Card / 1-Click Sandbox</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          
          {/* TAB 1: UPI QR CODE PAYMENT PROCESS (Requested by user) */}
          {paymentMethod === 'upi' && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex flex-col sm:flex-row items-center gap-6 p-5 rounded-3xl bg-purple-50/60 border border-purple-100">
                
                {/* Generated High-Resolution UPI QR Code */}
                <div className="relative p-3 rounded-2xl bg-white shadow-card border-2 border-brand-accent/30 flex-shrink-0 text-center">
                  <div className="w-44 h-44 mx-auto relative flex items-center justify-center bg-white">
                    {/* SVG Vector QR Code with UPI Branding */}
                    <svg viewBox="0 0 200 200" className="w-full h-full">
                      {/* Corner Position Detection Patterns */}
                      <rect x="10" y="10" width="50" height="50" fill="#111111" rx="8" />
                      <rect x="20" y="20" width="30" height="30" fill="#ffffff" rx="4" />
                      <rect x="28" y="28" width="14" height="14" fill="#7C3AED" rx="2" />

                      <rect x="140" y="10" width="50" height="50" fill="#111111" rx="8" />
                      <rect x="150" y="20" width="30" height="30" fill="#ffffff" rx="4" />
                      <rect x="158" y="28" width="14" height="14" fill="#7C3AED" rx="2" />

                      <rect x="10" y="140" width="50" height="50" fill="#111111" rx="8" />
                      <rect x="20" y="150" width="30" height="30" fill="#ffffff" rx="4" />
                      <rect x="28" y="158" width="14" height="14" fill="#7C3AED" rx="2" />

                      {/* Dense QR Pattern Grid Elements */}
                      <rect x="70" y="15" width="10" height="10" fill="#111" />
                      <rect x="90" y="15" width="10" height="10" fill="#7C3AED" />
                      <rect x="110" y="15" width="10" height="10" fill="#111" />
                      
                      <rect x="70" y="35" width="20" height="10" fill="#111" />
                      <rect x="100" y="35" width="10" height="20" fill="#111" />
                      <rect x="120" y="35" width="10" height="10" fill="#7C3AED" />

                      <rect x="15" y="70" width="10" height="20" fill="#111" />
                      <rect x="35" y="70" width="20" height="10" fill="#7C3AED" />
                      <rect x="15" y="100" width="15" height="10" fill="#111" />
                      <rect x="40" y="95" width="10" height="20" fill="#111" />

                      {/* Middle alignment & QR data dots */}
                      <rect x="70" y="70" width="60" height="60" fill="#F8F9FA" rx="8" />
                      <rect x="75" y="75" width="50" height="50" fill="#111111" rx="6" />
                      <text x="100" y="105" fill="#FACC15" fontSize="16" fontWeight="bold" textAnchor="middle" fontFamily="sans-serif">M²</text>
                      <text x="100" y="118" fill="#ffffff" fontSize="8" fontWeight="bold" textAnchor="middle" fontFamily="sans-serif">UPI PAY</text>

                      {/* Bottom data dots */}
                      <rect x="70" y="140" width="10" height="20" fill="#111" />
                      <rect x="90" y="150" width="20" height="10" fill="#7C3AED" />
                      <rect x="120" y="140" width="10" height="10" fill="#111" />
                      <rect x="140" y="140" width="10" height="20" fill="#7C3AED" />
                      <rect x="160" y="150" width="20" height="10" fill="#111" />
                      <rect x="150" y="170" width="30" height="10" fill="#111" />
                      <rect x="80" y="175" width="40" height="10" fill="#7C3AED" />
                    </svg>

                    {/* Scan indicator line */}
                    <div className="absolute inset-x-2 top-0 h-0.5 bg-brand-accent shadow-glow-accent animate-pulse" />
                  </div>

                  <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest block mt-1.5 font-mono">
                    Scan With Any UPI App
                  </span>
                </div>

                {/* QR Instructions & Actions */}
                <div className="space-y-3 flex-1 text-left">
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-700">
                    <Clock className="w-4 h-4 text-brand-warning" />
                    <span>Session valid for: </span>
                    <span className="font-mono text-brand-primary bg-white px-2 py-0.5 rounded border font-bold">
                      {minutes}:{seconds}
                    </span>
                  </div>

                  <div className="p-3 rounded-2xl bg-white border border-gray-200 space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block">
                      Payee VPA / UPI ID
                    </span>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-mono font-bold text-gray-900 select-all">
                        {upiId}
                      </span>
                      <button
                        onClick={handleCopyUpi}
                        className="p-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold flex items-center gap-1 transition-colors"
                        title="Copy UPI ID"
                      >
                        {copiedUpi ? <Check className="w-3.5 h-3.5 text-brand-success" /> : <Copy className="w-3.5 h-3.5" />}
                        <span className="text-[10px]">{copiedUpi ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Supported Payment App Icons */}
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block">
                      Supported Apps:
                    </span>
                    <div className="flex items-center gap-1.5 flex-wrap text-[11px] font-semibold text-gray-600">
                      <span className="px-2 py-0.5 rounded-md bg-white border border-gray-200">GPay</span>
                      <span className="px-2 py-0.5 rounded-md bg-white border border-gray-200">PhonePe</span>
                      <span className="px-2 py-0.5 rounded-md bg-white border border-gray-200">Paytm</span>
                      <span className="px-2 py-0.5 rounded-md bg-white border border-gray-200">CRED</span>
                      <span className="px-2 py-0.5 rounded-md bg-white border border-gray-200">BHIM</span>
                    </div>
                  </div>
                </div>

              </div>

              {/* Complete UPI Payment Action Button */}
              <button
                onClick={() => handleSimulatePayment('UPI QR Code')}
                disabled={isProcessing}
                className="w-full py-4 px-6 rounded-2xl bg-brand-accent hover:bg-brand-accentHover text-white font-bold text-base shadow-glow-accent hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 disabled:opacity-75"
              >
                {isProcessing ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Verifying UPI Payment...
                  </span>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-brand-secondary" />
                    <span>I Have Paid — Verify & Unlock Pro</span>
                  </>
                )}
              </button>
            </div>
          )}

          {/* TAB 2: FAST SANDBOX / CARD */}
          {paymentMethod === 'card' && (
            <div className="space-y-4 animate-fade-in">
              <div className="p-4 rounded-2xl bg-gray-50 border border-gray-200 space-y-3">
                <span className="text-xs font-bold uppercase text-gray-700 tracking-wider block">
                  Simulated Card Payment
                </span>
                <input
                  type="text"
                  readOnly
                  value="4242 •••• •••• 4242 (Demo Visa)"
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-300 bg-white text-xs font-mono font-bold text-gray-700"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    readOnly
                    value="12/28"
                    className="px-3 py-2 rounded-xl border border-gray-300 bg-white text-xs font-mono text-gray-700"
                  />
                  <input
                    type="text"
                    readOnly
                    value="CVC: 999"
                    className="px-3 py-2 rounded-xl border border-gray-300 bg-white text-xs font-mono text-gray-700"
                  />
                </div>
              </div>

              <button
                onClick={() => handleSimulatePayment('Card Sandbox')}
                disabled={isProcessing}
                className="w-full py-4 px-6 rounded-2xl bg-[#111111] hover:bg-black text-white font-bold text-base shadow-elevated hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 disabled:opacity-75"
              >
                {isProcessing ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Processing Payment...
                  </span>
                ) : (
                  <>
                    <CreditCard className="w-5 h-5 text-brand-secondary" />
                    <span>Simulate Payment (₹{totalPrice.toLocaleString('en-IN')})</span>
                  </>
                )}
              </button>
            </div>
          )}

          {/* Sandbox reassurance footnote */}
          <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200/80 flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-brand-warning flex-shrink-0 mt-0.5" />
            <div className="text-[11px] text-amber-900 leading-relaxed font-sans">
              <span className="font-bold">Sandbox Environment: </span>
              Both the UPI QR code scan and Card options simulate verified instant transactions without debiting real bank accounts. Pro status is saved to local session storage.
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
