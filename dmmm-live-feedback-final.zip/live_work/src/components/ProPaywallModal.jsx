import React from 'react';
import { useApp } from '../context/AppContext';
import { X, Sparkles, Check, ShieldAlert, BarChart3, Sliders, Zap, Download } from 'lucide-react';

export default function ProPaywallModal() {
  const { showProModal, closeProPaywall, openCheckout } = useApp();

  if (!showProModal) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Dark backdrop with blur */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-md transition-opacity"
        onClick={closeProPaywall}
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-elevated border border-gray-100 overflow-hidden z-10 animate-slide-up my-auto">
        {/* Top decorative header with brand badge */}
        <div className="relative bg-gradient-to-br from-[#111111] via-[#1a1226] to-[#7C3AED] p-8 text-white text-center">
          <button
            onClick={closeProPaywall}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-secondary text-brand-primary text-xs font-bold uppercase tracking-wider mb-4 shadow-glow-yellow">
            <Sparkles className="w-3.5 h-3.5 fill-current" />
            PRO EVALUATION SUITE
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white mb-2 font-heading">
            YOUR CAMPAIGN IS READY.
          </h2>
          <p className="text-xl sm:text-2xl font-semibold text-purple-200 font-heading">
            But is it actually marketable?
          </p>

          <p className="mt-3 text-sm text-gray-300 max-w-lg mx-auto font-sans">
            AI can generate a punchy meme. MEMEVERTISING evaluates whether that meme will convert attention into bottom-line revenue or blow up in brand risk.
          </p>
        </div>

        {/* Pro features list with peek preview */}
        <div className="p-6 sm:p-8 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-purple-50/60 border border-purple-100">
              <div className="p-2 rounded-xl bg-brand-accent text-white mt-0.5">
                <BarChart3 className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-900">M² Marketing Score</h4>
                <p className="text-xs text-gray-600 mt-0.5">6-dimensional scoring: Attention, Relatability, Brand Fit & Clarity.</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-amber-50/60 border border-amber-100">
              <div className="p-2 rounded-xl bg-brand-warning text-white mt-0.5">
                <ShieldAlert className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-900">Meme Risk Check</h4>
                <p className="text-xs text-gray-600 mt-0.5">Prevent PR disasters and the "remembered meme, forgot brand" trap.</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-emerald-50/60 border border-emerald-100">
              <div className="p-2 rounded-xl bg-brand-success text-white mt-0.5">
                <Sliders className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-900">Interactive ROI Lab</h4>
                <p className="text-xs text-gray-600 mt-0.5">Simulate reach, CTR, conversion rates, and projected revenue return.</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-blue-50/60 border border-blue-100">
              <div className="p-2 rounded-xl bg-blue-600 text-white mt-0.5">
                <Zap className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-900">A/B Testing Simulator</h4>
                <p className="text-xs text-gray-600 mt-0.5">Compare meme performance vs traditional ad benchmarks side-by-side.</p>
              </div>
            </div>
          </div>

          {/* Blurred Teaser preview */}
          <div className="relative rounded-2xl p-4 bg-gray-50 border border-gray-200 overflow-hidden">
            <div className="filter blur-[3px] select-none pointer-events-none opacity-50 space-y-2 text-xs">
              <div className="flex justify-between font-bold text-gray-700">
                <span>Overall M² Meme Score: 8.2 / 10</span>
                <span className="text-emerald-600">Risk: LOW</span>
              </div>
              <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                <div className="bg-purple-600 h-full w-[82%]" />
              </div>
              <p className="text-gray-500">Projected Campaign ROI: +1635% vs +125% baseline traditional banner.</p>
            </div>
            <div className="absolute inset-0 flex items-center justify-center bg-white/40">
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-gray-900 text-white shadow-sm">
                Pro Metrics Locked
              </span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
            <button
              onClick={openCheckout}
              className="w-full sm:flex-1 py-4 px-6 rounded-2xl bg-brand-accent hover:bg-brand-accentHover text-white font-bold text-base shadow-glow-accent hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              <Sparkles className="w-5 h-5 text-brand-secondary" />
              Unlock Pro — ₹999/mo
            </button>
            <button
              onClick={closeProPaywall}
              className="w-full sm:w-auto py-4 px-6 rounded-2xl border border-gray-200 hover:bg-gray-100 text-gray-700 font-semibold text-sm transition-colors"
            >
              Continue with Free Preview
            </button>
          </div>

          <p className="text-center text-xs text-gray-500">
            Instant unlock for this session • Demo checkout (no actual credit card required)
          </p>
        </div>
      </div>
    </div>
  );
}
