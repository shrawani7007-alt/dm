import React from 'react';
import { useApp } from '../context/AppContext';
import { BarChart3, Sparkles, Lock, Info, CheckCircle2, TrendingUp, AlertTriangle } from 'lucide-react';

export default function M2ScoreCard({ campaign, locked }) {
  const { isPro, openProPaywall } = useApp();
  const isLocked = locked ?? !isPro;

  const scoreData = campaign?.m2Score || {
    overall: 8.2,
    attention: 8.0,
    relatability: 9.0,
    brandFit: 8.0,
    trendRelevance: 7.0,
    shareability: 8.0,
    messageClarity: 9.0,
    insights: [
      'High organic sharing velocity expected among target demographic.',
      'Product punchline resolves cognitive dissonance within 3 seconds.',
      'Low audience fatigue risk due to situational premise.'
    ]
  };

  const dimensions = [
    { label: 'Attention', score: scoreData.attention, desc: 'Initial hook power & feed stop-rate' },
    { label: 'Relatability', score: scoreData.relatability, desc: 'Emotional recognition of target dilemma' },
    { label: 'Brand Fit', score: scoreData.brandFit, desc: 'Product naturally resolves the tension' },
    { label: 'Trend Relevance', score: scoreData.trendRelevance, desc: 'Cultural lifespan & format currency' },
    { label: 'Shareability', score: scoreData.shareability, desc: 'Peer tag & group chat transmission probability' },
    { label: 'Message Clarity', score: scoreData.messageClarity, desc: 'Prevents "remembering joke, forgetting brand"' },
  ];

  return (
    <div className="relative bg-white rounded-3xl p-6 sm:p-8 shadow-card border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-gray-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-purple-100 text-brand-accent">
              <BarChart3 className="w-5 h-5" />
            </span>
            <h3 className="text-xl sm:text-2xl font-bold font-heading text-brand-primary">
              M² Meme Marketing Score
            </h3>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Algorithmic marketing viability & virality-to-conversion evaluation
          </p>
        </div>

        {/* Overall Score Dial */}
        <div className="flex items-center gap-3 bg-purple-50/80 px-4 py-2.5 rounded-2xl border border-purple-100 self-start sm:self-auto">
          <div className="text-right">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 block">Overall Viability</span>
            <span className="text-2xl sm:text-3xl font-black font-heading text-brand-accent">
              {scoreData.overall}
            </span>
            <span className="text-xs font-semibold text-gray-400"> / 10</span>
          </div>
          <div className="w-10 h-10 rounded-full bg-brand-accent text-brand-secondary flex items-center justify-center font-bold text-xs shadow-glow-accent">
            M²
          </div>
        </div>
      </div>

      {/* Main Content Area (Blurred if locked) */}
      <div className={isLocked ? 'filter blur-sm select-none pointer-events-none opacity-40 mt-6' : 'mt-6'}>
        {/* Dimension Bars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
          {dimensions.map((dim, idx) => {
            const percentage = (dim.score / 10) * 100;
            return (
              <div key={idx} className="p-4 rounded-2xl bg-gray-50/70 border border-gray-100 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-gray-900 text-sm">{dim.label}</span>
                    <span className="block text-[11px] text-gray-500">{dim.desc}</span>
                  </div>
                  <span className="font-black font-heading text-base text-brand-accent">
                    {dim.score} <span className="text-xs font-normal text-gray-400">/ 10</span>
                  </span>
                </div>
                <div className="w-full bg-gray-200 h-2.5 rounded-full overflow-hidden">
                  <div 
                    className="h-full rounded-full bg-gradient-to-r from-brand-accent to-purple-500 transition-all duration-700"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Qualitative Insights */}
        <div className="mt-6 p-4 sm:p-5 rounded-2xl bg-purple-50/60 border border-purple-100 space-y-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-purple-900 flex items-center gap-1.5 font-heading">
            <Sparkles className="w-4 h-4 text-brand-accent" />
            Strategic Campaign Insights
          </h4>
          <ul className="space-y-1.5 text-xs text-gray-700 font-sans">
            {(scoreData.insights || []).map((insight, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-brand-success flex-shrink-0 mt-0.5" />
                <span>{insight}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Disclaimer as explicitly required by prompt */}
        <div className="mt-4 flex items-center gap-2 text-[11px] text-gray-400 bg-gray-50 p-2.5 rounded-xl border border-gray-100">
          <Info className="w-4 h-4 flex-shrink-0 text-gray-400" />
          <span>
            <strong>Marketing Notice:</strong> The M² Score is an evaluative predictive model. It does not claim or guarantee actual market performance, sales conversions, or platform algorithm reach.
          </span>
        </div>
      </div>

      {/* Locked Overlay for Free Users */}
      {isLocked && (
        <div className="absolute inset-0 bg-white/60 backdrop-blur-[2px] flex flex-col items-center justify-center p-6 text-center z-10">
          <div className="w-12 h-12 rounded-2xl bg-[#111111] text-brand-secondary flex items-center justify-center mb-3 shadow-md">
            <Lock className="w-6 h-6" />
          </div>
          <h4 className="text-lg sm:text-xl font-extrabold font-heading text-brand-primary">
            M² Score & Deep Dimension Analytics Locked
          </h4>
          <p className="text-xs text-gray-600 max-w-sm mt-1 mb-4">
            Evaluate shareability, relatability, product attribution, and message clarity before launching.
          </p>
          <button
            onClick={openProPaywall}
            className="px-6 py-3 rounded-xl bg-brand-accent hover:bg-brand-accentHover text-white font-bold text-xs uppercase tracking-wider shadow-glow-accent hover:scale-105 transition-all flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-brand-secondary" />
            Unlock Pro Evaluation Suite
          </button>
        </div>
      )}
    </div>
  );
}
