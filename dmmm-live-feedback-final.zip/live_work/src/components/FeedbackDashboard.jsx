import React, { useEffect, useMemo, useState } from 'react';
import { BarChart3, Download, RefreshCw, Users, Mail, Database, Clock3 } from 'lucide-react';
import { QUESTIONS, getResponses, getRemoteResponses, getRemoteVisits, exportResponses } from '../utils/feedbackStorage';
import { FEEDBACK_WEB_APP_URL, FEEDBACK_OWNER_EMAIL } from '../utils/feedbackConfig';

export default function FeedbackDashboard() {
  const [responses, setResponses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [source, setSource] = useState('local');
  const [visits, setVisits] = useState([]);

  const refresh = async () => {
    setLoading(true);
    const [remote, remoteVisits] = await Promise.all([getRemoteResponses(), getRemoteVisits()]);
    if (remote.configured && !remote.error) {
      setResponses(remote.responses);
      setSource('google-sheet');
    } else {
      setResponses(getResponses());
      setSource('browser');
    }
    if (remoteVisits.configured && !remoteVisits.error) setVisits(remoteVisits.visits);
    setLoading(false);
  };

  useEffect(() => {
    refresh();
    const timer = setInterval(refresh, 10000);
    return () => clearInterval(timer);
  }, []);

  const distribution = useMemo(() => QUESTIONS.map(q => ({ ...q, counts: q.options.map(o => responses.filter(r => r[q.id] === o).length) })), [responses]);
  const yesPct = responses.length ? Math.round(responses.filter(r => r.purchaseInterest === 'Yes').length / responses.length * 100) : 0;
  const uniqueVisitors = new Set(visits.map(v => v.visitorId).filter(Boolean)).size;
  const recentVisitors = visits.slice(0, 12);

  return (
    <section className="mt-10 rounded-3xl bg-white border border-gray-200 shadow-card overflow-hidden">
      <div className="bg-brand-primary text-white p-6 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div>
            <span className="text-[10px] uppercase tracking-[0.22em] font-black text-brand-secondary">FEEDBACK CENTER</span>
            <h2 className="text-2xl sm:text-3xl font-black font-heading mt-2">User Feedback & Analysis</h2>
            <p className="text-sm text-gray-300 mt-1">Google-Form-style collection with campaign-level analysis.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={refresh} className="px-3 py-2 rounded-xl bg-white/10 border border-white/15 text-xs font-bold flex items-center gap-2"><RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Refresh</button>
            <button onClick={() => exportResponses(responses)} className="px-3 py-2 rounded-xl bg-brand-secondary text-brand-primary text-xs font-bold flex items-center gap-2"><Download className="w-4 h-4"/> Export</button>
          </div>
        </div>
      </div>

      <div className="p-6 sm:p-8">
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-7">
          <Metric icon={Users} value={responses.length} label="Total responses" />
          <Metric icon={BarChart3} value={`${yesPct}%`} label="Purchase interest" />
          <Metric icon={Users} value={visits.length} label="Website views" />
          <Metric icon={Database} value={uniqueVisitors} label="Unique visitors" />
          <Metric icon={Mail} value="Live" label={`Alerts → ${FEEDBACK_OWNER_EMAIL}`} />
        </div>

        <div className="rounded-2xl border border-gray-200 p-5 mb-7">
          <div className="flex items-center justify-between gap-3 mb-4">
            <div>
              <h3 className="font-bold text-sm">Live visitor activity</h3>
              <p className="text-xs text-gray-500 mt-1">Updates automatically every 10 seconds after cloud setup.</p>
            </div>
            <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700">LIVE</span>
          </div>
          {recentVisitors.length ? (
            <div className="overflow-auto">
              <table className="w-full text-xs">
                <thead><tr className="text-left text-gray-400 border-b border-gray-100"><th className="py-2">Time</th><th>Visitor</th><th>Page</th><th>Source</th></tr></thead>
                <tbody>{recentVisitors.map(v => <tr key={v.id} className="border-b border-gray-50 last:border-0"><td className="py-2.5 pr-3 whitespace-nowrap">{v.createdAt ? new Date(v.createdAt).toLocaleString() : ''}</td><td className="pr-3 font-semibold">Anonymous visitor</td><td className="pr-3">{v.page || '#home'}</td><td className="text-gray-500">{v.referrer || 'Direct'}</td></tr>)}</tbody>
              </table>
            </div>
          ) : <div className="p-5 rounded-xl bg-gray-50 text-center text-sm text-gray-500">No visitor records yet.</div>}
          <p className="text-[11px] text-gray-400 mt-3">Visitor identity is anonymous unless the visitor voluntarily provides an email in the feedback form.
          </p>
        </div>

        <div className="rounded-2xl border border-gray-200 p-4 mb-7 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div><div className="text-sm font-bold">Response collection</div><div className="text-xs text-gray-500 mt-1">{FEEDBACK_WEB_APP_URL ? 'Connected to Google Sheets + Gmail notifications.' : 'Add the Apps Script URL to connect cloud storage and email notifications.'}</div></div>
          <span className={`text-xs font-bold px-3 py-1.5 rounded-full ${FEEDBACK_WEB_APP_URL ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>{FEEDBACK_WEB_APP_URL ? 'CONNECTED' : 'SETUP REQUIRED'}</span>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {distribution.map(q => (
            <div key={q.id} className="rounded-2xl border border-gray-200 p-5">
              <h3 className="font-bold text-sm mb-4">{q.label}</h3>
              <div className="space-y-3">
                {q.options.map((o, i) => { const n = q.counts[i], pct = responses.length ? Math.round(n / responses.length * 100) : 0; return <div key={o}><div className="flex justify-between text-xs mb-1"><span>{o}</span><span className="font-bold">{n} · {pct}%</span></div><div className="h-2 rounded-full bg-gray-100 overflow-hidden"><div className="h-full bg-brand-accent rounded-full transition-all" style={{ width: `${pct}%` }} /></div></div>; })}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 rounded-2xl border border-gray-200 overflow-hidden">
          <div className="p-5 border-b border-gray-200 flex items-center gap-2"><Clock3 className="w-4 h-4 text-brand-accent"/><h3 className="font-bold text-sm">Recent responses</h3></div>
          {responses.length ? <div className="divide-y divide-gray-100 max-h-80 overflow-auto">{responses.slice(0, 20).map(r => <div key={r.id || r.createdAt} className="p-4 text-xs"><div className="flex justify-between gap-3"><strong>{r.campaign || 'Meme campaign'}</strong><span className="text-gray-400">{r.createdAt ? new Date(r.createdAt).toLocaleString() : ''}</span></div><div className="text-gray-600 mt-1">{r.purchaseInterest} · {r.memorability} · {r.brandFit}</div></div>)}</div> : <div className="p-8 text-center text-sm text-gray-500">No responses yet.</div>}
        </div>
      </div>
    </section>
  );
}

function Metric({ icon: Icon, value, label }) {
  return <div className="rounded-2xl bg-gray-50 p-4"><Icon className="w-5 h-5 mb-2 text-brand-accent"/><div className="text-2xl font-black truncate">{value}</div><div className="text-xs text-gray-500 mt-0.5">{label}</div></div>;
}
