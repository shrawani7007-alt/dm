import React from 'react';
import { useApp } from '../context/AppContext';
import { ShieldAlert, ShieldCheck, AlertTriangle, AlertOctagon, Lock, Sparkles, HelpCircle } from 'lucide-react';

export default function RiskCheckCard({ campaign, locked }) {
  const { isPro, openProPaywall } = useApp();
  const isLocked = locked ?? !isPro;

  const risks = campaign?.riskCheck || [
    {
      dimension: 'Brand Fit',
      status: 'LOW',
      color: 'green',
      assessment: 'The comedic tone directly reinforces the product value proposition without diluting brand equity.'
    },
    {
      dimension: 'Audience Misunderstanding',
      status: 'LOW',
      color: 'green',
      assessment: 'Premise is grounded in universally recognizable student and young professional vernacular.'
    },
    {
      dimension: 'Trend Dependency',
      status: 'LOW',
      color: 'green',
      assessment: 'Format operates as a perennial situational structure, insulated from ephemeral sound decay.'
    },
    {
      dimension: 'Product Clarity',
      status: 'LOW',
      color: 'green',
      assessment: 'Product solves the central friction before 3 seconds, eliminating "forgot the brand" dropoff.'
    },
    {
      dimension: 'Context Risk',
      status: 'LOW',
      color: 'green',
      assessment: 'Zero sensitive, political, or divisive cultural tropes detected in the campaign hook.'
    }
  ];

  const getStatusBadge = (status) => {
    switch (status) {
      case 'LOW':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            LOW RISK
          </span>
        );
      case 'MODERATE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            MODERATE RISK
          </span>
        );
      case 'HIGH':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-red-100 text-red-800 border border-red-200">
            <AlertOctagon className="w-3.5 h-3.5 text-red-600" />
            HIGH RISK
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-gray-100 text-gray-800">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="relative bg-white rounded-3xl p-6 sm:p-8 shadow-card border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-gray-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-100 text-brand-warning">
              <ShieldAlert className="w-5 h-5" />
            </span>
            <h3 className="text-xl sm:text-2xl font-bold font-heading text-brand-primary">
              Meme Risk Check
            </h3>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Pre-flight vulnerability audit across brand equity, context, and audience misinterpretation
          </p>
        </div>

        <div className="flex items-center gap-2 bg-emerald-50 px-3.5 py-2 rounded-2xl border border-emerald-200 self-start sm:self-auto">
          <span className="w-2.5 h-2.5 rounded-full bg-brand-success animate-pulse" />
          <span className="text-xs font-bold text-emerald-900">Safety Index: Secure (Low Overall)</span>
        </div>
      </div>

      {/* Main Content Area */}
      <div className={isLocked ? 'filter blur-sm select-none pointer-events-none opacity-40 mt-6' : 'mt-6'}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {risks.map((item, idx) => (
            <div 
              key={idx} 
              className={`p-4 rounded-2xl border transition-all duration-200 ${
                item.status === 'HIGH'
                  ? 'bg-red-50/60 border-red-200'
                  : item.status === 'MODERATE'
                  ? 'bg-amber-50/60 border-amber-200'
                  : 'bg-emerald-50/30 border-gray-200'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-bold text-gray-900 font-heading">
                  {item.dimension}
                </h4>
                {getStatusBadge(item.status)}
              </div>
              <p className="text-xs text-gray-600 leading-relaxed font-sans mt-2">
                {item.assessment}
              </p>
            </div>
          ))}
        </div>

        {/* Executive Takeaway */}
        <div className="mt-6 p-4 rounded-2xl bg-gray-50 border border-gray-200 flex items-start gap-3">
          <HelpCircle className="w-4 h-4 text-brand-accent flex-shrink-0 mt-0.5" />
          <div className="text-xs text-gray-600 leading-relaxed">
            <span className="font-bold text-gray-900">Marketer Safeguard Rule: </span>
            A meme is safe when removing the joke leaves a functional value proposition, and removing the value proposition leaves an authentic joke. Both must work in synergy.
          </div>
        </div>
      </div>

      {/* Locked Overlay for Free Users */}
      {isLocked && (
        <div className="absolute inset-0 bg-white/60 backdrop-blur-[2px] flex flex-col items-center justify-center p-6 text-center z-10">
          <div className="w-12 h-12 rounded-2xl bg-[#111111] text-brand-secondary flex items-center justify-center mb-3 shadow-md">
            <Lock className="w-6 h-6" />
          </div>
          <h4 className="text-lg sm:text-xl font-extrabold font-heading text-brand-primary">
            Meme Risk Audit Locked
          </h4>
          <p className="text-xs text-gray-600 max-w-sm mt-1 mb-4">
            Protect your brand against backlash, dead-trend decay, and poor product attribution.
          </p>
          <button
            onClick={openProPaywall}
            className="px-6 py-3 rounded-xl bg-brand-accent hover:bg-brand-accentHover text-white font-bold text-xs uppercase tracking-wider shadow-glow-accent hover:scale-105 transition-all flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-brand-secondary" />
            Unlock Pro Evaluation Suite
          </button>
        </div>
      )}
    </div>
  );
}
