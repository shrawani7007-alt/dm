import React from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, ArrowUpRight, ShieldCheck, Heart } from 'lucide-react';

export default function Footer({ setActivePage }) {
  const { setAuthModal, user } = useApp();

  const handleNav = (pageId) => {
    setActivePage(pageId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#111111] text-white pt-16 pb-12 border-t border-gray-800 no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-gray-800">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-brand-accent text-white flex items-center justify-center font-black font-heading text-xl shadow-glow-accent">
                M<span className="text-brand-secondary text-sm ml-0.5">²</span>
              </div>
              <span className="text-2xl font-black font-heading tracking-tight text-white">
                MEMEVERTISING
              </span>
            </div>

            <p className="text-sm text-gray-400 max-w-sm leading-relaxed">
              "AI can generate a meme. MEMEVERTISING asks whether that meme makes marketing sense."
            </p>

            <div className="pt-2 flex items-center gap-2 text-xs text-gray-400">
              <span className="w-2 h-2 rounded-full bg-brand-success animate-pulse" />
              <span>Freemium Meme Marketing Strategy Engine</span>
            </div>
          </div>

          {/* Column 1: Explore */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-brand-secondary font-heading">
              EXPLORE
            </h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>
                <button
                  onClick={() => handleNav('why-meme-marketing')}
                  className="hover:text-white transition-colors"
                >
                  Why Meme Marketing
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('brand-vault')}
                  className="hover:text-white transition-colors"
                >
                  Brand Vault
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('meme-library')}
                  className="hover:text-white transition-colors"
                >
                  Meme Library
                </button>
              </li>
            </ul>
          </div>

          {/* Column 2: Create */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-brand-secondary font-heading">
              CREATE
            </h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>
                <button
                  onClick={() => handleNav('campaign-builder')}
                  className="hover:text-white transition-colors flex items-center gap-1"
                >
                  <span>Campaign Builder</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-brand-accent" />
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('pricing')}
                  className="hover:text-white transition-colors"
                >
                  Pricing
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('dashboard')}
                  className="hover:text-white transition-colors"
                >
                  Strategy Dashboard
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Company */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-brand-secondary font-heading">
              COMPANY
            </h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>
                <button
                  onClick={() => handleNav('about')}
                  className="hover:text-white transition-colors"
                >
                  About
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    if (user) {
                      handleNav('dashboard');
                    } else {
                      setAuthModal({ isOpen: true, mode: 'login' });
                    }
                  }}
                  className="hover:text-white transition-colors"
                >
                  {user ? 'My Account' : 'Login'}
                </button>
              </li>
              <li>
                <span className="inline-flex items-center gap-1.5 text-xs text-gray-500 pt-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  Ethical Meme Analysis
                </span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-400">
          <div>
            © 2026 MEMEVERTISING. All rights reserved.
          </div>
          <div className="font-bold text-gray-300 font-heading text-sm">
            "Don't Just Make a Meme. Make It Marketable."
          </div>
          <div className="flex items-center gap-1 text-gray-500">
            Built for modern brand marketers
          </div>
        </div>
      </div>
    </footer>
  );
}
