import React, { useState, useEffect, useRef } from 'react';
import { 
  Heart, MessageCircle, Share2, Eye, Bookmark, ExternalLink, 
  Sparkles, Check, Copy, X, Layers, Maximize2, ShieldCheck, 
  Send, ThumbsUp, Flame, Tag, Info, ArrowRight, Download
} from 'lucide-react';
import { 
  getCampaignInteractions, recordActualView, toggleActualLike, 
  toggleActualSave, addActualComment, recordActualShare 
} from '../utils/interactionStorage';
import { useApp } from '../context/AppContext';

export const POSTER_PRESETS = [
  {
    id: 'camp_hera_pheri',
    brandName: 'HERA INVEST',
    industry: 'Fintech & Wealth',
    productName: 'Titanium Wealth Card & High-Yield App',
    memeTheme: 'Phir Hera Pheri (21 Din Me Paisa Double)',
    posterImage: '/posters/ad_poster_phir_hera_pheri.jpg',
    headline: 'NO 21-DIN SCHEMES. REAL COMPOUNDING ROI.',
    stampText: 'BABU RAO APPROVED • 100% TRANSPARENT',
    ctaText: 'Open High-Yield Account',
    layoutSpecs: {
      brandLogo: 'Top center luxury gold typography emblem "HERA INVEST"',
      productFocus: 'Floating titanium credit card & smartphone app balance (₹320,533) with celebratory gold confetti',
      headlineHook: 'Direct satire of the 21-day Laxmi Chit Fund scheme from Phir Hera Pheri',
      culturalStamp: 'Distressed vintage stamp badge "Babu Rao Approved"',
      specsList: 'Zero hidden fees, instant compounding, SEBI regulated trust seals',
      footerCta: 'High-res barcode, App store QR code, handle @herainvest'
    }
  },
  {
    id: 'camp_demo_01',
    brandName: 'CAMPUS FUEL',
    industry: 'Energy & Lifestyle',
    productName: 'Ultra-Neon Clean Energy Drink (12oz)',
    memeTheme: 'Very Demure / 8 AM Lecture POV',
    posterImage: '/posters/ad_poster_campus_fuel.jpg',
    headline: 'UNSTOPPABLE FOCUS • ZERO 8 AM CRASH',
    stampText: 'VERY DEMURE, KINDA ENERGIZED',
    ctaText: 'Scan & Fuel Up',
    layoutSpecs: {
      brandLogo: 'Minimalist neon lightning emblem & Swiss typography "CAMPUS FUEL"',
      productFocus: 'Crisp condensation-beaded matte purple & electric yellow can with glowing aura',
      headlineHook: 'Solves the universally relatable 8 AM student fatigue without traditional ad fluff',
      culturalStamp: 'Viral TikTok sticker badge "Very Demure, Kinda Energized"',
      specsList: 'Zero Crash, Natural Caffeine, Hydration Boost, Focus & Clarity icons',
      footerCta: 'Verified order QR code, social handle @campusfuel'
    }
  },
  {
    id: 'camp_ravi_kishan',
    brandName: 'SWAGWAR APPAREL',
    industry: 'Streetwear & Kicks',
    productName: 'Metallic Neon Street High-Tops (#07/100)',
    memeTheme: 'Ravi Kishan Gucci Dance Swagger',
    posterImage: '/posters/ad_poster_ravi_kishan_gucci.jpg',
    headline: 'ZINDAGI JHANDWA, STYLE GHAMANDWA',
    stampText: 'GUCCI STEP READY • 100% DESI SWAGGER',
    ctaText: 'Cop Limited Drop',
    layoutSpecs: {
      brandLogo: 'Bold crown crest with bold editorial header "SWAGWAR APPAREL"',
      productFocus: 'Iridescent magenta & metallic gold high-top sneakers suspended over retro neon grid',
      headlineHook: 'Iconic Bollywood swagger catchphrase reimagined as youth streetwear pride',
      culturalStamp: 'Circular sneaker authentication badge "Gucci Step Ready"',
      specsList: 'Reflective lace accents, Air cushioning, numbered collector series',
      footerCta: 'Inventory barcode, collection scan QR, Instagram @swagwar'
    }
  }
];

export default function RefinedPosterShowcase() {
  const { addToast } = useApp();
  const [selectedPosterIndex, setSelectedPosterIndex] = useState(0);
  const [showLayoutBreakdown, setShowLayoutBreakdown] = useState(false);
  const [commentDrawerOpen, setCommentDrawerOpen] = useState(false);
  const [shareDrawerOpen, setShareDrawerOpen] = useState(false);
  const [newAuthor, setNewAuthor] = useState('');
  const [newComment, setNewComment] = useState('');
  const [copied, setCopied] = useState(false);

  const activePoster = POSTER_PRESETS[selectedPosterIndex];
  const [metrics, setMetrics] = useState(() => getCampaignInteractions(activePoster.id));

  // Sync interactions on active poster change and listen to live events
  useEffect(() => {
    const updated = recordActualView(activePoster.id);
    setMetrics({ ...updated });

    const handleUpdate = (e) => {
      if (e.detail && e.detail[activePoster.id]) {
        setMetrics({ ...e.detail[activePoster.id] });
      }
    };

    window.addEventListener('meme_interactions_updated', handleUpdate);
    return () => window.removeEventListener('meme_interactions_updated', handleUpdate);
  }, [activePoster.id]);

  // Actual like
  const handleLike = () => {
    const updated = toggleActualLike(activePoster.id);
    setMetrics({ ...updated });
    if (updated.likedByMe) {
      addToast(`Liked ${activePoster.brandName}! Counts saved across all visitors.`, 'success');
    }
  };

  // Actual bookmark
  const handleSave = () => {
    const updated = toggleActualSave(activePoster.id);
    setMetrics({ ...updated });
    addToast(updated.savedByMe ? 'Poster saved to your bookmarks' : 'Removed from bookmarks', 'info');
  };

  // Actual comment submission
  const handlePostComment = (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    const res = addActualComment(
      activePoster.id,
      newComment,
      newAuthor.trim() || 'Marketing Customer'
    );

    if (res) {
      setMetrics({ ...res.updated });
      setNewComment('');
      addToast('Comment saved permanently! Other visitors can now see your feedback.', 'success');
    }
  };

  // Actual share
  const handleShare = (channel = 'link') => {
    const updated = recordActualShare(activePoster.id, channel);
    setMetrics({ ...updated });
    navigator.clipboard?.writeText(window.location.href);
    setCopied(true);
    addToast('Poster link copied! Real cumulative share count updated.', 'success');
    setTimeout(() => setCopied(false), 2500);
  };

  // Calculate live popularity score
  const popularityScore = Math.round(
    (metrics.likes || 0) * 4 + 
    ((metrics.comments || []).length) * 8 + 
    (metrics.shares || 0) * 5 + 
    (metrics.views || 0) * 0.05
  );

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-card border border-gray-200 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-gray-100 pb-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-50 text-brand-accent text-xs font-bold uppercase tracking-wider border border-purple-200">
            <Sparkles className="w-3.5 h-3.5 text-brand-secondary fill-current" />
            Advertisement Poster & Layout Studio
          </div>
          <h2 className="text-3xl sm:text-4xl font-black font-heading text-brand-primary">
            Refined Commercial Meme Posters
          </h2>
          <p className="text-sm text-gray-600 font-sans max-w-2xl leading-relaxed">
            Examine complete poster layouts: Brand Logo, Hero Product, Cultural Hook, Value Proposition, and Trust Stamps. Likes and comments are permanently stored so customers can gauge brand popularity in real time.
          </p>
        </div>

        {/* Live Popularity Score Badge */}
        <div className="flex-shrink-0 p-4 rounded-2xl bg-gradient-to-br from-purple-900 to-brand-primary text-white border border-purple-500/30 shadow-md flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-brand-secondary text-brand-primary font-black text-lg flex items-center justify-center">
            🔥
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold tracking-widest text-purple-200 block">
              Brand Popularity Score
            </span>
            <span className="text-2xl font-black font-mono text-brand-secondary">
              {popularityScore.toLocaleString('en-IN')}
            </span>
          </div>
        </div>
      </div>

      {/* Poster Preset Selector Tabs */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl bg-gray-100 border border-gray-200">
        {POSTER_PRESETS.map((preset, idx) => (
          <button
            key={preset.id}
            onClick={() => setSelectedPosterIndex(idx)}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              selectedPosterIndex === idx
                ? 'bg-white text-brand-primary shadow-sm font-black'
                : 'text-gray-600 hover:text-black hover:bg-gray-200/60'
            }`}
          >
            <span>{idx === 0 ? '💰' : idx === 1 ? '⚡' : '🕺'}</span>
            <span>{preset.brandName}</span>
            <span className="text-[10px] text-gray-400 font-normal">({preset.memeTheme.split('(')[0]})</span>
          </button>
        ))}
      </div>

      {/* Main Two-Column Showcase: Poster on Left, Layout Anatomy & Live Social Proof on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left: The Refined Poster Frame (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="relative rounded-3xl overflow-hidden shadow-elevated border-2 border-gray-900/10 group bg-gray-950">
            
            {/* Poster Image */}
            <img
              src={activePoster.posterImage}
              alt={`${activePoster.brandName} Refined Advertisement Poster`}
              className="w-full h-auto object-cover transform transition-transform duration-500 group-hover:scale-[1.02]"
              loading="lazy"
            />

            {/* Layout Breakdown Overlay (When activated) */}
            {showLayoutBreakdown && (
              <div className="absolute inset-0 bg-black/75 p-5 text-white flex flex-col justify-between backdrop-blur-xs animate-fade-in text-xs font-sans">
                <div className="space-y-3">
                  <div className="flex items-center justify-between border-b border-white/20 pb-2">
                    <span className="font-bold uppercase tracking-widest text-brand-secondary text-[11px]">
                      Poster Layout Specifications
                    </span>
                    <button 
                      onClick={() => setShowLayoutBreakdown(false)}
                      className="p-1 rounded bg-white/20 text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="space-y-2 text-[11px] leading-snug">
                    <p><strong className="text-amber-400">1. Brand Logo:</strong> {activePoster.layoutSpecs.brandLogo}</p>
                    <p><strong className="text-cyan-400">2. Hero Product:</strong> {activePoster.layoutSpecs.productFocus}</p>
                    <p><strong className="text-purple-400">3. Cultural Hook:</strong> {activePoster.layoutSpecs.headlineHook}</p>
                    <p><strong className="text-pink-400">4. Badge Stamp:</strong> {activePoster.layoutSpecs.culturalStamp}</p>
                    <p><strong className="text-emerald-400">5. Specifications:</strong> {activePoster.layoutSpecs.specsList}</p>
                    <p><strong className="text-blue-400">6. Call to Action:</strong> {activePoster.layoutSpecs.footerCta}</p>
                  </div>
                </div>

                <div className="text-[10px] text-gray-400 border-t border-white/10 pt-2 font-mono">
                  Standard Commercial Ratio: 3:4 • High-Density Swiss Grid
                </div>
              </div>
            )}

            {/* Toggle Overlay Button */}
            <button
              onClick={() => setShowLayoutBreakdown(!showLayoutBreakdown)}
              className="absolute top-3 right-3 px-3 py-1.5 rounded-full bg-black/70 hover:bg-black text-white text-[10px] font-bold tracking-wider uppercase backdrop-blur-md flex items-center gap-1.5 border border-white/20 transition-all shadow-md"
            >
              <Layers className="w-3.5 h-3.5 text-brand-secondary" />
              <span>{showLayoutBreakdown ? 'Hide Layout' : 'Inspect Layout'}</span>
            </button>
          </div>

          {/* Direct Poster Download / External Action */}
          <div className="flex items-center justify-between text-xs text-gray-500 px-2">
            <span className="flex items-center gap-1 font-mono">
              <Eye className="w-3.5 h-3.5 text-brand-accent" />
              {(metrics.views || 0).toLocaleString('en-IN')} Cumulative Customer Views
            </span>
            <a
              href={activePoster.posterImage}
              target="_blank"
              rel="noreferrer"
              className="text-brand-accent hover:underline font-bold flex items-center gap-1"
            >
              <span>View Full Res</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* Right: Layout Blueprint Details & Real Customer Social Proof Hub (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Brand Spec Card */}
          <div className="p-6 rounded-3xl bg-gray-50/80 border border-gray-200 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-purple-100 text-brand-accent border border-purple-200">
                  {activePoster.industry}
                </span>
                <h3 className="text-2xl font-black font-heading text-brand-primary mt-1">
                  {activePoster.brandName}
                </h3>
                <p className="text-xs font-semibold text-gray-500 mt-0.5">
                  Hero Product: <span className="text-gray-900 font-bold">{activePoster.productName}</span>
                </p>
              </div>

              <div className="text-right">
                <span className="inline-block text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-200">
                  {activePoster.stampText}
                </span>
              </div>
            </div>

            {/* Poster Headline */}
            <div className="p-3.5 rounded-2xl bg-white border border-gray-200 text-xs font-black font-heading text-brand-primary uppercase tracking-tight">
              "{activePoster.headline}"
            </div>

            {/* Key Structural Blueprint */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-2xl bg-white border border-gray-100 space-y-1">
                <span className="text-[10px] uppercase font-bold text-gray-400 block font-mono">
                  Meme Anchor
                </span>
                <p className="font-bold text-gray-800">{activePoster.memeTheme}</p>
              </div>

              <div className="p-3 rounded-2xl bg-white border border-gray-100 space-y-1">
                <span className="text-[10px] uppercase font-bold text-gray-400 block font-mono">
                  Conversion CTA
                </span>
                <p className="font-bold text-brand-accent">{activePoster.ctaText}</p>
              </div>
            </div>
          </div>

          {/* Real Customer Engagement Hub (LIKES & COMMENTS PERMANENTLY STORED) */}
          <div className="p-6 rounded-3xl bg-white border-2 border-brand-accent/20 shadow-md space-y-5">
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <div>
                <h4 className="text-base font-black font-heading text-brand-primary flex items-center gap-2">
                  <ThumbsUp className="w-4 h-4 text-brand-accent" />
                  Real Customer Social Proof
                </h4>
                <p className="text-[11px] text-gray-500">
                  Likes and comments persist across all customers and sync across browser sessions.
                </p>
              </div>

              {/* Verified Count Badges */}
              <div className="flex items-center gap-3 font-mono text-xs font-bold">
                <span className="text-red-500">{(metrics.likes || 0).toLocaleString('en-IN')} Likes</span>
                <span className="text-gray-300">•</span>
                <span className="text-brand-accent">{(metrics.comments || []).length} Comments</span>
              </div>
            </div>

            {/* Interactive Social Buttons (REAL FUNCTIONALITY) */}
            <div className="flex items-center gap-3">
              
              {/* Like Button */}
              <button
                onClick={handleLike}
                className={`flex-1 py-3 px-4 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-sm ${
                  metrics.likedByMe
                    ? 'bg-red-500 text-white shadow-md'
                    : 'bg-red-50 hover:bg-red-100 text-red-600 border border-red-200'
                }`}
              >
                <Heart className={`w-4 h-4 ${metrics.likedByMe ? 'fill-current' : ''}`} />
                <span>{metrics.likedByMe ? 'Liked by You' : 'Like Brand Poster'} ({(metrics.likes || 0).toLocaleString('en-IN')})</span>
              </button>

              {/* Comment Drawer Toggle */}
              <button
                onClick={() => setCommentDrawerOpen(true)}
                className="flex-1 py-3 px-4 rounded-2xl bg-purple-50 hover:bg-purple-100 text-brand-accent border border-purple-200 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Discussion ({(metrics.comments || []).length})</span>
              </button>

              {/* Share Button */}
              <button
                onClick={() => handleShare('link')}
                className="py-3 px-4 rounded-2xl bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                title="Share & Copy Link"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
                <span>{copied ? 'Copied' : (metrics.shares || 0)}</span>
              </button>

              {/* Bookmark */}
              <button
                onClick={handleSave}
                className={`p-3 rounded-2xl border transition-colors ${
                  metrics.savedByMe ? 'bg-amber-50 border-amber-300 text-amber-600' : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'
                }`}
                title="Bookmark Poster"
              >
                <Bookmark className={`w-4 h-4 ${metrics.savedByMe ? 'fill-current' : ''}`} />
              </button>

            </div>

            {/* Customer Comments Preview List */}
            <div className="space-y-3">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block font-mono">
                Latest Customer Comments & Reactions:
              </span>

              <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                {(metrics.comments || []).slice(0, 3).map((comm) => (
                  <div key={comm.id} className="p-3 rounded-2xl bg-gray-50 border border-gray-100 text-xs">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <span className={`w-5 h-5 rounded-full ${comm.avatarColor || 'bg-brand-accent'} text-white text-[9px] font-bold flex items-center justify-center`}>
                          {comm.author.charAt(0).toUpperCase()}
                        </span>
                        <span className="font-bold text-gray-900">{comm.author}</span>
                      </div>
                      <span className="text-[10px] text-gray-400 font-mono">{comm.timestamp}</span>
                    </div>
                    <p className="text-gray-700 leading-relaxed font-sans pl-7">{comm.text}</p>
                  </div>
                ))}
              </div>

              {(metrics.comments || []).length > 3 && (
                <button
                  onClick={() => setCommentDrawerOpen(true)}
                  className="text-xs font-bold text-brand-accent hover:underline block pt-1"
                >
                  View all {(metrics.comments || []).length} customer comments →
                </button>
              )}
            </div>

            {/* Quick Inline Comment Input */}
            <form onSubmit={handlePostComment} className="pt-2 border-t border-gray-100 space-y-2">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Your Name (e.g. Ananya, Product Lead)"
                  value={newAuthor}
                  onChange={(e) => setNewAuthor(e.target.value)}
                  className="w-1/3 px-3 py-2 text-xs rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-1 focus:ring-brand-accent"
                />
                <input
                  type="text"
                  placeholder="Leave real customer feedback on this ad..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  className="flex-1 px-3 py-2 text-xs rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-accent"
                />
                <button
                  type="submit"
                  disabled={!newComment.trim()}
                  className="px-4 py-2 rounded-xl bg-brand-primary hover:bg-brand-accent text-white text-xs font-bold uppercase tracking-wider transition-colors disabled:opacity-40"
                >
                  Post
                </button>
              </div>
            </form>

          </div>

        </div>

      </div>

      {/* Customer Comment Drawer Modal */}
      {commentDrawerOpen && (
        <div 
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in"
        >
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-elevated border border-gray-200 overflow-hidden flex flex-col max-h-[85vh]">
            
            <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-gray-50">
              <div>
                <h3 className="text-base font-bold font-heading text-brand-primary">
                  {activePoster.brandName} Discussion ({(metrics.comments || []).length})
                </h3>
                <p className="text-[11px] text-gray-500">Stored in real-time for all prospective customers to see</p>
              </div>
              <button
                onClick={() => setCommentDrawerOpen(false)}
                className="p-1.5 rounded-full hover:bg-gray-200 text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1 space-y-3">
              {(metrics.comments || []).map((comm) => (
                <div key={comm.id} className="p-3.5 rounded-2xl bg-gray-50 border border-gray-100 text-xs">
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <div className={`w-7 h-7 rounded-full ${comm.avatarColor || 'bg-brand-accent'} text-white text-xs font-bold flex items-center justify-center`}>
                        {comm.author.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <span className="font-bold text-gray-900 block leading-tight">{comm.author}</span>
                        <span className="text-[10px] text-gray-400 font-mono">{comm.handle}</span>
                      </div>
                    </div>
                    <span className="text-[10px] text-gray-400 font-mono">{comm.timestamp}</span>
                  </div>
                  <p className="text-gray-700 font-sans leading-relaxed pl-9">{comm.text}</p>
                </div>
              ))}
            </div>

            <form onSubmit={handlePostComment} className="p-4 border-t border-gray-100 bg-white space-y-2">
              <input
                type="text"
                placeholder="Your Name (e.g. Rahul Sharma)"
                value={newAuthor}
                onChange={(e) => setNewAuthor(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-1 focus:ring-brand-accent"
              />
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Share your thoughts on this brand..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  className="flex-1 px-4 py-2.5 text-xs rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-accent"
                />
                <button
                  type="submit"
                  disabled={!newComment.trim()}
                  className="px-5 py-2.5 rounded-xl bg-brand-primary hover:bg-brand-accent text-white text-xs font-bold uppercase tracking-wider transition-colors disabled:opacity-40"
                >
                  Submit
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
}
