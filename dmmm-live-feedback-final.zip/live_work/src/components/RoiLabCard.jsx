import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Sliders, Calculator, Lock, Sparkles, TrendingUp, IndianRupee, MousePointerClick, Users, ShoppingBag, Info, RotateCcw } from 'lucide-react';

export default function RoiLabCard({ locked }) {
  const { isPro, openProPaywall } = useApp();
  const isLocked = locked ?? !isPro;

  // Defaults as specified in prompt
  const initialInputs = {
    budget: 10000,
    reach: 50000,
    engagementRate: 5.0, // 5%
    ctr: 3.0,            // 3%
    conversionRate: 10.0,// 10%
    aov: 500             // ₹500
  };

  const [inputs, setInputs] = useState(initialInputs);

  const handleReset = () => {
    setInputs(initialInputs);
  };

  // Calculations as per prompt formulas:
  // Engagement = Reach × Engagement Rate
  // Clicks = Reach × CTR
  // Conversions = Clicks × Conversion Rate
  // Revenue = Conversions × Average Order Value
  // ROI = ((Revenue - Budget) / Budget) × 100
  const engagement = Math.round(inputs.reach * (inputs.engagementRate / 100));
  const clicks = Math.round(inputs.reach * (inputs.ctr / 100));
  const conversions = Math.round(clicks * (inputs.conversionRate / 100));
  const revenue = Math.round(conversions * inputs.aov);
  const netProfit = revenue - inputs.budget;
  const roi = inputs.budget > 0 
    ? Math.round(((revenue - inputs.budget) / inputs.budget) * 100)
    : 0;

  return (
    <div className="relative bg-white rounded-3xl p-6 sm:p-8 shadow-card border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-gray-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-100 text-brand-success">
              <Calculator className="w-5 h-5" />
            </span>
            <h3 className="text-xl sm:text-2xl font-bold font-heading text-brand-primary">
              ROI Lab
            </h3>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Real-time interactive campaign financial model & return-on-ad-spend simulator
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold text-gray-400 bg-gray-100 px-3 py-1.5 rounded-xl">
            Demo Assumptions Model
          </span>
          <button
            onClick={handleReset}
            className="p-2 rounded-xl hover:bg-gray-100 text-gray-500 hover:text-black transition-colors"
            title="Reset to default assumptions"
            aria-label="Reset defaults"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className={isLocked ? 'filter blur-sm select-none pointer-events-none opacity-40 mt-6' : 'mt-6'}>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Interactive Inputs (5 cols) */}
          <div className="lg:col-span-6 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 font-heading mb-3">
              Campaign Parameter Inputs
            </h4>

            {/* Budget */}
            <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="font-bold text-gray-700">Campaign Budget</span>
                <span className="font-black text-brand-primary">₹{inputs.budget.toLocaleString('en-IN')}</span>
              </div>
              <input
                type="range"
                min="1000"
                max="100000"
                step="1000"
                value={inputs.budget}
                onChange={(e) => setInputs({ ...inputs, budget: Number(e.target.value) })}
                className="w-full accent-brand-accent cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-gray-400">
                <span>₹1,000</span>
                <span>Default: ₹10,000</span>
                <span>₹1,00,000</span>
              </div>
            </div>

            {/* Reach */}
            <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="font-bold text-gray-700">Target Reach (Impressions)</span>
                <span className="font-black text-brand-primary">{inputs.reach.toLocaleString('en-IN')}</span>
              </div>
              <input
                type="range"
                min="5000"
                max="500000"
                step="5000"
                value={inputs.reach}
                onChange={(e) => setInputs({ ...inputs, reach: Number(e.target.value) })}
                className="w-full accent-brand-accent cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-gray-400">
                <span>5,000</span>
                <span>Default: 50,000</span>
                <span>5,00,000</span>
              </div>
            </div>

            {/* Engagement Rate & CTR row */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 space-y-1">
                <label className="block text-[11px] font-bold text-gray-700">
                  Engagement Rate
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    step="0.5"
                    min="0.5"
                    max="30"
                    value={inputs.engagementRate}
                    onChange={(e) => setInputs({ ...inputs, engagementRate: Number(e.target.value) })}
                    className="w-full py-1.5 px-2.5 rounded-lg border border-gray-300 text-sm font-bold bg-white focus:outline-none focus:ring-1 focus:ring-brand-accent"
                  />
                  <span className="text-xs font-bold text-gray-500">%</span>
                </div>
                <span className="text-[10px] text-gray-400">Default: 5%</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 space-y-1">
                <label className="block text-[11px] font-bold text-gray-700">
                  Click-Through Rate (CTR)
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    step="0.5"
                    min="0.5"
                    max="20"
                    value={inputs.ctr}
                    onChange={(e) => setInputs({ ...inputs, ctr: Number(e.target.value) })}
                    className="w-full py-1.5 px-2.5 rounded-lg border border-gray-300 text-sm font-bold bg-white focus:outline-none focus:ring-1 focus:ring-brand-accent"
                  />
                  <span className="text-xs font-bold text-gray-500">%</span>
                </div>
                <span className="text-[10px] text-gray-400">Default: 3%</span>
              </div>
            </div>

            {/* Conversion Rate & AOV row */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 space-y-1">
                <label className="block text-[11px] font-bold text-gray-700">
                  Conversion Rate
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    step="1"
                    min="1"
                    max="50"
                    value={inputs.conversionRate}
                    onChange={(e) => setInputs({ ...inputs, conversionRate: Number(e.target.value) })}
                    className="w-full py-1.5 px-2.5 rounded-lg border border-gray-300 text-sm font-bold bg-white focus:outline-none focus:ring-1 focus:ring-brand-accent"
                  />
                  <span className="text-xs font-bold text-gray-500">%</span>
                </div>
                <span className="text-[10px] text-gray-400">Default: 10%</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 space-y-1">
                <label className="block text-[11px] font-bold text-gray-700">
                  Avg Order Value (AOV)
                </label>
                <div className="flex items-center gap-1">
                  <span className="text-xs font-bold text-gray-500">₹</span>
                  <input
                    type="number"
                    step="50"
                    min="50"
                    max="20000"
                    value={inputs.aov}
                    onChange={(e) => setInputs({ ...inputs, aov: Number(e.target.value) })}
                    className="w-full py-1.5 px-2.5 rounded-lg border border-gray-300 text-sm font-bold bg-white focus:outline-none focus:ring-1 focus:ring-brand-accent"
                  />
                </div>
                <span className="text-[10px] text-gray-400">Default: ₹500</span>
              </div>
            </div>
          </div>

          {/* Right Column: Calculated Dynamic Results (6 cols) */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 font-heading">
              Dynamic Real-Time Projections
            </h4>

            {/* ROI Hero Spotlight Card */}
            <div className="p-6 rounded-3xl bg-gradient-to-br from-[#111111] to-[#1F2937] text-white shadow-elevated relative overflow-hidden">
              <div className="absolute right-0 top-0 w-32 h-32 bg-brand-accent/20 rounded-full blur-2xl" />
              
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs uppercase font-bold text-gray-400 tracking-wider">
                  Projected Campaign ROI
                </span>
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${roi >= 0 ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'}`}>
                  {roi >= 0 ? 'Profitable' : 'Deficit'}
                </span>
              </div>

              <div className="flex items-baseline gap-2">
                <span className="text-4xl sm:text-5xl font-black font-heading text-brand-secondary">
                  {roi > 0 ? `+${roi.toLocaleString('en-IN')}%` : `${roi}%`}
                </span>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-700/60 flex items-center justify-between text-xs">
                <div>
                  <span className="text-gray-400 block text-[10px]">Projected Gross Revenue</span>
                  <span className="font-extrabold text-white text-base">₹{revenue.toLocaleString('en-IN')}</span>
                </div>
                <div className="text-right">
                  <span className="text-gray-400 block text-[10px]">Net Campaign Profit</span>
                  <span className={`font-extrabold text-base ${netProfit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {netProfit >= 0 ? `+₹${netProfit.toLocaleString('en-IN')}` : `-₹${Math.abs(netProfit).toLocaleString('en-IN')}`}
                  </span>
                </div>
              </div>
            </div>

            {/* Micro Funnel Metrics */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 text-center">
                <Users className="w-4 h-4 mx-auto text-purple-600 mb-1" />
                <span className="text-[10px] text-gray-500 block uppercase font-bold">Engagement</span>
                <span className="text-base font-black text-gray-900 font-heading">
                  {engagement.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 text-center">
                <MousePointerClick className="w-4 h-4 mx-auto text-blue-600 mb-1" />
                <span className="text-[10px] text-gray-500 block uppercase font-bold">Clicks</span>
                <span className="text-base font-black text-gray-900 font-heading">
                  {clicks.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 text-center">
                <ShoppingBag className="w-4 h-4 mx-auto text-emerald-600 mb-1" />
                <span className="text-[10px] text-gray-500 block uppercase font-bold">Conversions</span>
                <span className="text-base font-black text-gray-900 font-heading">
                  {conversions.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2 p-3 rounded-xl bg-gray-50 text-[11px] text-gray-500 border border-gray-200">
              <Info className="w-3.5 h-3.5 flex-shrink-0 mt-0.5 text-gray-400" />
              <span>
                <strong>Formula:</strong> Revenue = Reach × CTR × ConvRate × AOV. ROI = ((Revenue − Budget) / Budget) × 100. Default inputs are illustrative demo assumptions.
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Locked Overlay for Free Users */}
      {isLocked && (
        <div className="absolute inset-0 bg-white/60 backdrop-blur-[2px] flex flex-col items-center justify-center p-6 text-center z-10">
          <div className="w-12 h-12 rounded-2xl bg-[#111111] text-brand-secondary flex items-center justify-center mb-3 shadow-md">
            <Lock className="w-6 h-6" />
          </div>
          <h4 className="text-lg sm:text-xl font-extrabold font-heading text-brand-primary">
            Interactive ROI Lab Locked
          </h4>
          <p className="text-xs text-gray-600 max-w-sm mt-1 mb-4">
            Simulate custom budgets, CTR forecasts, conversion assumptions, and profit modeling.
          </p>
          <button
            onClick={openProPaywall}
            className="px-6 py-3 rounded-xl bg-brand-accent hover:bg-brand-accentHover text-white font-bold text-xs uppercase tracking-wider shadow-glow-accent hover:scale-105 transition-all flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-brand-secondary" />
            Unlock Pro Evaluation Suite
          </button>
        </div>
      )}
    </div>
  );
}
