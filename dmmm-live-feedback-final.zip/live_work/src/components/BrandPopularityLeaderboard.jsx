import React, { useState, useEffect } from 'react';
import { 
  getBrandPopularityLeaderboard, toggleActualLike, addActualComment, 
  recordActualView 
} from '../utils/interactionStorage';
import { useApp } from '../context/AppContext';
import { 
  Trophy, Flame, Heart, MessageCircle, Eye, ArrowUpRight, 
  Sparkles, CheckCircle2, ThumbsUp, Send, X, ExternalLink
} from 'lucide-react';

export default function BrandPopularityLeaderboard({ onSelectBrand }) {
  const { addToast } = useApp();
  const [leaderboard, setLeaderboard] = useState(() => getBrandPopularityLeaderboard());
  const [activeCommentBrand, setActiveCommentBrand] = useState(null);
  const [commentText, setCommentText] = useState('');
  const [authorName, setAuthorName] = useState('');

  // Update leaderboard on storage events
  useEffect(() => {
    const handleUpdate = () => {
      setLeaderboard(getBrandPopularityLeaderboard());
    };

    window.addEventListener('meme_interactions_updated', handleUpdate);
    return () => window.removeEventListener('meme_interactions_updated', handleUpdate);
  }, []);

  const handleLikeBrand = (brandId, brandName) => {
    toggleActualLike(brandId);
    setLeaderboard(getBrandPopularityLeaderboard());
    addToast(`Liked ${brandName}! Popularity score updated.`, 'success');
  };

  const handlePostComment = (e) => {
    e.preventDefault();
    if (!commentText.trim() || !activeCommentBrand) return;

    addActualComment(
      activeCommentBrand.id,
      commentText,
      authorName.trim() || 'Verified Customer'
    );

    setLeaderboard(getBrandPopularityLeaderboard());
    setCommentText('');
    setActiveCommentBrand(null);
    addToast('Comment published! Stored permanently for all customers.', 'success');
  };

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-card border border-gray-200 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-5">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-50 text-amber-700 text-xs font-bold uppercase tracking-wider border border-amber-200">
            <Trophy className="w-3.5 h-3.5 text-amber-600" />
            AI-Generated Social Proof
          </div>
          <h2 className="text-2xl sm:text-3xl font-black font-heading text-brand-primary">
            Brand Popularity & Social Resonance
          </h2>
          <p className="text-xs sm:text-sm text-gray-600 font-sans">
            Engagement numbers and discussion are AI-generated demo data modeled on realistic social-media activity. User interactions are added locally on top of this baseline.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-bold text-gray-500 font-mono">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span>Live Demo Sync Active</span>
        </div>
      </div>

      {/* Leaderboard Rankings List */}
      <div className="grid grid-cols-1 gap-4">
        {leaderboard.map((item, rank) => {
          const isLikedByMe = item.interactions?.likedByMe;

          return (
            <div
              key={item.id}
              className={`p-5 sm:p-6 rounded-3xl border transition-all duration-300 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:shadow-card-hover ${
                rank === 0
                  ? 'bg-gradient-to-r from-amber-50/70 via-white to-purple-50/40 border-amber-300 shadow-sm'
                  : rank === 1
                  ? 'bg-white border-purple-200'
                  : 'bg-gray-50/60 border-gray-200'
              }`}
            >
              
              {/* Left Column: Rank + Brand Details */}
              <div className="flex items-start gap-4">
                
                {/* Rank Badge */}
                <div className={`w-12 h-12 rounded-2xl flex-shrink-0 flex items-center justify-center font-black font-heading text-lg shadow-xs ${
                  rank === 0
                    ? 'bg-amber-400 text-brand-primary shadow-amber-300'
                    : rank === 1
                    ? 'bg-gray-200 text-gray-800'
                    : rank === 2
                    ? 'bg-amber-700/20 text-amber-900'
                    : 'bg-gray-100 text-gray-500'
                }`}>
                  #{rank + 1}
                </div>

                {/* Poster Thumbnail */}
                <img
                  src={item.posterImage}
                  alt={item.brand}
                  className="w-14 h-18 object-cover rounded-xl border border-gray-200 shadow-xs hidden sm:block flex-shrink-0"
                />

                {/* Details */}
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-xl font-black font-heading text-brand-primary">
                      {item.brand}
                    </h3>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-purple-50 text-brand-accent border border-purple-200">
                      {item.industry}
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-gray-100 text-gray-700">
                      {item.badge}
                    </span>
                  </div>

                  <p className="text-xs font-semibold text-gray-600 font-sans">
                    Product: <span className="font-bold text-gray-900">{item.product}</span>
                  </p>

                  <p className="text-xs text-brand-accent italic font-sans">
                    Meme Campaign: "{item.memeHook}"
                  </p>
                </div>

              </div>

              {/* Right Column: Live Metrics + Interactive Actions */}
              <div className="flex flex-wrap sm:flex-nowrap items-center justify-between md:justify-end gap-5 border-t sm:border-t-0 pt-3 sm:pt-0">
                
                {/* Cumulative Metric Counters */}
                <div className="flex items-center gap-4 text-xs font-mono">
                  <div className="text-center">
                    <span className="block text-[10px] uppercase font-bold text-gray-400 font-sans">Likes</span>
                    <span className="font-bold text-red-500 text-sm">{item.likesCount.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="text-center">
                    <span className="block text-[10px] uppercase font-bold text-gray-400 font-sans">Comments</span>
                    <span className="font-bold text-brand-accent text-sm">{item.commentsCount.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="text-center">
                    <span className="block text-[10px] uppercase font-bold text-gray-400 font-sans">Popularity</span>
                    <span className="font-black text-amber-600 text-sm">{item.popularityScore.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                {/* Interactive Action Buttons */}
                <div className="flex items-center gap-2">
                  
                  {/* Like Button */}
                  <button
                    onClick={() => handleLikeBrand(item.id, item.brand)}
                    className={`p-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 ${
                      isLikedByMe
                        ? 'bg-red-500 text-white shadow-sm'
                        : 'bg-red-50 hover:bg-red-100 text-red-600 border border-red-200'
                    }`}
                    title={isLikedByMe ? 'Liked' : 'Like Brand'}
                  >
                    <Heart className={`w-4 h-4 ${isLikedByMe ? 'fill-current' : ''}`} />
                    <span className="hidden sm:inline">{isLikedByMe ? 'Liked' : 'Like'}</span>
                  </button>

                  {/* Comment Button */}
                  <button
                    onClick={() => setActiveCommentBrand(item)}
                    className="p-2.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-brand-accent border border-purple-200 text-xs font-bold flex items-center gap-1.5 transition-colors"
                    title="Add Comment"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span className="hidden sm:inline">Comment</span>
                  </button>

                </div>

              </div>

            </div>
          );
        })}
      </div>

      {/* Real-time Customer Comment Drawer Modal */}
      {activeCommentBrand && (
        <div 
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in"
        >
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-elevated border border-gray-200 overflow-hidden flex flex-col max-h-[85vh]">
            
            <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-gray-50">
              <div>
                <h3 className="text-base font-bold font-heading text-brand-primary">
                  Review & Comment on {activeCommentBrand.brand}
                </h3>
                <p className="text-[11px] text-gray-500">
                  Total {activeCommentBrand.commentsCount} comments stored and visible to all prospective customers
                </p>
              </div>
              <button
                onClick={() => setActiveCommentBrand(null)}
                className="p-1.5 rounded-full hover:bg-gray-200 text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Comment Feed */}
            <div className="p-6 overflow-y-auto flex-1 space-y-3">
              {(activeCommentBrand.interactions?.comments || []).map((c) => (
                <div key={c.id} className="p-3.5 rounded-2xl bg-gray-50 border border-gray-100 text-xs">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-gray-900">{c.author}</span>
                    <span className="text-[10px] text-gray-400 font-mono">{c.timestamp}</span>
                  </div>
                  <p className="text-gray-700 leading-relaxed font-sans">{c.text}</p>
                </div>
              ))}
            </div>

            {/* Submit Comment */}
            <form onSubmit={handlePostComment} className="p-4 border-t border-gray-100 bg-white space-y-2">
              <input
                type="text"
                placeholder="Your Name (e.g. Vikram, Brand Strategist)"
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-gray-200 bg-gray-50 focus:outline-none focus:ring-1 focus:ring-brand-accent"
              />
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder={`Write authentic customer feedback for ${activeCommentBrand.brand}...`}
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="flex-1 px-4 py-2.5 text-xs rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-accent"
                />
                <button
                  type="submit"
                  disabled={!commentText.trim()}
                  className="px-5 py-2.5 rounded-xl bg-brand-primary hover:bg-brand-accent text-white text-xs font-bold uppercase tracking-wider transition-colors disabled:opacity-40"
                >
                  Post
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
}
