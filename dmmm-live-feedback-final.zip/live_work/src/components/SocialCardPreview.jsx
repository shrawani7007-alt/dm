import React, { useState, useEffect } from 'react';
import { 
  Heart, MessageCircle, Send, Bookmark, MoreHorizontal, 
  Share2, ThumbsUp, Repeat, ExternalLink, Zap, Sparkles, 
  X, Copy, Check, Eye, MessageSquare, Flame, Smile, Plus,
  Volume2, VolumeX, Play, Square, Music, Disc
} from 'lucide-react';
import { 
  getCampaignInteractions, recordActualView, toggleActualLike, 
  toggleActualSave, recordActualShare, addActualComment 
} from '../utils/interactionStorage';
import { TRENDING_MEME_ASSETS } from '../data/trendingStickers';
import { memeAudio } from '../utils/memeAudioEngine';
import { useApp } from '../context/AppContext';

export default function SocialCardPreview({ campaign, customPlatform }) {
  const { addToast } = useApp();
  const campaignId = campaign?.id || 'camp_demo_01';

  const currentPlatform = customPlatform || campaign?.platform || 'Instagram';
  const [activePlatformTab, setActivePlatformTab] = useState(currentPlatform);

  // Trending meme sticker / poster state
  const [activeStickerId, setActiveStickerId] = useState(
    campaign?.format?.includes('Chic') ? 'kinda-chic' :
    campaign?.format?.includes('Jimothy') ? 'jimothy-raccoon' :
    campaign?.format?.includes('Ravi') ? 'ravi-kishan-dance' : 'kinda-chic'
  );

  // Cumulative interaction data from persistent storage
  const [metrics, setMetrics] = useState(() => getCampaignInteractions(campaignId));
  
  // Modals & Drawers state
  const [shareDrawerOpen, setShareDrawerOpen] = useState(false);
  const [commentDrawerOpen, setCommentDrawerOpen] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);


  // Audio state
  const [audioPlaying, setAudioPlaying] = useState(false);
  const [currentAudioTrack, setCurrentAudioTrack] = useState(null);

  // Sync audio state with global memeAudioEngine
  useEffect(() => {
    const handleAudioChange = (e) => {
      setAudioPlaying(e.detail.isPlaying);
      setCurrentAudioTrack(e.detail.trackId);
    };

    window.addEventListener('meme_audio_state_change', handleAudioChange);
    return () => window.removeEventListener('meme_audio_state_change', handleAudioChange);
  }, []);

  // Increment actual cumulative view on mount and listen for interaction updates
  useEffect(() => {
    const updated = recordActualView(campaignId);
    setMetrics({ ...updated });

    const handleUpdate = (e) => {
      if (e.detail && e.detail[campaignId]) {
        setMetrics({ ...e.detail[campaignId] });
      }
    };

    window.addEventListener('meme_interactions_updated', handleUpdate);
    return () => window.removeEventListener('meme_interactions_updated', handleUpdate);
  }, [campaignId]);


  const brandName = campaign?.product?.split(' ')[0] || 'CampusFuel';
  const fullBrandName = campaign?.product || 'Campus Fuel Energy';
  const concept = campaign?.concept || "POV: Your 8 AM lecture started... but your brain didn't.";
  const headline = campaign?.headline || "Energy for the lecture you definitely weren't ready for.";
  const caption = campaign?.caption || "When attendance is mandatory but your energy isn't. ⚡ Tag someone who's staring blankly into their notebook right now.";
  const cta = campaign?.cta || "Grab your boost before the first bell.";
  const hashtags = campaign?.hashtags || ['#CollegeLife', '#POV', '#CampusEnergy', '#MemeMarketing'];
  const visualBadge = campaign?.visualBadge || 'POV: 8 AM lecture';

  const platforms = ['Instagram', 'TikTok', 'X', 'LinkedIn'];

  const activeSticker = TRENDING_MEME_ASSETS.find(s => s.id === activeStickerId) || TRENDING_MEME_ASSETS[0];

  // Actual like handler
  const handleLike = () => {
    const updated = toggleActualLike(campaignId);
    setMetrics({ ...updated });
    if (updated.likedByMe) {
      addToast('Liked! Cumulative interaction recorded.', 'info');
    }
  };

  // Store a real user comment. Comments are never AI-generated.
  const handleCommentSubmit = (e) => {
    e.preventDefault();
    const clean = commentText.trim();
    if (!clean) return;
    const updated = addActualComment(campaignId, clean, 'You');
    setMetrics({ ...updated });
    setCommentText('');
    addToast('Comment saved to this campaign.', 'success');
  };

  // Actual save handler
  const handleSave = () => {
    const updated = toggleActualSave(campaignId);
    setMetrics({ ...updated });
    addToast(updated.savedByMe ? 'Saved to your ad bookmarks.' : 'Removed from bookmarks.', 'info');
  };

  // Actual share handler
  const handleShareClick = (platformName = 'direct') => {
    const updated = recordActualShare(campaignId, platformName);
    setMetrics({ ...updated });

    const shareUrl = window.location.href;
    const shareTitle = `${fullBrandName} Meme Campaign: "${concept}"`;

    if (platformName === 'whatsapp') {
      window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(shareTitle + ' ' + shareUrl)}`, '_blank');
      addToast('Opening WhatsApp to share ad campaign!', 'info');
    } else if (platformName === 'twitter') {
      window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareTitle)}&url=${encodeURIComponent(shareUrl)}`, '_blank');
      addToast('Opening X / Twitter to share ad campaign!', 'info');
    } else if (platformName === 'linkedin') {
      window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`, '_blank');
      addToast('Opening LinkedIn to share marketing ad!', 'info');
    } else {
      navigator.clipboard?.writeText(shareUrl);
      setCopiedLink(true);
      addToast('Link copied! Real cumulative share count updated.', 'success');
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto space-y-3">
      
      {/* Platform Switcher Pills */}
      <div 
        role="tablist" 
        aria-label="Social media platform preview switcher"
        className="flex items-center justify-center gap-1.5 p-1 rounded-2xl bg-gray-100 border border-gray-200 text-xs font-semibold"
      >
        {platforms.map((p) => (
          <button
            key={p}
            role="tab"
            aria-selected={activePlatformTab === p}
            onClick={() => setActivePlatformTab(p)}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              activePlatformTab === p
                ? 'bg-white text-brand-primary shadow-sm font-bold'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            {p}
          </button>
        ))}
      </div>

      {/* Trending Meme Poster & Sticker Quick Selector */}
      <div className="bg-white p-2.5 rounded-2xl border border-gray-200 shadow-xs space-y-1.5">
        <div className="flex items-center justify-between text-[11px] font-bold text-gray-500 uppercase tracking-wider px-1">
          <span className="flex items-center gap-1 text-brand-accent">
            <Sparkles className="w-3.5 h-3.5" />
            Trending Sound FX & Stickers:
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (audioPlaying) {
                  memeAudio.stop();
                  addToast('Audio stopped', 'info');
                } else {
                  memeAudio.play(activeStickerId);
                  addToast(`Playing "${activeSticker.name}" sound FX!`, 'info');
                }
              }}
              className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all ${
                audioPlaying
                  ? 'bg-red-500 text-white animate-pulse'
                  : 'bg-purple-100 text-brand-accent hover:bg-purple-200'
              }`}
            >
              {audioPlaying ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
              <span>{audioPlaying ? 'Stop Audio' : 'Play Sound FX'}</span>
            </button>
            <span className="text-[10px] text-gray-400">Tap to equip & play</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-semibold">
          {TRENDING_MEME_ASSETS.map((asset) => {
            const isSelected = activeStickerId === asset.id;
            const isThisAudio = audioPlaying && currentAudioTrack === asset.id;

            return (
              <button
                key={asset.id}
                onClick={() => {
                  setActiveStickerId(asset.id);
                  memeAudio.play(asset.id);
                  addToast(`Equipped "${asset.name}" & playing sound!`, 'info');
                }}
                className={`px-2.5 py-1 rounded-xl whitespace-nowrap flex items-center gap-1 text-[11px] transition-all ${
                  isThisAudio
                    ? 'bg-brand-accent text-white font-black shadow-sm scale-105'
                    : isSelected
                    ? 'bg-brand-primary text-brand-secondary font-bold shadow-xs'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <span>{asset.emoji}</span>
                <span>{asset.name.split(' ')[0]}</span>
                {isThisAudio && <span className="w-1.5 h-1.5 rounded-full bg-brand-secondary animate-ping ml-0.5" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Social Ad Frame Card */}
      <div 
        className="bg-white rounded-3xl shadow-card border border-gray-200 overflow-hidden transition-all duration-300 hover:shadow-card-hover relative"
        aria-label="Interactive social ad campaign card"
      >
        
        {/* Post Header */}
        <div className="p-4 flex items-center justify-between border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-brand-accent to-brand-secondary text-white font-black text-sm flex items-center justify-center shadow-sm">
              {brandName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-xs text-gray-900 leading-none">
                  {brandName.toLowerCase().replace(/[^a-z0-9]/g, '')}_official
                </span>
                <span className="w-3.5 h-3.5 rounded-full bg-blue-500 text-white flex items-center justify-center text-[8px] font-bold" title="Verified Account">
                  ✓
                </span>
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-[10px] text-gray-400 font-medium">Sponsored</span>
                <span className="text-[9px] text-brand-accent font-bold px-1.5 py-0.2 rounded bg-purple-50">
                  {campaign?.format || 'Meme Ad'}
                </span>
              </div>
            </div>
          </div>
          
          {/* Cumulative Views Live Counter */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-gray-100 text-gray-600 text-[10px] font-mono font-bold" title="AI-generated demo engagement data">
            <Eye className="w-3 h-3 text-brand-accent" />
            <span>{(metrics.views || 18450).toLocaleString('en-IN')} views</span>
          </div>
        </div>

        {/* Meme Visual Creative Box with Trending Sticker / Poster Overlay */}
        <div className="relative bg-[#111111] min-h-[310px] flex flex-col justify-between p-6 text-white overflow-hidden group">
          <div className="absolute inset-0 bg-[radial-gradient(#333_1px,transparent_1px)] [background-size:16px_16px] opacity-40" />

          {/* Top Row: Floating Badges */}
          <div className="relative z-10 flex items-start justify-between gap-2">
            
            {/* Equippable Trending Meme Sticker / Poster Badge */}
            <div 
              className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider shadow-elevated ${
                activeSticker.id === 'kinda-chic' 
                  ? 'bg-pink-100 text-pink-900 border border-pink-300' 
                  : activeSticker.id === 'jimothy-raccoon'
                  ? 'bg-sky-400 text-gray-950 border border-sky-300 animate-pulse'
                  : activeSticker.id === 'ravi-kishan-dance'
                  ? 'bg-amber-400 text-brand-primary border border-amber-300'
                  : 'bg-brand-secondary text-brand-primary'
              }`}
            >
              <span>{activeSticker.emoji}</span>
              <span>{activeSticker.badgeText}</span>
            </div>

            <span className="text-[10px] tracking-widest uppercase font-mono px-2 py-0.5 rounded bg-white/10 text-gray-300">
              {activePlatformTab}
            </span>
          </div>

          {/* Central Meme Creative Visual Anchor */}
          <div className="relative z-10 py-4 text-center my-auto space-y-3">
            
            {/* Animated Meme Avatar / Micro Graphic */}
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-3xl bg-white/10 backdrop-blur-md border border-white/20 text-3xl shadow-glow-yellow mx-auto">
              {activeSticker.id === 'jimothy-raccoon' ? (
                <span className="animate-spin inline-block">🦝</span>
              ) : activeSticker.id === 'ravi-kishan-dance' ? (
                <span className="animate-bounce inline-block">🕺</span>
              ) : activeSticker.id === 'phir-hera-pheri' ? (
                <span className="animate-bounce inline-block">💰</span>
              ) : activeSticker.id === 'chin-tapak-dum-dum' ? (
                <span className="animate-pulse inline-block">🪄</span>
              ) : activeSticker.id === 'piche-to-dekho' ? (
                <span className="animate-float inline-block">👀</span>
              ) : activeSticker.id === 'wah-shampy-wah' ? (
                <span className="animate-bounce inline-block">🏆</span>
              ) : activeSticker.id === 'brazilian-phonk' ? (
                <span className="animate-pulse inline-block">⚡</span>
              ) : activeSticker.id === 'scuba-dance' ? (
                <span className="animate-float inline-block">🤿</span>
              ) : activeSticker.id === 'fahhhh-scream' ? (
                <span className="animate-pulse inline-block">💥</span>
              ) : activeSticker.id === 'skibidi-toilet' ? (
                <span className="animate-spin inline-block">🚽</span>
              ) : activeSticker.id === 'six-seven-trend' ? (
                <span className="animate-pulse inline-block">🔢</span>
              ) : activeSticker.id === 'drake-hotline' ? (
                <span className="animate-bounce inline-block">👉</span>
              ) : activeSticker.id === 'kinda-chic' ? (
                <span className="animate-pulse inline-block">🎀</span>
              ) : (
                <span>{activeSticker.emoji}</span>
              )}
            </div>

            <div className="text-xl sm:text-2xl font-black font-heading leading-tight tracking-tight text-white drop-shadow-md">
              "{concept}"
            </div>

            <div className="inline-block px-3.5 py-1 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-xs font-medium text-purple-200">
              Product Hero: <span className="font-bold text-white">{fullBrandName}</span>
            </div>
          </div>

          {/* Bottom Meme Sub-caption Quote */}
          <div className="relative z-10 pt-2 border-t border-white/10 flex items-center justify-between text-xs text-gray-300">
            <span className="italic text-[11px] text-brand-secondary truncate max-w-[260px]">
              {activeSticker.quote}
            </span>
            <span className="text-[10px] text-gray-400 uppercase font-mono">
              AI-Generated Social Proof
            </span>
          </div>
        </div>

        {/* CTA Bar immediately below visual */}
        <div className="bg-purple-50 px-4 py-2.5 flex items-center justify-between border-y border-purple-100">
          <div className="text-xs font-bold text-purple-950 truncate max-w-[220px]">
            {headline}
          </div>
          <button 
            onClick={() => handleShareClick('direct')}
            className="flex-shrink-0 px-3.5 py-1.5 rounded-lg bg-brand-accent hover:bg-brand-accentHover text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-transform active:scale-95"
            aria-label={`Call to action: ${cta}`}
          >
            <span>{cta}</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>

        {/* Social Interaction Buttons (ACTUAL ACCESSIBLE BUTTONS) */}
        <div className="p-4 space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3.5">
              
              {/* Like Button */}
              <button 
                onClick={handleLike} 
                className={`flex items-center gap-1.5 text-xs font-bold transition-transform active:scale-90 ${
                  metrics.likedByMe ? 'text-red-500' : 'text-gray-700 hover:text-black'
                }`}
                aria-label={metrics.likedByMe ? 'Unlike this ad' : 'Like this ad'}
              >
                <Heart className={`w-5 h-5 ${metrics.likedByMe ? 'fill-current text-red-500' : ''}`} />
                <span className="font-mono">{(metrics.likes ?? 0).toLocaleString('en-IN')}</span>
              </button>

              {/* Comment button */}
              <button
                onClick={() => setCommentDrawerOpen(true)}
                className="flex items-center gap-1.5 text-xs font-bold text-gray-700 hover:text-brand-accent transition-colors"
                aria-label={`${(metrics.comments || []).length} comments`}
              >
                <MessageCircle className="w-5 h-5" />
                <span className="font-mono">{(metrics.comments || []).length}</span>
              </button>

              {/* Accessible Share Button (Opens Real Share Drawer) */}
              <button 
                onClick={() => setShareDrawerOpen(true)}
                className="flex items-center gap-1.5 text-xs font-bold text-gray-700 hover:text-brand-accent transition-colors"
                aria-label={`Share ad campaign. ${(metrics.shares ?? 0)} shares recorded.`}
                aria-haspopup="dialog"
              >
                <Share2 className="w-5 h-5" />
                <span className="font-mono">{(metrics.shares ?? 0).toLocaleString('en-IN')}</span>
              </button>

            </div>

            {/* Save Bookmark Button */}
            <button 
              onClick={handleSave}
              className={`p-1.5 rounded-lg transition-colors ${
                metrics.savedByMe ? 'text-brand-accent bg-purple-50' : 'text-gray-700 hover:text-black'
              }`}
              aria-label={metrics.savedByMe ? 'Remove from saved' : 'Save ad creative'}
            >
              <Bookmark className={`w-5 h-5 ${metrics.savedByMe ? 'fill-current' : ''}`} />
            </button>
          </div>

          {/* Social Proof Metric Bar */}
          <div className="flex items-center justify-between text-xs text-gray-900 font-bold pt-1">
            <span>{(metrics.likes ?? 0).toLocaleString('en-IN')} likes</span>
            <span className="text-gray-500 text-xs font-semibold">{(metrics.comments || []).length} comments</span>
          </div>

          {/* Caption & Hashtags */}
          <div className="text-xs text-gray-800 leading-relaxed font-sans">
            <span className="font-bold mr-1.5">{brandName.toLowerCase().replace(/[^a-z0-9]/g, '')}_official</span>
            {caption}
          </div>

          <div className="flex flex-wrap gap-1.5 pt-1">
            {hashtags.map((tag, i) => (
              <span key={i} className="text-[11px] font-semibold text-brand-accent hover:underline cursor-pointer">
                {tag.startsWith('#') ? tag : `#${tag}`}
              </span>
            ))}
          </div>

          <div className="flex items-center justify-between text-[10px] text-gray-400 uppercase tracking-wider pt-1 font-mono">
            <span>Current demo feed • AI-generated engagement simulation</span>
            <span className="text-emerald-600 font-bold">● Active Delivery</span>
          </div>
        </div>
      </div>

      {/* REAL STORED COMMENT DRAWER */}
      {commentDrawerOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="comment-drawer-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs animate-fade-in"
        >
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-elevated border border-gray-200 overflow-hidden p-6 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 id="comment-drawer-title" className="text-base font-bold font-heading text-brand-primary">Campaign Comments</h3>
                <p className="text-xs text-gray-500 mt-1">Only comments submitted by visitors are stored here.</p>
              </div>
              <button onClick={() => setCommentDrawerOpen(false)} className="p-1.5 rounded-full hover:bg-gray-100 text-gray-500" aria-label="Close comments">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCommentSubmit} className="space-y-2">
              <textarea
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Write a comment..."
                rows={3}
                maxLength={500}
                className="w-full rounded-2xl border border-gray-200 px-4 py-3 text-sm outline-none focus:border-brand-accent resize-none"
              />
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] text-gray-400">{commentText.length}/500</span>
                <button type="submit" disabled={!commentText.trim()} className="px-4 py-2 rounded-xl bg-brand-primary text-white text-xs font-bold disabled:opacity-40 hover:bg-brand-accent transition-colors">
                  Post Comment
                </button>
              </div>
            </form>

            <div className="max-h-64 overflow-y-auto space-y-3 border-t border-gray-100 pt-4">
              {(metrics.comments || []).length === 0 ? (
                <p className="text-sm text-gray-400 text-center py-6">No comments yet.</p>
              ) : (
                [...metrics.comments].reverse().map((comment) => (
                  <div key={comment.id} className="rounded-2xl bg-gray-50 border border-gray-100 p-3">
                    <div className="flex items-center justify-between gap-3">
                      <span className="text-xs font-bold text-gray-900">{comment.author}</span>
                      <span className="text-[10px] text-gray-400">{new Date(comment.createdAt).toLocaleString()}</span>
                    </div>
                    <p className="text-sm text-gray-700 mt-1 whitespace-pre-wrap break-words">{comment.text}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* ACCESSIBLE SHARE MODAL / DRAWER (Requested by user) */}
      {shareDrawerOpen && (
        <div 
          role="dialog"
          aria-modal="true"
          aria-labelledby="share-drawer-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-xs animate-fade-in"
        >
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-elevated border border-gray-200 overflow-hidden p-6 space-y-5">
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Share2 className="w-5 h-5 text-brand-accent" />
                <h3 id="share-drawer-title" className="text-base font-bold font-heading text-brand-primary">
                  Share Campaign Ad
                </h3>
              </div>
              <button
                onClick={() => setShareDrawerOpen(false)}
                className="p-1.5 rounded-full hover:bg-gray-100 text-gray-500 transition-colors"
                aria-label="Close share dialog"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-gray-600 font-sans">
              Every share updates the live cumulative campaign share counter (currently <strong>{(metrics.shares ?? 0).toLocaleString('en-IN')} shares</strong>).
            </p>

            {/* Direct Copy Link Box */}
            <div className="p-3 rounded-2xl bg-gray-50 border border-gray-200 flex items-center justify-between gap-2">
              <span className="text-xs font-mono text-gray-600 truncate">
                {window.location.href}
              </span>
              <button
                onClick={() => handleShareClick('direct')}
                className="px-3 py-1.5 rounded-xl bg-brand-primary hover:bg-brand-accent text-white text-xs font-bold flex items-center gap-1 transition-colors flex-shrink-0"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5 text-brand-secondary" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            {/* Social Share Channel Buttons */}
            <div className="grid grid-cols-3 gap-2.5 text-xs font-bold">
              <button
                onClick={() => handleShareClick('whatsapp')}
                className="p-3 rounded-2xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 flex flex-col items-center gap-1 transition-colors"
              >
                <span className="text-lg">💬</span>
                <span>WhatsApp</span>
              </button>

              <button
                onClick={() => handleShareClick('twitter')}
                className="p-3 rounded-2xl bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 flex flex-col items-center gap-1 transition-colors"
              >
                <span className="text-lg">🐦</span>
                <span>X / Twitter</span>
              </button>

              <button
                onClick={() => handleShareClick('linkedin')}
                className="p-3 rounded-2xl bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 flex flex-col items-center gap-1 transition-colors"
              >
                <span className="text-lg">💼</span>
                <span>LinkedIn</span>
              </button>
            </div>

            <div className="text-center pt-2">
              <button
                onClick={() => setShareDrawerOpen(false)}
                className="text-xs font-bold text-gray-400 hover:text-black"
              >
                Done
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
