import React from 'react';
import { useApp } from '../context/AppContext';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export default function ToastContainer() {
  const { toasts, removeToast } = useApp();

  if (!toasts.length) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 max-w-sm w-full pointer-events-none">
      {toasts.map((toast) => {
        const isSuccess = toast.type === 'success';
        const isWarning = toast.type === 'warning';
        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start gap-3 p-4 rounded-xl shadow-elevated border transition-all duration-300 animate-slide-up ${
              isSuccess
                ? 'bg-white border-brand-success text-brand-primary'
                : isWarning
                ? 'bg-white border-brand-warning text-brand-primary'
                : 'bg-[#111111] border-gray-800 text-white'
            }`}
          >
            <div className="flex-shrink-0 mt-0.5">
              {isSuccess && <CheckCircle2 className="w-5 h-5 text-brand-success" />}
              {isWarning && <AlertCircle className="w-5 h-5 text-brand-warning" />}
              {!isSuccess && !isWarning && <Info className="w-5 h-5 text-brand-secondary" />}
            </div>
            <div className="flex-1 text-sm font-medium leading-relaxed">
              {toast.text}
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className="flex-shrink-0 p-1 rounded-md hover:bg-gray-100 hover:text-black transition-colors"
              aria-label="Dismiss"
            >
              <X className="w-4 h-4 opacity-60" />
            </button>
          </div>
        );
      })}
    </div>
  );
}
