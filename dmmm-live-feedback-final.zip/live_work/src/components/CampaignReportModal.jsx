import React from 'react';
import { useApp } from '../context/AppContext';
import { X, Printer, Download, Sparkles, CheckCircle2, ShieldCheck, IndianRupee, BarChart3, Lock } from 'lucide-react';

export default function CampaignReportModal({ campaign, isOpen, onClose }) {
  const { isPro, openProPaywall } = useApp();

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const camp = campaign || {};
  const m2 = camp.m2Score || { overall: 8.2, attention: 8, relatability: 9, brandFit: 8, trendRelevance: 7, shareability: 8, messageClarity: 9 };
  const roi = camp.roiDefaults || { budget: 10000, reach: 50000, engagementRate: 5, ctr: 3, conversionRate: 10, aov: 500 };

  // Calculate default ROI metrics for summary
  const estClicks = Math.round(roi.reach * (roi.ctr / 100));
  const estConversions = Math.round(estClicks * (roi.conversionRate / 100));
  const estRevenue = estConversions * roi.aov;
  const estRoi = Math.round(((estRevenue - roi.budget) / roi.budget) * 100);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity no-print"
        onClick={onClose}
      />

      {/* Report Modal */}
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-elevated border border-gray-200 overflow-hidden z-10 my-auto max-h-[92vh] flex flex-col">
        
        {/* Modal Action Bar (Hidden when printing) */}
        <div className="p-4 sm:p-5 bg-[#111111] text-white flex items-center justify-between no-print flex-shrink-0">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-brand-accent text-white">
              <Sparkles className="w-4 h-4 text-brand-secondary" />
            </span>
            <div>
              <h3 className="text-base font-bold font-heading">
                Campaign Strategy & Audit Report
              </h3>
              <p className="text-[11px] text-gray-400">
                Official PDF-exportable memorandum
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isPro ? (
              <button
                onClick={handlePrint}
                className="px-4 py-2 rounded-xl bg-brand-accent hover:bg-brand-accentHover text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-transform active:scale-95"
              >
                <Printer className="w-4 h-4" />
                <span>Print / Save as PDF</span>
              </button>
            ) : (
              <button
                onClick={openProPaywall}
                className="px-4 py-2 rounded-xl bg-brand-secondary text-brand-primary text-xs font-black flex items-center gap-1.5 shadow-sm"
              >
                <Lock className="w-4 h-4" />
                <span>Unlock Pro to Download</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors ml-1"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="p-6 sm:p-10 overflow-y-auto space-y-8 bg-white text-gray-900 printable-report">
          
          {/* Document Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-6 border-b-2 border-gray-900">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-2xl font-black font-heading tracking-tight text-brand-primary">
                  MEMEVERTISING
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded bg-gray-100 text-gray-700">
                  CONFIDENTIAL CAMPAIGN DOSSIER
                </span>
              </div>
              <p className="text-xs text-gray-500 font-sans">
                "Don't Just Make a Meme. Make It Marketable."
              </p>
            </div>

            <div className="text-left sm:text-right text-xs text-gray-500 font-mono">
              <p>Generated: {new Date(camp.createdAt || Date.now()).toLocaleDateString()}</p>
              <p>Campaign ID: {camp.id || 'CAMP-PREVIEW'}</p>
              <p>Platform: {camp.platform || 'Instagram'}</p>
            </div>
          </div>

          {/* Section 1: Campaign Metadata */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-2xl bg-gray-50 border border-gray-200">
            <div>
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Product / Brand</span>
              <span className="text-sm font-bold text-gray-900">{camp.product || 'Energy Drink'}</span>
            </div>
            <div>
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Objective</span>
              <span className="text-sm font-bold text-gray-900">{camp.objective || 'Engagement'}</span>
            </div>
            <div>
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Target Audience</span>
              <span className="text-sm font-bold text-gray-900">{camp.audience || 'College Students'}</span>
            </div>
            <div>
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Meme Format</span>
              <span className="text-sm font-bold text-brand-accent">{camp.format || 'POV'}</span>
            </div>
          </div>

          {/* Section 2: Creative Strategy & Assets */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-gray-900 font-heading border-b pb-2 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-brand-accent" />
              Creative Architecture & Copy
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-purple-50/50 border border-purple-100 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-purple-700">Meme Concept Hook</span>
                <p className="text-sm font-bold text-gray-900 font-heading">
                  "{camp.concept || "POV: Your 8 AM lecture started... but your brain didn't."}"
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-gray-50 border border-gray-200 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-gray-500">Ad Headline</span>
                <p className="text-sm font-bold text-gray-900">
                  {camp.headline || "Energy for the lecture you definitely weren't ready for."}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-gray-50 border border-gray-200 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-gray-700 uppercase tracking-wider text-[10px]">Caption & CTA</span>
                <span className="text-brand-accent font-bold">Call to Action: {camp.cta || 'Grab your boost'}</span>
              </div>
              <p className="text-xs text-gray-800 leading-relaxed font-sans">
                {camp.caption || "When attendance is mandatory but your energy isn't. ⚡"}
              </p>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {(camp.hashtags || ['#CollegeLife', '#POV', '#MemeMarketing']).map((t, i) => (
                  <span key={i} className="text-[10px] font-semibold text-brand-accent bg-purple-50 px-2 py-0.5 rounded">
                    {t}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-200/60 space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800">Deployment Strategy</span>
              <p className="text-xs text-gray-800 leading-relaxed">
                {camp.strategy || "Ground the meme in a high-friction universal moment, placing the product as the hero resolution rather than an intrusive ad."}
              </p>
            </div>
          </div>

          {/* Section 3: M² Score & Risk Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
            <div className="p-5 rounded-2xl border border-gray-200 bg-gray-50/50 space-y-3">
              <div className="flex items-center justify-between">
                <h5 className="text-xs font-bold uppercase tracking-wider text-gray-700 font-heading">
                  M² Viability Score
                </h5>
                <span className="text-xl font-black font-heading text-brand-accent">
                  {m2.overall} / 10
                </span>
              </div>
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between"><span>Attention Hook:</span><strong>{m2.attention}/10</strong></div>
                <div className="flex justify-between"><span>Relatability Index:</span><strong>{m2.relatability}/10</strong></div>
                <div className="flex justify-between"><span>Product Brand Fit:</span><strong>{m2.brandFit}/10</strong></div>
                <div className="flex justify-between"><span>Trend Relevance:</span><strong>{m2.trendRelevance}/10</strong></div>
                <div className="flex justify-between"><span>Shareability Probability:</span><strong>{m2.shareability}/10</strong></div>
                <div className="flex justify-between"><span>Message Clarity:</span><strong>{m2.messageClarity}/10</strong></div>
              </div>
            </div>

            <div className="p-5 rounded-2xl border border-gray-200 bg-gray-50/50 space-y-3">
              <div className="flex items-center justify-between">
                <h5 className="text-xs font-bold uppercase tracking-wider text-gray-700 font-heading">
                  Meme Risk Check Audit
                </h5>
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  STATUS: LOW RISK
                </span>
              </div>
              <div className="space-y-1.5 text-xs">
                {(camp.riskCheck || [
                  { dimension: 'Brand Fit', status: 'LOW' },
                  { dimension: 'Audience Misunderstanding', status: 'LOW' },
                  { dimension: 'Trend Dependency', status: 'LOW' },
                  { dimension: 'Product Clarity', status: 'LOW' },
                  { dimension: 'Context Risk', status: 'LOW' },
                ]).map((r, i) => (
                  <div key={i} className="flex justify-between items-center">
                    <span className="text-gray-600">{r.dimension}:</span>
                    <span className="font-bold text-[10px] px-2 py-0.5 rounded bg-white border text-emerald-700">
                      {r.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Section 4: ROI & A/B Benchmark Summary */}
          <div className="p-5 rounded-2xl bg-gray-50 border border-gray-200 space-y-3">
            <h5 className="text-xs font-bold uppercase tracking-wider text-gray-700 font-heading">
              Financial Projections & Split-Test Delta
            </h5>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-2.5 rounded-xl bg-white border border-gray-200">
                <span className="text-[10px] text-gray-400 uppercase font-bold block">Assumed Budget</span>
                <span className="text-sm font-bold text-gray-900">₹{roi.budget.toLocaleString('en-IN')}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white border border-gray-200">
                <span className="text-[10px] text-gray-400 uppercase font-bold block">Est. Revenue</span>
                <span className="text-sm font-bold text-emerald-600">₹{estRevenue.toLocaleString('en-IN')}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white border border-gray-200">
                <span className="text-[10px] text-gray-400 uppercase font-bold block">Projected ROI</span>
                <span className="text-sm font-bold text-brand-accent">+{estRoi}%</span>
              </div>
              <div className="p-2.5 rounded-xl bg-white border border-gray-200">
                <span className="text-[10px] text-gray-400 uppercase font-bold block">A/B Lift Over Static</span>
                <span className="text-sm font-bold text-purple-700">+248% CTR</span>
              </div>
            </div>
            <p className="text-[10px] text-gray-400 text-center pt-1 font-sans">
              All quantitative metrics are simulated illustrative projections based on historical benchmark averages.
            </p>
          </div>

          {/* Report Footer */}
          <div className="pt-6 border-t border-gray-200 flex justify-between items-center text-xs text-gray-400 font-sans">
            <span>MEMEVERTISING Intelligence Platform</span>
            <span>https://memevertising.io</span>
          </div>

        </div>
      </div>
    </div>
  );
}
