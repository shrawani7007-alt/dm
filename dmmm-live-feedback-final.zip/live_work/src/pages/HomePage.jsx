import React from 'react';
import { useApp } from '../context/AppContext';
import SocialCardPreview from '../components/SocialCardPreview';
import RefinedPosterShowcase from '../components/RefinedPosterShowcase';
import MemeAudioDanceSoundboard from '../components/MemeAudioDanceSoundboard';
import BrandPopularityLeaderboard from '../components/BrandPopularityLeaderboard';
import { 
  Sparkles, ArrowRight, ShieldCheck, Zap, TrendingUp, Users, Heart, Share2, 
  Eye, MessageSquare, ChevronRight, Check, CheckCircle2, Lock, Flame, Compass,
  Sliders, BarChart3, ShieldAlert, Download, Layers, Trophy, Music
} from 'lucide-react';

export default function HomePage({ setActivePage }) {
  const { openCheckout, currentCampaign } = useApp();

  const handleStartBuilding = () => {
    setActivePage('campaign-builder');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleExploreVault = () => {
    setActivePage('brand-vault');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const problemCards = [
    {
      num: '01',
      title: 'SCROLL',
      body: 'Your audience keeps moving.',
      detail: 'Traditional promotional ads are tuned out in 0.4 seconds. Feed blindness kills expensive static creative before viewers even read the brand headline.'
    },
    {
      num: '02',
      title: 'SKIP',
      body: 'The joke doesn’t connect with the product.',
      detail: 'Brands copy trending audio or formats with zero structural bridge to their product value. Users laugh at the meme, swipe away, and never remember what was sold.'
    },
    {
      num: '03',
      title: 'FORGET',
      body: 'People remember the meme but forget the brand.',
      detail: 'The dreaded vanity virality trap: 10 million views, 50,000 comments, zero website clicks, and not a single unit moved from inventory.'
    }
  ];

  const memeAdvantageCards = [
    {
      title: 'Attention',
      icon: Eye,
      color: 'bg-purple-100 text-brand-accent',
      desc: 'Breaks the scroll autopilot by using visual formats users actively look forward to consuming.'
    },
    {
      title: 'Emotion',
      icon: Heart,
      color: 'bg-amber-100 text-amber-600',
      desc: 'Transfers positive dopamine and situational catharsis directly onto product perception.'
    },
    {
      title: 'Shareability',
      icon: Share2,
      color: 'bg-emerald-100 text-brand-success',
      desc: 'Turns prospective customers into unpaid media distribution nodes sharing ads in private group chats.'
    },
    {
      title: 'Recall',
      icon: Zap,
      color: 'bg-blue-100 text-blue-600',
      desc: 'Connects the brand solution to everyday recurring triggers (e.g., 8 AM fatigue, 3 PM sugar crash).'
    },
    {
      title: 'Participation',
      icon: Users,
      color: 'bg-rose-100 text-rose-600',
      desc: 'Invites comments, taggings, and remixing that traditional broadcast advertising can never achieve.'
    }
  ];

  const howItWorksSteps = [
    {
      step: '01',
      name: 'Explore',
      summary: 'Understand meme formats, examples and cultural context.',
      tag: 'Curation'
    },
    {
      step: '02',
      name: 'Strategize',
      summary: 'Choose audience, objective, personality and platform.',
      tag: 'Alignment'
    },
    {
      step: '03',
      name: 'Create',
      summary: 'Generate the campaign concept, headline, caption and CTA.',
      tag: 'Execution'
    },
    {
      step: '04',
      name: 'Optimize',
      summary: 'Evaluate fit, risk, ROI and alternative versions.',
      tag: 'Audit'
    }
  ];

  const funnelStages = [
    { name: 'Trend', desc: 'Cultural moment or format resonance', color: 'bg-[#111111] text-white' },
    { name: 'Attention', desc: 'Feed stop-rate in under 0.8s', color: 'bg-purple-950 text-purple-200' },
    { name: 'Emotion', desc: 'Relatability, humor, shared relief', color: 'bg-purple-900 text-purple-100' },
    { name: 'Engagement', desc: 'Likes, comments, bookmarks', color: 'bg-brand-accent text-white' },
    { name: 'Sharing', desc: 'Direct message sends & peer tagging', color: 'bg-purple-600 text-white' },
    { name: 'Brand Awareness', desc: 'Clear product-to-punchline attribution', color: 'bg-amber-400 text-brand-primary' },
    { name: 'Potential Conversion', desc: 'Downstream trial, clicks & measurable sales', color: 'bg-brand-secondary text-brand-primary font-black' },
  ];

  return (
    <div className="space-y-24 sm:space-y-32 pb-20">
      {/* SECTION 5: HERO SECTION */}
      <section className="pt-8 sm:pt-14 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Hero Copy & Actions (7 cols) */}
          <div className="lg:col-span-7 space-y-6 text-left">
            
            {/* Philosophy Pill */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-50 border border-purple-200 text-brand-accent text-xs font-bold tracking-wider uppercase">
              <span className="w-2 h-2 rounded-full bg-brand-accent animate-pulse" />
              CREATE → CONNECT → EVALUATE → OPTIMIZE
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading text-brand-primary tracking-tight leading-[1.1]">
              Don't Just Make a Meme.<br />
              <span className="text-brand-accent underline decoration-brand-secondary decoration-wavy decoration-2">
                Make It Marketable.
              </span>
            </h1>

            {/* Supporting Copy */}
            <p className="text-lg sm:text-xl text-gray-600 font-sans leading-relaxed max-w-2xl">
              Create meme campaigns that connect the joke to the product — then evaluate whether the idea actually makes marketing sense.
            </p>

            {/* Prominent Core Differentiator Banner specified in prompt */}
            <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-purple-50 via-amber-50/50 to-purple-50 border-2 border-brand-accent/30 shadow-sm relative overflow-hidden">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-xl bg-brand-accent text-brand-secondary flex-shrink-0 mt-0.5">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold tracking-widest text-brand-accent block mb-1">
                    THE MEMEVERTISING LAW
                  </span>
                  <p className="text-base sm:text-lg font-black font-heading text-gray-900 leading-snug">
                    "AI can generate a meme. MEMEVERTISING asks whether that meme makes marketing sense."
                  </p>
                </div>
              </div>
            </div>

            {/* Primary & Secondary CTAs */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={handleStartBuilding}
                className="py-4 px-8 rounded-2xl bg-brand-primary hover:bg-brand-accent text-white font-black text-sm uppercase tracking-wider shadow-card-hover hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 group"
              >
                <span>Create Your Campaign</span>
                <ArrowRight className="w-4 h-4 text-brand-secondary group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={handleExploreVault}
                className="py-4 px-8 rounded-2xl bg-white border border-gray-300 hover:border-gray-900 hover:bg-gray-50 text-gray-900 font-bold text-sm tracking-wide transition-all text-center"
              >
                Explore Brand Vault
              </button>
            </div>

            {/* Trust Micro-Row */}
            <div className="pt-2 flex items-center gap-6 text-xs text-gray-500 font-medium">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-brand-success" />
                <span>Zero fluff generation</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-brand-success" />
                <span>Audit before spending</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-brand-success" />
                <span>Freemium access</span>
              </div>
            </div>

          </div>

          {/* Right Column: Hero Visual Card (5 cols) */}
          <div className="lg:col-span-5 relative">
            {/* Decorative background glow */}
            <div className="absolute -inset-4 bg-gradient-to-r from-purple-200 to-amber-200 rounded-4xl blur-3xl opacity-40 -z-10" />

            {/* Social Ad Card preview with Campus Fuel demo */}
            <SocialCardPreview campaign={currentCampaign} />
          </div>

        </div>
      </section>

      {/* REFINED ADVERTISEMENT POSTERS & LAYOUT STUDIO */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <RefinedPosterShowcase />
      </section>

      {/* MEME AUDIO & DANCE FX ENGINE (Brazilian Phonk, FAHHHH!, Scuba Dance, Gucci Ravi Kishan, etc.) */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <MemeAudioDanceSoundboard />
      </section>

      {/* LIVE BRAND POPULARITY LEADERBOARD & CUSTOMER VERIFIED SOCIAL PROOF */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <BrandPopularityLeaderboard />
      </section>

      {/* SECTION 6: THE PROBLEM */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-danger bg-red-50 px-3 py-1 rounded-full border border-red-200">
            Current Marketing Reality
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-heading text-brand-primary">
            The Problem
          </h2>
          <p className="text-sm sm:text-base text-gray-600 font-sans">
            Views are easy. Conversion and brand equity are hard. Here is where 90% of meme ads implode:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {problemCards.map((card, idx) => (
            <div
              key={idx}
              className="bg-white rounded-3xl p-8 shadow-card border border-gray-200/80 hover:border-brand-accent/50 hover:shadow-card-hover transition-all duration-300 group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-baseline justify-between mb-4">
                  <span className="text-3xl font-black font-mono text-gray-200 group-hover:text-brand-accent transition-colors">
                    {card.num}
                  </span>
                  <span className="text-xs font-bold uppercase tracking-wider text-brand-danger bg-red-50 px-2 py-0.5 rounded">
                    Friction Point
                  </span>
                </div>
                <h3 className="text-2xl font-black font-heading text-brand-primary mb-2">
                  {card.title}
                </h3>
                <p className="text-base font-bold text-gray-900 mb-3 font-sans">
                  "{card.body}"
                </p>
                <p className="text-xs text-gray-500 leading-relaxed font-sans">
                  {card.detail}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-gray-100 flex items-center justify-between text-xs text-gray-400">
                <span>MEMEVERTISING Solution</span>
                <span className="font-bold text-brand-accent">Strategy Bridge →</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SECTION 7: THE MEME ADVANTAGE */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-accent bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
            Psychological Triggers
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-heading text-brand-primary">
            The Meme Advantage
          </h2>
          <p className="text-sm sm:text-base text-gray-600 font-sans">
            Why humor and internet vernacular outperform traditional direct-response banners when executed with discipline.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
          {memeAdvantageCards.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="bg-white rounded-3xl p-6 shadow-card border border-gray-200 hover:shadow-card-hover hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className={`w-12 h-12 rounded-2xl ${item.color} flex items-center justify-center mb-4 shadow-sm`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold font-heading text-brand-primary mb-2">
                    {item.title}
                  </h3>
                  <p className="text-xs text-gray-600 leading-relaxed font-sans">
                    {item.desc}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-gray-100 text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                  Advantage 0{idx + 1}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* SECTION 8: HOW MEME ADVERTISING WORKS */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-[#111111] rounded-4xl p-8 sm:p-14 text-white shadow-elevated relative overflow-hidden">
          <div className="absolute right-0 top-0 w-96 h-96 bg-brand-accent/20 rounded-full blur-3xl pointer-events-none" />

          <div className="max-w-2xl mb-12 sm:mb-16 space-y-3">
            <span className="text-xs font-bold uppercase tracking-widest text-brand-secondary bg-white/10 px-3 py-1 rounded-full">
              Structured Methodology
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black font-heading text-white">
              How Meme Advertising Works
            </h2>
            <p className="text-sm sm:text-base text-gray-300 font-sans">
              A 4-step framework turning fleeting internet jokes into sustainable, accountable growth channels.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {howItWorksSteps.map((step, idx) => (
              <div 
                key={idx}
                className="bg-white/5 border border-white/10 rounded-3xl p-6 hover:bg-white/10 transition-colors flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-3xl font-black font-mono text-brand-secondary">
                      {step.step}
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-white/10 text-gray-300">
                      {step.tag}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold font-heading text-white mb-2">
                    {step.name}
                  </h3>
                  <p className="text-xs text-gray-300 leading-relaxed font-sans">
                    {step.summary}
                  </p>
                </div>
                <div className="mt-6 pt-4 border-t border-white/10 text-[11px] text-gray-400 flex items-center justify-between">
                  <span>Phase {idx + 1}</span>
                  <span className="text-brand-secondary">Ready →</span>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-10 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-gray-400 font-sans">
              Built on verified advertising science — not random viral guessing.
            </p>
            <button
              onClick={handleStartBuilding}
              className="py-3 px-6 rounded-xl bg-brand-accent hover:bg-brand-accentHover text-white font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2"
            >
              <span>Launch Campaign Builder</span>
              <ArrowRight className="w-3.5 h-3.5 text-brand-secondary" />
            </button>
          </div>
        </div>
      </section>

      {/* SECTION 9: MEME MARKETING FUNNEL */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-accent bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
            Conversion Architecture
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-heading text-brand-primary">
            The Meme Marketing Funnel
          </h2>
          <p className="text-sm sm:text-base text-gray-600 font-sans">
            How a cultural impulse journeys from initial feed stop to validated transaction.
          </p>
        </div>

        {/* Visual Funnel Stack */}
        <div className="max-w-3xl mx-auto space-y-3">
          {funnelStages.map((stage, idx) => {
            const widthPercentage = 100 - (idx * 6);
            return (
              <div 
                key={idx}
                className="mx-auto transition-transform hover:scale-[1.01]"
                style={{ width: `${widthPercentage}%` }}
              >
                <div className={`p-4 sm:p-5 rounded-2xl shadow-sm flex items-center justify-between ${stage.color}`}>
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-xs font-mono font-bold">
                      {idx + 1}
                    </span>
                    <div>
                      <h3 className="text-base sm:text-lg font-bold font-heading leading-none">
                        {stage.name}
                      </h3>
                      <p className="text-xs opacity-80 mt-1 font-sans">
                        {stage.desc}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs font-mono opacity-80 uppercase tracking-widest hidden sm:block">
                    Stage 0{idx + 1}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* SECTION 10: FREE VS PRO */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16 space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-primary bg-gray-100 px-3 py-1 rounded-full">
            Transparent Freemium Model
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-heading text-brand-primary">
            Free vs Pro
          </h2>
          <p className="text-sm sm:text-base text-gray-600 font-sans">
            Learn and generate for free. Upgrade when you need executive risk auditing, scoring, and financial simulations.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-4xl mx-auto items-stretch">
          
          {/* FREE CARD */}
          <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-card border border-gray-200 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-2xl font-bold font-heading text-gray-900">FREE</h3>
                <span className="text-xs font-bold uppercase px-3 py-1 rounded-full bg-gray-100 text-gray-700">
                  Exploration & Creation
                </span>
              </div>

              <div className="mb-6">
                <span className="text-4xl sm:text-5xl font-black font-heading text-brand-primary">₹0</span>
                <span className="text-xs text-gray-500 ml-2">Forever free</span>
              </div>

              <p className="text-xs text-gray-600 mb-6 font-sans">
                Ideal for solo founders, curious creators, and marketers testing meme creative angles.
              </p>

              <div className="space-y-3 text-sm text-gray-700 font-sans">
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-success flex-shrink-0" />
                  <span>Brand Case Studies</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-success flex-shrink-0" />
                  <span>Meme Library</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-success flex-shrink-0" />
                  <span>Meme Formats</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-success flex-shrink-0" />
                  <span>Campaign Builder</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-success flex-shrink-0" />
                  <span>Basic Ad Copy</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-success flex-shrink-0" />
                  <span>Caption Suggestions</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-success flex-shrink-0" />
                  <span>CTA Suggestions</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-success flex-shrink-0" />
                  <span>Campaign Preview</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleStartBuilding}
              className="mt-8 w-full py-4 rounded-2xl border-2 border-brand-primary hover:bg-gray-100 text-brand-primary font-bold text-sm tracking-wide transition-colors"
            >
              Start Creating for Free
            </button>
          </div>

          {/* PRO CARD */}
          <div className="bg-[#111111] text-white rounded-3xl p-8 sm:p-10 shadow-elevated border-2 border-brand-accent relative flex flex-col justify-between overflow-hidden">
            <div className="absolute right-0 top-0 w-48 h-48 bg-brand-accent/30 rounded-full blur-3xl pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <h3 className="text-2xl font-bold font-heading text-white">PRO</h3>
                  <span className="p-1 rounded-md bg-brand-secondary text-brand-primary">
                    <Sparkles className="w-3.5 h-3.5 fill-current" />
                  </span>
                </div>
                <span className="text-xs font-black uppercase tracking-wider px-3 py-1 rounded-full bg-brand-secondary text-brand-primary">
                  Recommended
                </span>
              </div>

              <div className="mb-6">
                <span className="text-4xl sm:text-5xl font-black font-heading text-brand-secondary">₹999</span>
                <span className="text-xs text-gray-400 ml-2">/ month (cancel anytime)</span>
              </div>

              <p className="text-xs text-gray-300 mb-6 font-sans">
                For growth marketing teams, agencies, and brands putting real ad spend behind memes.
              </p>

              <div className="space-y-3 text-sm text-gray-200 font-sans">
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                  <span><strong>M² Meme Marketing Score</strong> (6 Dimensions)</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                  <span><strong>Meme Risk Check</strong> (Brand Fit & Misunderstanding)</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                  <span><strong>ROI Lab</strong> (Live Dynamic Financial Simulator)</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                  <span><strong>A/B Testing Lab</strong> (Meme vs Traditional Benchmarks)</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                  <span><strong>Campaign Insights</strong></span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                  <span><strong>Saved Campaigns</strong> Dashboard</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                  <span><strong>Downloadable & Printable</strong> Campaign Reports</span>
                </div>
              </div>
            </div>

            <button
              onClick={openCheckout}
              className="mt-8 w-full py-4 rounded-2xl bg-brand-accent hover:bg-brand-accentHover text-white font-bold text-sm tracking-wider uppercase shadow-glow-accent hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-brand-secondary" />
              Get Pro (Simulated Instant Unlock)
            </button>
          </div>

        </div>
      </section>

    </div>
  );
}
