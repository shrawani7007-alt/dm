import React from 'react';
import { 
  Sparkles, CheckCircle2, AlertTriangle, ArrowRight, Eye, Heart, 
  Smile, Globe, Share2, UserCheck, ShieldAlert, CheckCircle, Info 
} from 'lucide-react';

export default function WhyMemeMarketingPage({ setActivePage }) {
  const sixReasons = [
    {
      number: '01',
      icon: Eye,
      title: 'Attention / Familiarity',
      explanation: 'Memes leverage existing neural pathways. When users encounter a recognized format (like POV or Drake), their cognitive resistance drops because they already know how the joke works.',
      example: 'Instead of spending 3 seconds explaining a comparison table, a Drake Approves/Disapproves meme visually communicates the contrast in 200 milliseconds.'
    },
    {
      number: '02',
      icon: Heart,
      title: 'Relatability',
      explanation: 'Traditional ads lecture the customer on how great the company is. Meme marketing validates the customer’s actual, unpolished lived reality—their laziness, deadline stress, or morning exhaustion.',
      example: 'A productivity app admitting “I snoozed my alarm 6 times today” wins 10x more trust than a generic corporate post about “optimizing maximum workflow synergy.”'
    },
    {
      number: '03',
      icon: Smile,
      title: 'Humor',
      explanation: 'Laughter triggers endorphins that reduce skepticism and disarm defensive advertising filters. When a brand makes people genuinely laugh, it earns psychological goodwill.',
      example: 'Zomato poking fun at broken Monday diet resolutions creates instant warmth and craving without ever sounding like an aggressive food coupon salesman.'
    },
    {
      number: '04',
      icon: Globe,
      title: 'Cultural Relevance',
      explanation: 'Culture is the modern marketer’s operating system. Brands that fluently participate in internet culture feel alive, agile, and plugged into the modern zeitgeist.',
      example: 'Duolingo’s chaotic green owl on TikTok reacting to Grammy outfits and pop culture gossip turned a language drill app into a beloved entertainment phenomenon.'
    },
    {
      number: '05',
      icon: Share2,
      title: 'Shareability',
      explanation: 'Nobody forwards a boring promotional brochure into their group chat. People do forward relatable memes with messages like “@rahul this is literally you.”',
      example: 'Spotify Wrapped transforms complex algorithmic listening data into personalized, self-deprecating badges that millions of people proudly share on Instagram stories.'
    },
    {
      number: '06',
      icon: UserCheck,
      title: 'Brand Personality',
      explanation: 'A distinct, human, slightly self-deprecating brand persona creates a durable moat that competitors with bigger media budgets cannot easily clone.',
      example: 'Ryanair openly acknowledging their ultra-cheap flights lack luxury perks made their rock-bottom ticket pricing iconic and untouchable.'
    }
  ];

  const fitPoints = [
    { title: 'Social-first audiences', desc: 'Gen Z, digital natives, and internet subcultures who consume short-form video and carousels daily.' },
    { title: 'Informal brand voice', desc: 'Brands willing to speak like a funny friend rather than a legal compliance committee.' },
    { title: 'Products naturally integrated into jokes', desc: 'Beverages, snacks, apps, streetwear, gaming gear, and tools solving relatable everyday friction.' },
    { title: 'Engagement/community objectives', desc: 'Campaigns designed to spark comments, user-generated remakes, and community conversations.' }
  ];

  const cautionPoints = [
    { title: 'Sensitive products', desc: 'Healthcare, funeral services, crisis management, life insurance, and sensitive legal situations.' },
    { title: 'High-stakes communication', desc: 'Product recalls, privacy updates, regulatory announcements, or safety advisories.' },
    { title: 'Product becomes secondary to joke', desc: 'When the punchline works even if your brand is erased, you are subsidizing someone else’s entertainment.' },
    { title: 'Trend dependency', desc: 'Relying on TikTok sounds or ephemeral memes that die within 7 days before your approval chain finishes.' },
    { title: 'High context risk', desc: 'Using meme templates that originated in polarizing, offensive, or controversial subcultures.' },
    { title: 'Potential audience misunderstanding', desc: 'When older or enterprise B2B buyers mistake internet irony for childish incompetence.' }
  ];

  return (
    <div className="space-y-20 sm:space-y-28 pb-20 pt-8 sm:pt-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold uppercase tracking-widest text-brand-accent bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
          Executive Education
        </span>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading text-brand-primary tracking-tight">
          Why Meme Marketing?
        </h1>
        <p className="text-base sm:text-lg text-gray-600 font-sans leading-relaxed">
          The psychology, mechanics, and guardrails of turning internet culture into measurable commercial advantage.
        </p>
      </div>

      {/* The Six Reasons Grid */}
      <section className="space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-gray-200 pb-4">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold font-heading text-brand-primary">
              Six Psychological Catalysts
            </h2>
            <p className="text-xs sm:text-sm text-gray-500 font-sans">
              Why meme architecture bypasses standard customer defense shields.
            </p>
          </div>
          <span className="text-xs font-bold text-brand-accent uppercase tracking-wider font-mono">
            Framework 01 → 06
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sixReasons.map((reason, idx) => {
            const Icon = reason.icon;
            return (
              <div
                key={idx}
                className="bg-white rounded-3xl p-7 shadow-card border border-gray-200 hover:shadow-card-hover hover:border-brand-accent/40 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-black font-mono text-gray-300">
                      {reason.number}
                    </span>
                    <div className="w-10 h-10 rounded-xl bg-purple-50 text-brand-accent flex items-center justify-center">
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>

                  <h3 className="text-xl font-bold font-heading text-brand-primary mb-2">
                    {reason.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-gray-600 font-sans leading-relaxed mb-4">
                    {reason.explanation}
                  </p>
                </div>

                <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-100 text-xs text-gray-700">
                  <span className="font-bold text-brand-primary block mb-1">Real-World Case:</span>
                  <p className="italic text-gray-600 font-sans">"{reason.example}"</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* MARKETING REALITY CHECK BANNER */}
      <section className="bg-[#111111] rounded-4xl p-8 sm:p-14 text-white shadow-elevated relative overflow-hidden">
        <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-brand-accent/30 rounded-full blur-3xl pointer-events-none" />

        <div className="text-center max-w-3xl mx-auto space-y-6 relative z-10">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-secondary bg-white/10 px-3 py-1 rounded-full">
            Crucial Distinction
          </span>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black font-heading text-white">
            Marketing Reality Check
          </h2>

          {/* Core Formula Formula Box */}
          <div className="py-6 px-4 sm:px-8 rounded-3xl bg-white/10 backdrop-blur-md border border-white/20 inline-block max-w-full">
            <span className="text-xl sm:text-3xl lg:text-4xl font-black font-heading text-brand-secondary tracking-tight block">
              Views ≠ Engagement ≠ Conversion ≠ Profit
            </span>
          </div>

          <p className="text-sm sm:text-base text-gray-300 leading-relaxed font-sans max-w-2xl mx-auto">
            These represent completely distinct stages of buyer intent. A meme that earns 5 million views on TikTok may produce 0 paying customers if there is no natural friction between the joke and your value proposition.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 text-center">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
              <span className="text-xs uppercase font-bold text-gray-400 block">Stage 1</span>
              <span className="text-lg font-bold text-white font-heading">Views</span>
              <p className="text-[11px] text-gray-400 mt-1">Cheap vanity impressions</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
              <span className="text-xs uppercase font-bold text-gray-400 block">Stage 2</span>
              <span className="text-lg font-bold text-purple-300 font-heading">Engagement</span>
              <p className="text-[11px] text-gray-400 mt-1">Likes, comments & DMs</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
              <span className="text-xs uppercase font-bold text-gray-400 block">Stage 3</span>
              <span className="text-lg font-bold text-amber-300 font-heading">Conversion</span>
              <p className="text-[11px] text-gray-400 mt-1">Clicks, signups & checkouts</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
              <span className="text-xs uppercase font-bold text-gray-400 block">Stage 4</span>
              <span className="text-lg font-bold text-emerald-400 font-heading">Profit</span>
              <p className="text-[11px] text-gray-400 mt-1">Net LTV after ad spend</p>
            </div>
          </div>
        </div>
      </section>

      {/* WHEN IT FITS vs WHEN TO USE CAUTION */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* WHEN MEME MARKETING CAN FIT */}
        <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-card border border-emerald-200/80 space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-gray-100">
            <div className="p-2.5 rounded-2xl bg-emerald-100 text-brand-success">
              <CheckCircle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-2xl font-bold font-heading text-brand-primary">
                When Meme Marketing Fits
              </h3>
              <p className="text-xs text-gray-500">Green flags for high commercial payoff</p>
            </div>
          </div>

          <div className="space-y-4">
            {fitPoints.map((pt, idx) => (
              <div key={idx} className="flex items-start gap-3 p-3.5 rounded-2xl bg-emerald-50/40 border border-emerald-100/60">
                <CheckCircle2 className="w-5 h-5 text-brand-success flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-gray-900">{pt.title}</h4>
                  <p className="text-xs text-gray-600 mt-0.5 font-sans leading-relaxed">{pt.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* WHEN TO USE CAUTION */}
        <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-card border border-amber-200/80 space-y-6">
          <div className="flex items-center gap-3 pb-4 border-b border-gray-100">
            <div className="p-2.5 rounded-2xl bg-amber-100 text-brand-warning">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-2xl font-bold font-heading text-brand-primary">
                When to Use Caution
              </h3>
              <p className="text-xs text-gray-500">Risk scenarios requiring strict audit</p>
            </div>
          </div>

          <div className="space-y-4">
            {cautionPoints.map((pt, idx) => (
              <div key={idx} className="flex items-start gap-3 p-3 rounded-2xl bg-amber-50/40 border border-amber-100/60">
                <AlertTriangle className="w-4 h-4 text-brand-warning flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-gray-900">{pt.title}</h4>
                  <p className="text-xs text-gray-600 mt-0.5 font-sans leading-relaxed">{pt.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </section>

      {/* Closing Punchline Required by Prompt */}
      <div className="p-8 sm:p-10 rounded-3xl bg-purple-50 border-2 border-brand-accent/20 text-center space-y-4 max-w-3xl mx-auto">
        <p className="text-2xl sm:text-3xl font-black font-heading text-brand-primary">
          "A viral meme isn't automatically a successful advertisement."
        </p>
        <p className="text-sm text-gray-600 font-sans max-w-xl mx-auto">
          Ensure your meme connects the punchline directly to the consumer solution before allocating ad budget.
        </p>
        <div className="pt-2">
          <button
            onClick={() => {
              setActivePage('campaign-builder');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="py-3.5 px-7 rounded-2xl bg-brand-primary hover:bg-brand-accent text-white font-bold text-xs uppercase tracking-wider transition-all inline-flex items-center gap-2"
          >
            <span>Audit Your Next Campaign</span>
            <ArrowRight className="w-4 h-4 text-brand-secondary" />
          </button>
        </div>
      </div>

    </div>
  );
}
