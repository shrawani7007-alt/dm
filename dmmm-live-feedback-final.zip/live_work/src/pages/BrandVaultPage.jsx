import React, { useState } from 'react';
import { CASE_STUDIES, MARKETER_RULES } from '../data/caseStudies';
import BrandPopularityLeaderboard from '../components/BrandPopularityLeaderboard';
import RefinedPosterShowcase from '../components/RefinedPosterShowcase';
import { 
  Search, Filter, Sparkles, BookOpen, CheckCircle2, ArrowRight, 
  Lightbulb, ExternalLink, Tag, ShieldCheck 
} from 'lucide-react';

export default function BrandVaultPage({ setActivePage }) {
  const [selectedIndustry, setSelectedIndustry] = useState('All');
  const [selectedStyle, setSelectedStyle] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCaseModal, setActiveCaseModal] = useState(null);

  const industries = ['All', 'Food', 'Tech', 'Entertainment', 'FMCG', 'Travel', 'Education'];
  const styles = ['All', 'Relatable', 'Chaotic', 'Cultural', 'Personalized', 'Topical', 'Self-aware'];

  const filteredCaseStudies = CASE_STUDIES.filter((cs) => {
    const matchesIndustry = selectedIndustry === 'All' || cs.industry === selectedIndustry;
    const matchesStyle = selectedStyle === 'All' || cs.marketingStyle.toLowerCase() === selectedStyle.toLowerCase();
    const matchesSearch = searchQuery.trim() === '' || 
      cs.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cs.keyLesson.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cs.approach.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesIndustry && matchesStyle && matchesSearch;
  });

  return (
    <div className="space-y-20 pb-20 pt-8 sm:pt-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold uppercase tracking-widest text-brand-accent bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
          Deconstructed Playbooks
        </span>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading text-brand-primary tracking-tight">
          Brand Vault
        </h1>
        <p className="text-base sm:text-lg text-gray-600 font-sans leading-relaxed">
          Six iconic brands that turned cultural vernacular into commercial moats. Pure strategic breakdown without fabricated vanity metrics.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-3xl p-6 shadow-card border border-gray-200 space-y-5">
        
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search by brand name, core lesson, or strategy..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-2xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-accent transition-all bg-gray-50/50"
          />
        </div>

        {/* Filter Pills */}
        <div className="space-y-3">
          {/* Industry Filter */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider mr-2 font-mono">
              Industry:
            </span>
            {industries.map((ind) => (
              <button
                key={ind}
                onClick={() => setSelectedIndustry(ind)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  selectedIndustry === ind
                    ? 'bg-brand-primary text-white shadow-sm'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {ind}
              </button>
            ))}
          </div>

          {/* Marketing Style Filter */}
          <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-gray-100">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider mr-2 font-mono">
              Marketing Style:
            </span>
            {styles.map((st) => (
              <button
                key={st}
                onClick={() => setSelectedStyle(st)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  selectedStyle === st
                    ? 'bg-brand-accent text-white shadow-sm'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Case Studies Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
        {filteredCaseStudies.map((study) => (
          <div
            key={study.id}
            className="bg-white rounded-3xl p-6 sm:p-8 shadow-card border border-gray-200 hover:shadow-card-hover hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
          >
            <div>
              {/* Header Badges */}
              <div className="flex items-start justify-between gap-2 mb-4">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-purple-50 text-brand-accent border border-purple-100">
                    {study.industry}
                  </span>
                  <h3 className="text-2xl font-black font-heading text-brand-primary mt-1">
                    {study.brand}
                  </h3>
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-gray-100 text-gray-700">
                  {study.marketingStyle}
                </span>
              </div>

              {/* Tagline / Subtitle */}
              <p className="text-xs font-semibold text-gray-500 italic mb-4 font-sans">
                "{study.tagline}"
              </p>

              {/* Spec Rows */}
              <div className="space-y-2 text-xs py-3 border-y border-gray-100 mb-4">
                <div className="flex justify-between">
                  <span className="text-gray-400">Target Audience:</span>
                  <span className="font-semibold text-gray-800 text-right">{study.targetAudience}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Marketing Objective:</span>
                  <span className="font-semibold text-brand-accent text-right">{study.marketingObjective}</span>
                </div>
              </div>

              {/* Approach summary */}
              <div className="space-y-1.5 mb-5">
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                  Strategic Approach
                </span>
                <p className="text-xs text-gray-700 leading-relaxed font-sans">
                  {study.approach}
                </p>
              </div>
            </div>

            {/* Key Lesson Box (Crucial Highlight) */}
            <div>
              <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900 uppercase tracking-wider">
                  <Lightbulb className="w-3.5 h-3.5 text-brand-warning flex-shrink-0" />
                  Key Marketer Lesson
                </div>
                <p className="text-xs font-bold text-gray-900 font-sans leading-snug">
                  "{study.keyLesson}"
                </p>
              </div>

              {/* Examples snippet */}
              <div className="mt-4 pt-3 flex items-center justify-between text-xs">
                <span className="text-[11px] text-gray-400">
                  Verified Brand Playbook
                </span>
                <button
                  onClick={() => {
                    // Navigate to campaign builder to emulate this style
                    setActivePage('campaign-builder');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="font-bold text-brand-accent hover:underline flex items-center gap-1"
                >
                  Emulate Approach →
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredCaseStudies.length === 0 && (
        <div className="p-12 text-center bg-white rounded-3xl border border-gray-200 space-y-3">
          <BookOpen className="w-10 h-10 mx-auto text-gray-300" />
          <h3 className="text-lg font-bold text-gray-700">No Case Studies Match Your Filters</h3>
          <p className="text-xs text-gray-500">Try clearing the industry or style filters to see all 6 case studies.</p>
          <button
            onClick={() => {
              setSelectedIndustry('All');
              setSelectedStyle('All');
              setSearchQuery('');
            }}
            className="px-4 py-2 rounded-xl bg-brand-primary text-white text-xs font-bold"
          >
            Reset Filters
          </button>
        </div>
      )}

      {/* LIVE BRAND POPULARITY LEADERBOARD & SOCIAL RESONANCE */}
      <section>
        <BrandPopularityLeaderboard />
      </section>

      {/* REFINED COMMERCIAL POSTER SHOWCASE & LAYOUT BLUEPRINT */}
      <section>
        <RefinedPosterShowcase />
      </section>

      {/* SECTION: WHAT CAN MARKETERS LEARN? (6 Rules) */}
      <section className="bg-white rounded-4xl p-8 sm:p-12 shadow-card border border-gray-200 space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-accent bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
            Synthesized Principles
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-heading text-brand-primary">
            What Can Marketers Learn?
          </h2>
          <p className="text-xs sm:text-sm text-gray-600 font-sans">
            Six non-negotiable laws extracted across thousands of brand meme campaigns.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {MARKETER_RULES.map((ruleItem, idx) => (
            <div
              key={idx}
              className="p-6 rounded-3xl bg-gray-50/70 border border-gray-200/80 hover:bg-purple-50/30 hover:border-purple-200 transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-brand-accent bg-white px-2 py-0.5 rounded shadow-xs border border-gray-200">
                    {ruleItem.tag}
                  </span>
                  <span className="text-xs font-mono font-bold text-gray-300">0{idx + 1}</span>
                </div>
                <h3 className="text-base font-bold font-heading text-brand-primary mb-2">
                  {ruleItem.rule}
                </h3>
                <p className="text-xs text-gray-600 font-sans leading-relaxed">
                  {ruleItem.summary}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-gray-200/60 flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700">
                <CheckCircle2 className="w-3.5 h-3.5 text-brand-success" />
                Verified Tactical Rule
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
