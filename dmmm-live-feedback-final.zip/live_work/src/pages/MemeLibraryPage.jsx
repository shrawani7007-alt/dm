import React, { useState } from 'react';
import { MEME_FORMATS } from '../data/memeFormats';
import { useApp } from '../context/AppContext';
import MemeAudioDanceSoundboard from '../components/MemeAudioDanceSoundboard';
import { 
  Search, Sparkles, ArrowRight, CheckCircle2, Zap, Layers, 
  Tag, HelpCircle, Eye, Flame, Music, Volume2 
} from 'lucide-react';

export default function MemeLibraryPage({ setActivePage }) {
  const { selectFormatAndNavigateToBuilder } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedObjective, setSelectedObjective] = useState('All');
  const [selectedTone, setSelectedTone] = useState('All');
  const [selectedFormatFilter, setSelectedFormatFilter] = useState('All');

  const objectives = ['All', 'Brand Awareness', 'Engagement', 'Product Launch', 'Promotion', 'App Download', 'Community Building'];
  const tones = ['All', 'Relatable', 'Funny', 'Bold', 'Chaotic', 'Smart', 'Wholesome'];
  const formatNames = [
    'All', 'Phir Hera Pheri', 'Chin Tapak Dum Dum', 'Ravi Kishan', 'Piche Dekho', 
    'Wah Shampy', 'Skibidi Toilet', '6-7', 'Drake', 'Kinda Chic', 'Jimothy', 
    'POV', 'Distracted Boyfriend', 'This Is Fine', 'Surprised Pikachu'
  ];

  const filteredFormats = MEME_FORMATS.filter((fmt) => {
    const matchesObjective = selectedObjective === 'All' || 
      (fmt.suggestedObjectives && fmt.suggestedObjectives.includes(selectedObjective)) ||
      fmt.recommendedObjective.toLowerCase().includes(selectedObjective.toLowerCase());
    
    const matchesTone = selectedTone === 'All' || 
      (fmt.suggestedTones && fmt.suggestedTones.includes(selectedTone)) ||
      fmt.tone.toLowerCase().includes(selectedTone.toLowerCase());

    const matchesFormat = selectedFormatFilter === 'All' || fmt.name.toLowerCase().includes(selectedFormatFilter.toLowerCase());

    const matchesSearch = searchQuery.trim() === '' ||
      fmt.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fmt.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fmt.tone.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesObjective && matchesTone && matchesFormat && matchesSearch;
  });

  const handleUseFormat = (formatName) => {
    let builderKey = 'POV';
    if (formatName.includes('Hera') || formatName.includes('Pheri')) builderKey = 'Phir Hera Pheri';
    else if (formatName.includes('Chin Tapak') || formatName.includes('Dum Dum')) builderKey = 'Chin Tapak Dum Dum';
    else if (formatName.includes('Ravi') || formatName.includes('Kishan')) builderKey = 'Ravi Kishan Dance';
    else if (formatName.includes('Piche')) builderKey = 'Piche Dekho Piche';
    else if (formatName.includes('Shampy')) builderKey = 'Wah Shampy Wah';
    else if (formatName.includes('Skibidi')) builderKey = 'Skibidi Toilet';
    else if (formatName.includes('6-7')) builderKey = '6-7';
    else if (formatName.includes('Drake')) builderKey = 'Drake';
    else if (formatName.includes('Chic') || formatName.includes('Demure')) builderKey = 'Kinda Chic (Demure)';
    else if (formatName.includes('Jimothy') || formatName.includes('Raccoon')) builderKey = 'Jimothy the Raccoon';
    else if (formatName.includes('POV')) builderKey = 'POV';
    else if (formatName.includes('Distracted')) builderKey = 'Distracted Boyfriend';
    else if (formatName.includes('Expectation')) builderKey = 'Expectation vs Reality';
    else if (formatName.includes('Before')) builderKey = 'Before vs After';
    else if (formatName.includes('Starter')) builderKey = 'Starter Pack';
    else if (formatName.includes('Fine')) builderKey = 'This Is Fine';
    else if (formatName.includes('Pikachu')) builderKey = 'Surprised Pikachu';

    selectFormatAndNavigateToBuilder(builderKey);
    setActivePage('campaign-builder');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-16 pb-20 pt-8 sm:pt-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold uppercase tracking-widest text-brand-accent bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
          Curated Archetype Registry
        </span>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading text-brand-primary tracking-tight">
          Meme Library
        </h1>
        <p className="text-base sm:text-lg text-gray-600 font-sans leading-relaxed">
          Search proven cultural formats, examine structural anatomy, listen to trending audio syncs, and launch directly into campaign generation with one click.
        </p>
      </div>

      {/* LIVE MEME AUDIO & DANCE FX ENGINE */}
      <MemeAudioDanceSoundboard />

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-card border border-gray-200 space-y-5">
        
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search meme format by name, psychological hook, or tone..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-2xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-accent transition-all bg-gray-50/50"
          />
        </div>

        {/* Filter Rows */}
        <div className="space-y-3 pt-2">
          {/* Objective Filter */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider mr-2 font-mono">
              Objective:
            </span>
            {objectives.map((obj) => (
              <button
                key={obj}
                onClick={() => setSelectedObjective(obj)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  selectedObjective === obj
                    ? 'bg-brand-primary text-white shadow-sm'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {obj}
              </button>
            ))}
          </div>

          {/* Tone Filter */}
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-gray-100">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider mr-2 font-mono">
              Tone:
            </span>
            {tones.map((t) => (
              <button
                key={t}
                onClick={() => setSelectedTone(t)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  selectedTone === t
                    ? 'bg-brand-accent text-white shadow-sm'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          {/* Format Filter */}
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-gray-100">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider mr-2 font-mono">
              Format:
            </span>
            {formatNames.map((fn) => (
              <button
                key={fn}
                onClick={() => setSelectedFormatFilter(fn)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  selectedFormatFilter === fn
                    ? 'bg-amber-400 text-brand-primary font-bold shadow-sm'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {fn}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Formats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredFormats.map((fmt) => (
          <div
            key={fmt.id}
            className="bg-white rounded-3xl shadow-card border border-gray-200 overflow-hidden hover:shadow-card-hover hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between group"
          >
            <div>
              {/* Visual Preview Box */}
              <div className="relative bg-[#111111] p-6 text-white min-h-[160px] flex flex-col justify-between overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(#333_1px,transparent_1px)] [background-size:12px_12px] opacity-50" />
                
                <div className="relative z-10 flex items-center justify-between">
                  <span className="text-2xl">{fmt.iconEmoji}</span>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-brand-secondary text-brand-primary">
                    {fmt.badge}
                  </span>
                </div>

                <div className="relative z-10 mt-3">
                  <h3 className="text-xl font-black font-heading tracking-tight text-white group-hover:text-brand-secondary transition-colors">
                    {fmt.name}
                  </h3>
                  <p className="text-[11px] text-purple-200 font-mono mt-0.5">
                    Structure: {fmt.structure.split('\n')[0]}
                  </p>
                </div>
              </div>

              {/* Details Body */}
              <div className="p-6 space-y-4">
                
                {/* Tone and Objective Badges */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-400 font-medium">Tone:</span>
                    <span className="font-bold text-gray-800 px-2 py-0.5 rounded bg-gray-100">
                      {fmt.tone}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-400 font-medium">Best Objective:</span>
                    <span className="font-bold text-brand-accent text-right">
                      {fmt.recommendedObjective}
                    </span>
                  </div>
                </div>

                {/* Description */}
                <p className="text-xs text-gray-600 leading-relaxed font-sans line-clamp-3">
                  {fmt.description}
                </p>

                {/* Micro preview mock */}
                <div className="p-3 rounded-2xl bg-purple-50/60 border border-purple-100 text-[11px] text-purple-950 font-sans">
                  <span className="font-bold block text-[10px] uppercase text-brand-accent mb-0.5">Headline Angle:</span>
                  "{fmt.exampleMock.headline}"
                </div>

              </div>
            </div>

            {/* Action Button: "Use This Format" (CRITICAL requirement) */}
            <div className="p-6 pt-0">
              <button
                onClick={() => handleUseFormat(fmt.name)}
                className="w-full py-3.5 px-4 rounded-2xl bg-brand-primary hover:bg-brand-accent text-white font-bold text-xs uppercase tracking-wider shadow-sm hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 group-hover:bg-brand-accent"
              >
                <span>Use This Format</span>
                <ArrowRight className="w-3.5 h-3.5 text-brand-secondary" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredFormats.length === 0 && (
        <div className="p-12 text-center bg-white rounded-3xl border border-gray-200 space-y-3">
          <Layers className="w-10 h-10 mx-auto text-gray-300" />
          <h3 className="text-lg font-bold text-gray-700">No Meme Formats Found</h3>
          <p className="text-xs text-gray-500">Try adjusting your search keywords or clearing tone/objective filters.</p>
          <button
            onClick={() => {
              setSelectedObjective('All');
              setSelectedTone('All');
              setSelectedFormatFilter('All');
              setSearchQuery('');
            }}
            className="px-4 py-2 rounded-xl bg-brand-primary text-white text-xs font-bold"
          >
            Reset Filters
          </button>
        </div>
      )}

    </div>
  );
}
