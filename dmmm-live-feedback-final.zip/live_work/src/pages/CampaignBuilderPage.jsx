import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { generateCampaignData } from '../data/campaignTemplates';
import SocialCardPreview from '../components/SocialCardPreview';
import M2ScoreCard from '../components/M2ScoreCard';
import RiskCheckCard from '../components/RiskCheckCard';
import RoiLabCard from '../components/RoiLabCard';
import AbTestLabCard from '../components/AbTestLabCard';
import CampaignReportModal from '../components/CampaignReportModal';
import { 
  Sparkles, ArrowRight, ArrowLeft, Check, CheckCircle2, Bookmark, 
  RotateCcw, Download, Eye, Zap, Sliders, ShieldAlert, BarChart3, 
  Share2, Copy, ExternalLink, Flame, HelpCircle, Layers, Lightbulb
} from 'lucide-react';

export default function CampaignBuilderPage({ setActivePage }) {
  const { 
    wizardDraft, setWizardDraft, currentCampaign, setCurrentCampaign, 
    saveCampaign, isPro, openProPaywall, addToast 
  } = useApp();

  // Wizard Step (1 to 7)
  const [currentStep, setCurrentStep] = useState(wizardDraft?.step || 1);

  // Form State
  const [formData, setFormData] = useState({
    product: wizardDraft?.product || 'Campus Fuel Energy Drink',
    objective: wizardDraft?.objective || 'Engagement',
    audience: wizardDraft?.audience || 'College Students',
    personality: wizardDraft?.personality || 'Funny',
    platform: wizardDraft?.platform || 'Instagram',
    format: wizardDraft?.format || 'POV',
  });

  // Loading animation state for Step 7
  const [isGenerating, setIsGenerating] = useState(false);
  const [loadingMessageIndex, setLoadingMessageIndex] = useState(0);
  const [hasGenerated, setHasGenerated] = useState(false);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [activeOutputTab, setActiveOutputTab] = useState('creative'); // 'creative' | 'm2score' | 'risk' | 'roi' | 'abtest'

  const loadingMessages = [
    "Finding your meme angle...",
    "Matching your audience...",
    "Building your campaign...",
    "Connecting the joke to the product..."
  ];

  // Sync back to wizardDraft in context/localStorage
  useEffect(() => {
    setWizardDraft({
      ...formData,
      step: currentStep
    });
  }, [formData, currentStep, setWizardDraft]);

  // Options configuration
  const objectives = [
    { id: 'Brand Awareness', desc: 'Maximize feed stop-rate & top-of-mind cultural recall' },
    { id: 'Engagement', desc: 'Drive high-volume likes, comments & group chat shares' },
    { id: 'Product Launch', desc: 'Position new offer as shiny irresistible upgrade' },
    { id: 'Promotion', desc: 'Highlight limited deals with self-aware contrast' },
    { id: 'App Download', desc: 'Turn daily chaos/pain into instant installation' },
    { id: 'Event', desc: 'Accelerate ticket hype and group attendance FOMO' },
    { id: 'Community Building', desc: 'Strengthen insider subcultural jokes and badges' },
  ];

  const audiences = [
    { id: 'Gen Z', hint: 'Ultra-fast visual literacy, irony-steeped, allergic to hard sells' },
    { id: 'College Students', hint: '8 AM lectures, exam anxiety, late nights, tight budgets' },
    { id: 'Young Professionals', hint: 'Corporate burnout, Slack overload, weekend escapism' },
    { id: 'Gamers', hint: 'Discord banter, competitive tilt, late night grind' },
    { id: 'Food Lovers', hint: 'Diet procrastination, midnight cravings, foodie obsession' },
    { id: 'Fashion Audience', hint: 'Aesthetic curation, street capsule drops, insider codes' },
    { id: 'General Audience', hint: 'Broad universal situational human truths' },
  ];

  const personalities = [
    { id: 'Funny', badge: 'Witty & playful' },
    { id: 'Cool', badge: 'Effortless & modern' },
    { id: 'Bold', badge: 'Direct & provocative' },
    { id: 'Smart', badge: 'Clever & insightful' },
    { id: 'Emotional', badge: 'Empathetic & heartfelt' },
    { id: 'Chaotic', badge: 'Unhinged & meme-first' },
    { id: 'Wholesome', badge: 'Warm & community-focused' },
    { id: 'Professional', badge: 'Sharply articulate' },
  ];

  const platforms = [
    { id: 'Instagram', tag: 'Reels & Carousels' },
    { id: 'TikTok', tag: 'Fast audio loops' },
    { id: 'YouTube Shorts', tag: 'Visual hooks' },
    { id: 'X', tag: 'Punchy text memes' },
    { id: 'WhatsApp', tag: 'Peer viral forwarding' },
    { id: 'LinkedIn', tag: 'Relatable work satire' },
  ];

  const formats = [
    { id: 'Kinda Chic (Demure)', desc: 'Very demure, very mindful, kinda chic understated luxury satire', isRecommended: formData.personality === 'Wholesome' || formData.personality === 'Smart' },
    { id: 'Jimothy the Raccoon', desc: 'Spinning dance groove (Pedro) celebrating pure victory & euphoria', isRecommended: formData.personality === 'Chaotic' || formData.objective === 'Engagement' },
    { id: 'Ravi Kishan Dance', desc: 'Zindagi jhandwa, fir bhi ghamandwa! High voltage Bollywood swagger', isRecommended: formData.personality === 'Bold' || formData.audience === 'College Students' },
    { id: 'POV', desc: 'Places the viewer right inside the relatable struggle', isRecommended: formData.audience === 'College Students' || formData.audience === 'Gen Z' },
    { id: 'Drake', desc: 'The classic disapproval vs approval comparison', isRecommended: formData.objective === 'Promotion' || formData.personality === 'Smart' },
    { id: 'Distracted Boyfriend', desc: 'Temptation to abandon the old way for your product', isRecommended: formData.objective === 'Product Launch' },
    { id: 'Expectation vs Reality', desc: 'Aesthetic dreams vs messy relatable hustle', isRecommended: formData.personality === 'Wholesome' || formData.personality === 'Funny' },
    { id: 'Before vs After', desc: 'Clear visual problem to solved after-state', isRecommended: formData.objective === 'Promotion' },
    { id: 'Starter Pack', desc: '4-item identity essentials kit with your product included', isRecommended: formData.audience === 'Fashion Audience' || formData.objective === 'Community Building' },
    { id: 'This Is Fine', desc: 'Everything burning while you calmly sip with your solution', isRecommended: formData.audience === 'Young Professionals' || formData.personality === 'Chaotic' },
    { id: 'Surprised Pikachu', desc: 'Mock shock at predictable consequences of bad habits', isRecommended: formData.personality === 'Funny' },
  ];

  // Generator trigger
  const handleGenerate = () => {
    setIsGenerating(true);
    setLoadingMessageIndex(0);

    // Rotate through the 4 prompt-specified messages
    const interval = setInterval(() => {
      setLoadingMessageIndex((prev) => (prev + 1) % loadingMessages.length);
    }, 600);

    setTimeout(() => {
      clearInterval(interval);
      const generated = generateCampaignData(formData);
      setCurrentCampaign(generated);
      setIsGenerating(false);
      setHasGenerated(true);
      setCurrentStep(7);
      addToast('✨ Campaign generated successfully with marketing evaluation!', 'success');
    }, 2500);
  };

  const handleSaveCampaign = () => {
    saveCampaign(currentCampaign);
  };

  const handleCopyText = (text, label) => {
    navigator.clipboard?.writeText(text);
    addToast(`${label} copied to clipboard!`, 'info');
  };

  const nextStep = () => {
    if (currentStep === 6) {
      handleGenerate();
    } else {
      setCurrentStep(prev => Math.min(prev + 1, 7));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const stepLabels = [
    '01 Product',
    '02 Objective',
    '03 Audience',
    '04 Personality',
    '05 Platform',
    '06 Format',
    '07 Output'
  ];

  return (
    <div className="space-y-12 pb-24 pt-6 sm:pt-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-gray-200">
        <div>
          <span className="text-xs font-bold uppercase tracking-widest text-brand-accent bg-purple-50 px-3 py-1 rounded-full border border-purple-200 inline-block mb-2">
            Wizard Architecture
          </span>
          <h1 className="text-3xl sm:text-4xl font-black font-heading text-brand-primary">
            Campaign Builder
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 font-sans mt-0.5">
            Step-by-step strategy configuration that bridges the meme joke directly to your product.
          </p>
        </div>

        {hasGenerated && (
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <button
              onClick={() => {
                setCurrentStep(1);
                setHasGenerated(false);
              }}
              className="px-3.5 py-2 rounded-xl border border-gray-200 hover:bg-gray-100 text-xs font-bold text-gray-700 flex items-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Configure New Campaign</span>
            </button>
          </div>
        )}
      </div>

      {/* 7-Step Progress Indicator */}
      <div className="bg-white rounded-3xl p-4 sm:p-6 shadow-card border border-gray-200">
        <div className="grid grid-cols-7 gap-2 sm:gap-4 items-center">
          {stepLabels.map((lbl, idx) => {
            const stepNum = idx + 1;
            const isCompleted = stepNum < currentStep || (hasGenerated && stepNum === 7);
            const isCurrent = stepNum === currentStep;

            return (
              <button
                key={idx}
                disabled={stepNum > currentStep && !hasGenerated}
                onClick={() => {
                  if (stepNum <= currentStep || hasGenerated) {
                    setCurrentStep(stepNum);
                  }
                }}
                className={`flex flex-col items-center text-center transition-all ${
                  isCurrent
                    ? 'scale-105'
                    : isCompleted
                    ? 'opacity-90 hover:opacity-100 cursor-pointer'
                    : 'opacity-40 cursor-not-allowed'
                }`}
              >
                <div
                  className={`w-8 h-8 sm:w-10 sm:h-10 rounded-2xl flex items-center justify-center font-mono font-bold text-xs sm:text-sm transition-all mb-1 ${
                    isCurrent
                      ? 'bg-brand-accent text-white shadow-glow-accent'
                      : isCompleted
                      ? 'bg-brand-primary text-brand-secondary'
                      : 'bg-gray-100 text-gray-400'
                  }`}
                >
                  {isCompleted && stepNum !== currentStep ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    `0${stepNum}`
                  )}
                </div>
                <span className={`text-[10px] sm:text-xs font-bold truncate max-w-full hidden md:block ${
                  isCurrent ? 'text-brand-accent' : 'text-gray-500'
                }`}>
                  {lbl.split(' ')[1]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* GENERATING ANIMATED STATE (For Step 07) */}
      {isGenerating && (
        <div className="bg-white rounded-4xl p-12 sm:p-20 shadow-elevated border border-gray-200 text-center max-w-2xl mx-auto space-y-6 animate-pulse-subtle">
          <div className="w-20 h-20 rounded-3xl bg-brand-primary text-brand-secondary flex items-center justify-center mx-auto shadow-glow-yellow animate-float">
            <Sparkles className="w-10 h-10" />
          </div>
          
          <div className="space-y-2">
            <span className="text-xs font-mono uppercase font-bold tracking-widest text-brand-accent">
              MEME MARKETING SYNTHESIS ENGINE
            </span>
            <h3 className="text-2xl sm:text-3xl font-black font-heading text-brand-primary">
              {loadingMessages[loadingMessageIndex]}
            </h3>
          </div>

          <div className="w-64 max-w-full mx-auto bg-gray-100 h-2.5 rounded-full overflow-hidden">
            <div className="bg-gradient-to-r from-brand-accent via-brand-secondary to-brand-accent h-full w-full animate-pulse" />
          </div>

          <p className="text-xs text-gray-400 font-sans">
            Validating humor attribution, calculating M² score & auditing context risk...
          </p>
        </div>
      )}

      {/* WIZARD STEPS (When not generating) */}
      {!isGenerating && currentStep < 7 && (
        <div className="bg-white rounded-4xl p-6 sm:p-10 shadow-card border border-gray-200 max-w-3xl mx-auto space-y-8 animate-fade-in">
          
          {/* STEP 01: PRODUCT / BRAND */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-brand-accent uppercase tracking-wider">
                  Step 01 / 07
                </span>
                <h2 className="text-2xl sm:text-3xl font-black font-heading text-brand-primary mt-1">
                  What product or brand are we advertising?
                </h2>
                <p className="text-xs sm:text-sm text-gray-500 font-sans mt-1">
                  Enter your core offering, product name, or service category.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-gray-700 tracking-wider mb-2">
                  Product / Brand Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Energy Drink, Fintech Savings App, Oversized Hoodies"
                  value={formData.product}
                  onChange={(e) => setFormData({ ...formData, product: e.target.value })}
                  className="w-full px-5 py-4 rounded-2xl border-2 border-gray-200 text-base font-semibold focus:outline-none focus:border-brand-accent transition-all bg-gray-50/50"
                  autoFocus
                />
              </div>

              {/* Quick suggestions */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-gray-400">Quick Demo Presets:</span>
                <div className="flex flex-wrap gap-2">
                  {['Campus Fuel Energy Drink', 'SprintPay Instant UPI', 'ThreadCraft Streetwear', 'FocusMode Productivity App'].map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setFormData({ ...formData, product: p })}
                      className="px-3 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-brand-accent text-xs font-semibold transition-colors"
                    >
                      + {p}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 02: MARKETING OBJECTIVE */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-brand-accent uppercase tracking-wider">
                  Step 02 / 07
                </span>
                <h2 className="text-2xl sm:text-3xl font-black font-heading text-brand-primary mt-1">
                  What is your primary marketing objective?
                </h2>
                <p className="text-xs sm:text-sm text-gray-500 font-sans mt-1">
                  Select the key result this meme campaign must deliver.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {objectives.map((obj) => (
                  <button
                    key={obj.id}
                    onClick={() => setFormData({ ...formData, objective: obj.id })}
                    className={`p-4 rounded-2xl border-2 text-left transition-all ${
                      formData.objective === obj.id
                        ? 'border-brand-accent bg-purple-50/70 shadow-sm'
                        : 'border-gray-200 hover:border-gray-300 bg-gray-50/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-gray-900">{obj.id}</span>
                      {formData.objective === obj.id && (
                        <Check className="w-4 h-4 text-brand-accent font-bold" />
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{obj.desc}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 03: TARGET AUDIENCE */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-brand-accent uppercase tracking-wider">
                  Step 03 / 07
                </span>
                <h2 className="text-2xl sm:text-3xl font-black font-heading text-brand-primary mt-1">
                  Who is your target audience?
                </h2>
                <p className="text-xs sm:text-sm text-gray-500 font-sans mt-1">
                  The joke must reflect their specific cultural vernacular and daily frictions.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {audiences.map((aud) => (
                  <button
                    key={aud.id}
                    onClick={() => setFormData({ ...formData, audience: aud.id })}
                    className={`p-4 rounded-2xl border-2 text-left transition-all ${
                      formData.audience === aud.id
                        ? 'border-brand-accent bg-purple-50/70 shadow-sm'
                        : 'border-gray-200 hover:border-gray-300 bg-gray-50/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-gray-900">{aud.id}</span>
                      {formData.audience === aud.id && (
                        <Check className="w-4 h-4 text-brand-accent font-bold" />
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{aud.hint}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 04: BRAND PERSONALITY */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-brand-accent uppercase tracking-wider">
                  Step 04 / 07
                </span>
                <h2 className="text-2xl sm:text-3xl font-black font-heading text-brand-primary mt-1">
                  What brand personality tone fits best?
                </h2>
                <p className="text-xs sm:text-sm text-gray-500 font-sans mt-1">
                  Choose how bold, sarcastic, or wholesome your brand voice should sound.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {personalities.map((per) => (
                  <button
                    key={per.id}
                    onClick={() => setFormData({ ...formData, personality: per.id })}
                    className={`p-4 rounded-2xl border-2 text-center transition-all ${
                      formData.personality === per.id
                        ? 'border-brand-accent bg-purple-50/70 shadow-sm'
                        : 'border-gray-200 hover:border-gray-300 bg-gray-50/40'
                    }`}
                  >
                    <span className="font-black text-sm text-gray-900 block font-heading">{per.id}</span>
                    <span className="text-[10px] text-gray-500 block mt-1">{per.badge}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 05: PLATFORM */}
          {currentStep === 5 && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-brand-accent uppercase tracking-wider">
                  Step 05 / 07
                </span>
                <h2 className="text-2xl sm:text-3xl font-black font-heading text-brand-primary mt-1">
                  Where will this campaign be deployed?
                </h2>
                <p className="text-xs sm:text-sm text-gray-500 font-sans mt-1">
                  Each platform dictates distinct visual formatting and caption length rules.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {platforms.map((plat) => (
                  <button
                    key={plat.id}
                    onClick={() => setFormData({ ...formData, platform: plat.id })}
                    className={`p-5 rounded-2xl border-2 text-left transition-all ${
                      formData.platform === plat.id
                        ? 'border-brand-accent bg-purple-50/70 shadow-sm'
                        : 'border-gray-200 hover:border-gray-300 bg-gray-50/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-base text-gray-900 font-heading">{plat.id}</span>
                      {formData.platform === plat.id && (
                        <Check className="w-4 h-4 text-brand-accent font-bold" />
                      )}
                    </div>
                    <span className="text-[11px] text-gray-500 mt-1 block">{plat.tag}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 06: MEME FORMAT */}
          {currentStep === 6 && (
            <div className="space-y-6">
              <div>
                <span className="text-xs font-mono font-bold text-brand-accent uppercase tracking-wider">
                  Step 06 / 07
                </span>
                <h2 className="text-2xl sm:text-3xl font-black font-heading text-brand-primary mt-1">
                  Select your meme archetype
                </h2>
                <p className="text-xs sm:text-sm text-gray-500 font-sans mt-1">
                  Recommended archetypes are highlighted based on your target audience & objective.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {formats.map((fmt) => (
                  <button
                    key={fmt.id}
                    onClick={() => setFormData({ ...formData, format: fmt.id })}
                    className={`p-4 rounded-2xl border-2 text-left transition-all relative ${
                      formData.format === fmt.id
                        ? 'border-brand-accent bg-purple-50/70 shadow-sm'
                        : 'border-gray-200 hover:border-gray-300 bg-gray-50/40'
                    }`}
                  >
                    {fmt.isRecommended && (
                      <span className="absolute top-3 right-3 text-[10px] font-bold px-2 py-0.5 rounded-full bg-brand-secondary text-brand-primary uppercase">
                        Recommended
                      </span>
                    )}
                    <h4 className="font-bold text-sm text-gray-900 font-heading">{fmt.id}</h4>
                    <p className="text-xs text-gray-600 mt-1 font-sans">{fmt.desc}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Wizard Navigation Action Buttons */}
          <div className="pt-6 border-t border-gray-100 flex items-center justify-between">
            {currentStep > 1 ? (
              <button
                type="button"
                onClick={prevStep}
                className="py-3 px-5 rounded-xl border border-gray-200 hover:bg-gray-100 text-gray-700 font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Back
              </button>
            ) : <div />}

            <button
              type="button"
              onClick={nextStep}
              className="py-4 px-8 rounded-2xl bg-brand-primary hover:bg-brand-accent text-white font-bold text-xs uppercase tracking-wider shadow-sm hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2"
            >
              <span>{currentStep === 6 ? 'Generate Campaign' : 'Continue'}</span>
              <ArrowRight className="w-4 h-4 text-brand-secondary" />
            </button>
          </div>

        </div>
      )}

      {/* STEP 07: CAMPAIGN OUTPUT & EVALUATION DASHBOARD */}
      {!isGenerating && currentStep === 7 && (
        <div className="space-y-10 animate-fade-in">
          
          {/* Top Campaign Control Header */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-card border border-gray-200 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-purple-100 text-brand-accent">
                  {currentCampaign?.format || 'POV'} Format
                </span>
                <span className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-gray-100 text-gray-700">
                  {currentCampaign?.platform || 'Instagram'}
                </span>
                <span className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-emerald-100 text-emerald-800">
                  Target: {currentCampaign?.audience || 'College Students'}
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black font-heading text-brand-primary">
                {currentCampaign?.product || 'Campaign Asset'}
              </h2>
              <p className="text-xs text-gray-500 font-sans mt-0.5">
                Objective: {currentCampaign?.objective || 'Engagement'} • Tone: {currentCampaign?.personality || 'Funny'}
              </p>
            </div>

            {/* Action Bar */}
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={handleSaveCampaign}
                className="py-3 px-5 rounded-2xl border border-gray-200 hover:bg-gray-100 text-gray-800 font-bold text-xs uppercase tracking-wider transition-colors flex items-center gap-2 shadow-xs"
              >
                <Bookmark className="w-4 h-4 text-brand-accent" />
                Save Campaign
              </button>

              <button
                onClick={() => setReportModalOpen(true)}
                className="py-3 px-5 rounded-2xl bg-brand-primary hover:bg-black text-white font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2 shadow-sm"
              >
                <Download className="w-4 h-4 text-brand-secondary" />
                Download Report
              </button>
            </div>
          </div>

          {/* Sub-Tab Navigation for Deep Strategy & Evaluation */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-gray-200 text-xs font-bold">
            {[
              { id: 'creative', label: '1. Creative & Copy Assets', icon: Eye },
              { id: 'm2score', label: '2. M² Marketing Score', icon: BarChart3, isPro: true },
              { id: 'risk', label: '3. Meme Risk Check', icon: ShieldAlert, isPro: true },
              { id: 'roi', label: '4. ROI Lab', icon: Sliders, isPro: true },
              { id: 'abtest', label: '5. A/B Testing Lab', icon: Zap, isPro: true },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeOutputTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    if (tab.isPro && !isPro) {
                      openProPaywall();
                    } else {
                      setActiveOutputTab(tab.id);
                    }
                  }}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-brand-accent text-white shadow-glow-accent'
                      : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                  {tab.isPro && !isPro && (
                    <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-amber-400 text-brand-primary">
                      PRO
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* TAB 1: CREATIVE & COPY ASSETS */}
          {activeOutputTab === 'creative' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Left Column: Social Card Ad Mockup (5 cols) */}
              <div className="lg:col-span-5 space-y-4">
                <div className="flex items-center justify-between text-xs font-bold text-gray-500 uppercase tracking-wider">
                  <span>Sponsored Feed Placement</span>
                  <span className="text-brand-accent">Interactive Live Mock</span>
                </div>
                <SocialCardPreview campaign={currentCampaign} />
              </div>

              {/* Right Column: Copywriting & Deployment Blueprint (7 cols) */}
              <div className="lg:col-span-7 space-y-6">
                
                {/* Concept Box */}
                <div className="bg-white rounded-3xl p-6 shadow-card border border-gray-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-brand-accent font-heading">
                      Meme Concept & Visual Hook
                    </span>
                    <button
                      onClick={() => handleCopyText(currentCampaign?.concept, 'Concept')}
                      className="text-xs text-gray-400 hover:text-black flex items-center gap-1"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      Copy
                    </button>
                  </div>
                  <p className="text-lg font-black font-heading text-brand-primary leading-snug">
                    "{currentCampaign?.concept}"
                  </p>
                </div>

                {/* Headline & CTA */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-white rounded-3xl p-6 shadow-card border border-gray-200 space-y-1.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400">
                      Ad Headline
                    </span>
                    <p className="text-sm font-bold text-gray-900 font-heading">
                      {currentCampaign?.headline}
                    </p>
                  </div>

                  <div className="bg-white rounded-3xl p-6 shadow-card border border-gray-200 space-y-1.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400">
                      Call to Action (CTA)
                    </span>
                    <p className="text-sm font-bold text-brand-accent font-heading">
                      {currentCampaign?.cta}
                    </p>
                  </div>
                </div>

                {/* Caption & Hashtags */}
                <div className="bg-white rounded-3xl p-6 shadow-card border border-gray-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-gray-400">
                      Primary Post Caption
                    </span>
                    <button
                      onClick={() => handleCopyText(currentCampaign?.caption, 'Caption')}
                      className="text-xs text-gray-400 hover:text-black flex items-center gap-1"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      Copy
                    </button>
                  </div>
                  <p className="text-xs text-gray-800 leading-relaxed font-sans bg-gray-50 p-3.5 rounded-2xl border border-gray-100">
                    {currentCampaign?.caption}
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {(currentCampaign?.hashtags || []).map((h, i) => (
                      <span key={i} className="text-[11px] font-semibold text-brand-accent bg-purple-50 px-2.5 py-1 rounded-xl">
                        {h}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Strategy Deployment Recommendation */}
                <div className="bg-purple-50/70 rounded-3xl p-6 border border-purple-200 space-y-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-brand-accent flex items-center gap-1.5 font-heading">
                    <Lightbulb className="w-4 h-4 text-brand-secondary fill-current" />
                    Strategic Deployment Directive
                  </span>
                  <p className="text-xs text-gray-800 leading-relaxed font-sans">
                    {currentCampaign?.strategy}
                  </p>
                </div>

              </div>

            </div>
          )}

          {/* TAB 2: M² MEME MARKETING SCORE */}
          {activeOutputTab === 'm2score' && (
            <M2ScoreCard campaign={currentCampaign} locked={!isPro} />
          )}

          {/* TAB 3: MEME RISK CHECK */}
          {activeOutputTab === 'risk' && (
            <RiskCheckCard campaign={currentCampaign} locked={!isPro} />
          )}

          {/* TAB 4: ROI LAB */}
          {activeOutputTab === 'roi' && (
            <RoiLabCard locked={!isPro} />
          )}

          {/* TAB 5: A/B TESTING LAB */}
          {activeOutputTab === 'abtest' && (
            <AbTestLabCard campaign={currentCampaign} locked={!isPro} />
          )}

        </div>
      )}

      {/* Campaign PDF Report Modal */}
      <CampaignReportModal
        campaign={currentCampaign}
        isOpen={reportModalOpen}
        onClose={() => setReportModalOpen(false)}
      />

    </div>
  );
}
