import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Sparkles, Check, CheckCircle2, X, ArrowRight, ShieldCheck, 
  HelpCircle, ChevronDown, Zap, BarChart3, Sliders, ShieldAlert, FileText 
} from 'lucide-react';

export default function PricingPage({ setActivePage }) {
  const { isPro, openCheckout } = useApp();
  const [billingCycle, setBillingCycle] = useState('monthly'); // 'monthly' | 'annual'

  const handleStartFree = () => {
    setActivePage('campaign-builder');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const featureMatrix = [
    {
      category: 'Education & Creative Generation',
      features: [
        { name: 'Brand Case Studies (6 Full Vault Breakdowns)', free: true, pro: true },
        { name: 'Meme Format Library & Structural Guides', free: true, pro: true },
        { name: '7-Step Campaign Builder Wizard', free: true, pro: true },
        { name: 'Basic Ad Copy & Concept Generation', free: true, pro: true },
        { name: 'Caption & Hashtag Suggestions', free: true, pro: true },
        { name: 'Multi-Platform Ad Social Feed Previews', free: true, pro: true },
      ]
    },
    {
      category: 'Strategic Evaluation & Financial Modeling',
      features: [
        { name: 'M² Meme Marketing Score (6 Dimensions)', free: false, pro: true },
        { name: 'Pre-flight Meme Risk Check & Brand Equity Audit', free: false, pro: true },
        { name: 'Interactive ROI Lab (Live Budget & Profit Simulator)', free: false, pro: true },
        { name: 'A/B Testing Simulator (Meme vs Traditional Benchmarks)', free: false, pro: true },
        { name: 'Strategic Campaign Insights & Actionable Directives', free: false, pro: true },
        { name: 'Saved Campaign History & Persistent Workspace', free: false, pro: true },
        { name: 'One-Click Downloadable & Printable PDF Strategy Reports', free: false, pro: true },
      ]
    }
  ];

  const faqs = [
    {
      q: 'Why separate Education & Creation from Evaluation & Strategy?',
      a: 'Anyone can use AI to write a joke. The real business bottleneck is knowing if the joke actually aligns with brand equity, avoids PR disaster, and has a mathematical probability of delivering positive ROI before spending budget.'
    },
    {
      q: 'How does the simulated checkout work?',
      a: 'MEMEVERTISING is currently in sandbox demo prototype mode. Clicking "Get Pro" opens a simulated checkout where you can test the entire Pro suite instantly with zero credit card entry.'
    },
    {
      q: 'Can I export reports for client presentations?',
      a: 'Yes! Pro members can print or export high-resolution, confidential PDF dossiers including the creative assets, M² Score, risk audit, and financial models.'
    },
    {
      q: 'What payment methods will be supported in production?',
      a: 'In production, we support UPI, Netbanking, Credit/Debit cards, and international payment methods via Razorpay and Stripe.'
    }
  ];

  return (
    <div className="space-y-20 sm:space-y-28 pb-20 pt-8 sm:pt-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold uppercase tracking-widest text-brand-accent bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
          Transparent Freemium Plans
        </span>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading text-brand-primary tracking-tight">
          Don't Guess on Virality.<br />
          <span className="text-brand-accent">Invest in Marketing Rigor.</span>
        </h1>
        <p className="text-base sm:text-lg text-gray-600 font-sans leading-relaxed">
          Create unlimited meme campaign concepts for free. Upgrade to unlock algorithmic scoring, context risk checks, and live financial simulations.
        </p>

        {/* Billing Switch */}
        <div className="pt-4 flex items-center justify-center gap-3">
          <span className={`text-xs font-bold ${billingCycle === 'monthly' ? 'text-brand-primary' : 'text-gray-400'}`}>
            Monthly
          </span>
          <button
            onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'annual' : 'monthly')}
            className="w-14 h-8 rounded-full bg-gray-200 p-1 transition-colors relative focus:outline-none"
            aria-label="Toggle billing cycle"
          >
            <div
              className={`w-6 h-6 rounded-full bg-brand-accent transition-transform shadow-sm ${
                billingCycle === 'annual' ? 'translate-x-6 bg-brand-secondary' : 'translate-x-0'
              }`}
            />
          </button>
          <div className="flex items-center gap-1.5">
            <span className={`text-xs font-bold ${billingCycle === 'annual' ? 'text-brand-primary' : 'text-gray-400'}`}>
              Annual
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-purple-100 text-brand-accent uppercase">
              Save 20%
            </span>
          </div>
        </div>
      </div>

      {/* Pricing Cards Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto items-stretch">
        
        {/* FREE PLAN */}
        <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-card border border-gray-200 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-2xl font-bold font-heading text-brand-primary">Free Explorer</h3>
                <p className="text-xs text-gray-500 mt-0.5">Education & Creation Suite</p>
              </div>
              <span className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-gray-100 text-gray-700">
                Forever Free
              </span>
            </div>

            <div className="mb-6">
              <span className="text-5xl font-black font-heading text-brand-primary">₹0</span>
              <span className="text-xs text-gray-400 ml-2">/ month</span>
            </div>

            <p className="text-xs text-gray-600 mb-6 font-sans leading-relaxed">
              Explore meme marketing theory, inspect brand case studies, and generate rapid campaign copy drafts.
            </p>

            <div className="space-y-3 text-sm text-gray-700 font-sans border-t pt-6">
              <div className="flex items-center gap-3">
                <Check className="w-4 h-4 text-brand-success flex-shrink-0" />
                <span>6 Brand Vault Case Studies</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-4 h-4 text-brand-success flex-shrink-0" />
                <span>8 Meme Format Directory with Templates</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-4 h-4 text-brand-success flex-shrink-0" />
                <span>7-Step Campaign Builder Wizard</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-4 h-4 text-brand-success flex-shrink-0" />
                <span>Basic Concept & Copywriting Generator</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-4 h-4 text-brand-success flex-shrink-0" />
                <span>Sponsored Feed Placement Preview</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <X className="w-4 h-4 text-gray-300 flex-shrink-0" />
                <span>M² Marketing Score Breakdown</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <X className="w-4 h-4 text-gray-300 flex-shrink-0" />
                <span>Pre-flight Meme Risk Audit</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <X className="w-4 h-4 text-gray-300 flex-shrink-0" />
                <span>Interactive Financial ROI Lab</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleStartFree}
            className="mt-8 w-full py-4 rounded-2xl border-2 border-brand-primary hover:bg-gray-100 text-brand-primary font-bold text-sm tracking-wide transition-colors"
          >
            Start Creating for Free
          </button>
        </div>

        {/* PRO PLAN */}
        <div className="bg-[#111111] text-white rounded-3xl p-8 sm:p-10 shadow-elevated border-2 border-brand-accent relative flex flex-col justify-between overflow-hidden">
          <div className="absolute right-0 top-0 w-64 h-64 bg-brand-accent/30 rounded-full blur-3xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-2xl font-bold font-heading text-white">MEMEVERTISING PRO</h3>
                  <Sparkles className="w-4 h-4 text-brand-secondary fill-current" />
                </div>
                <p className="text-xs text-purple-300 mt-0.5">Evaluation & Strategy Suite</p>
              </div>
              <span className="text-xs font-black uppercase tracking-wider px-3 py-1 rounded-full bg-brand-secondary text-brand-primary">
                {isPro ? 'YOUR CURRENT PLAN' : 'RECOMMENDED'}
              </span>
            </div>

            <div className="mb-6 flex items-baseline gap-2">
              <span className="text-5xl font-black font-heading text-brand-secondary">
                {billingCycle === 'monthly' ? '₹999' : '₹799'}
              </span>
              <span className="text-xs text-gray-400">
                / month {billingCycle === 'annual' ? '(billed annually)' : ''}
              </span>
            </div>

            <p className="text-xs text-gray-300 mb-6 font-sans leading-relaxed">
              For marketing teams, agencies, and founders who need to ensure memes translate into measurable revenue before launching.
            </p>

            <div className="space-y-3 text-sm text-gray-200 font-sans border-t border-gray-800 pt-6">
              <div className="flex items-center gap-3">
                <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                <span><strong>Everything in Free Explorer</strong></span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                <span><strong>M² Meme Marketing Score</strong> (6 Dimensions)</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                <span><strong>Meme Risk Check</strong> (Brand Fit, Context & Fatigue)</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                <span><strong>Interactive ROI Lab</strong> (Live Budget & Profit Simulator)</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                <span><strong>A/B Testing Simulator</strong> (Traditional vs Meme Ads)</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                <span><strong>Saved Campaigns Workspace</strong> (Multi-campaign storage)</span>
              </div>
              <div className="flex items-center gap-3">
                <Check className="w-4 h-4 text-brand-secondary flex-shrink-0" />
                <span><strong>Downloadable PDF Strategy Reports</strong> with 1-Click Print</span>
              </div>
            </div>
          </div>

          <button
            onClick={openCheckout}
            className="mt-8 w-full py-4 rounded-2xl bg-brand-accent hover:bg-brand-accentHover text-white font-bold text-sm tracking-wider uppercase shadow-glow-accent hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-brand-secondary" />
            {isPro ? 'Pro Active (Extend or Manage)' : 'Get Pro — Unlock Full Suite'}
          </button>
        </div>

      </div>

      {/* Feature Deep Dive Matrix */}
      <section className="bg-white rounded-4xl p-6 sm:p-12 shadow-card border border-gray-200 space-y-8 max-w-5xl mx-auto">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold font-heading text-brand-primary">
            Detailed Feature Matrix
          </h2>
          <p className="text-xs sm:text-sm text-gray-500 font-sans">
            Explicit separation of educational creation vs strategic audit capabilities.
          </p>
        </div>

        <div className="space-y-6">
          {featureMatrix.map((cat, idx) => (
            <div key={idx} className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-brand-accent font-heading border-b pb-2">
                {cat.category}
              </h4>
              <div className="space-y-2">
                {cat.features.map((feat, fIdx) => (
                  <div key={fIdx} className="flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 text-xs sm:text-sm">
                    <span className="text-gray-800 font-medium">{feat.name}</span>
                    <div className="flex items-center gap-8 font-mono">
                      <span className="w-16 text-center">
                        {feat.free ? (
                          <Check className="w-4 h-4 text-brand-success mx-auto" />
                        ) : (
                          <span className="text-gray-300">—</span>
                        )}
                      </span>
                      <span className="w-16 text-center">
                        <Check className="w-4 h-4 text-brand-accent mx-auto font-bold" />
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ Section */}
      <section className="max-w-3xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-primary bg-gray-100 px-3 py-1 rounded-full">
            Frequently Asked Questions
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-heading text-brand-primary">
            Answers for Growth Marketers
          </h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, idx) => (
            <div key={idx} className="p-6 rounded-3xl bg-white shadow-card border border-gray-200 space-y-2">
              <h4 className="text-base font-bold font-heading text-brand-primary flex items-start gap-2">
                <HelpCircle className="w-4 h-4 text-brand-accent flex-shrink-0 mt-1" />
                {faq.q}
              </h4>
              <p className="text-xs sm:text-sm text-gray-600 font-sans leading-relaxed pl-6">
                {faq.a}
              </p>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
