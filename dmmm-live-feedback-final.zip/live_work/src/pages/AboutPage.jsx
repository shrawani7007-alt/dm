import React from 'react';
import { 
  Sparkles, ArrowRight, Target, ShieldCheck, Zap, Compass, 
  CheckCircle2, Layers, Heart, TrendingUp, Lightbulb 
} from 'lucide-react';

export default function AboutPage({ setActivePage }) {
  const frameworkSteps = [
    {
      num: '01',
      title: 'EXPLORE',
      summary: 'Analyze cultural artifacts and decode meme mechanics.',
      desc: 'Understand why specific visual formats, punchlines, and vernacular thrive in subcultures. We dissect historical case studies so you never deploy an obsolete trend.'
    },
    {
      num: '02',
      title: 'STRATEGIZE',
      summary: 'Anchor the campaign in business objectives and audience friction.',
      desc: 'Meme marketing fails when it lacks clear intent. We define the specific consumer tension (e.g. 8 AM morning fatigue, tax dread) that your product genuinely solves.'
    },
    {
      num: '03',
      title: 'CREATE',
      summary: 'Synthesize the punchline directly into the product proposition.',
      desc: 'Generate headlines, copy, captions, and visual angles where the product is the necessary hero resolution, not a tagged-on sponsor after the joke is already over.'
    },
    {
      num: '04',
      title: 'EVALUATE',
      summary: 'Audit marketing viability, brand risk, and audience misinterpretation.',
      desc: 'Run the M² Meme Marketing Score and Pre-Flight Risk Audit. Is the joke clear? Does it damage brand equity? Will people remember the meme but forget the product?'
    },
    {
      num: '05',
      title: 'OPTIMIZE',
      summary: 'Simulate financial ROI and benchmark against traditional advertising.',
      desc: 'Model expected CTR, conversion velocity, and return on ad spend. Test meme creative variants against control banners before putting paid capital on the line.'
    }
  ];

  return (
    <div className="space-y-20 sm:space-y-28 pb-20 pt-8 sm:pt-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold uppercase tracking-widest text-brand-accent bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
          Product Philosophy
        </span>
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black font-heading text-brand-primary tracking-tight">
          About MEMEVERTISING
        </h1>
        <p className="text-base sm:text-lg text-gray-600 font-sans leading-relaxed">
          Bringing advertising rigor, brand safety, and financial accountability to internet humor.
        </p>
      </div>

      {/* CORE DIFFERENTIATOR BANNER (Prominently featured as required) */}
      <section className="bg-gradient-to-br from-[#111111] via-[#1a1226] to-[#7C3AED] rounded-4xl p-8 sm:p-14 text-white shadow-elevated relative overflow-hidden text-center">
        <div className="max-w-3xl mx-auto space-y-6 relative z-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-brand-secondary text-brand-primary text-xs font-bold uppercase tracking-wider shadow-glow-yellow">
            <Sparkles className="w-3.5 h-3.5 fill-current" />
            CORE PLATFORM DIFFERENTIATOR
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black font-heading leading-tight tracking-tight text-white">
            "AI can generate a meme.<br />
            <span className="text-brand-secondary">
              MEMEVERTISING asks whether that meme makes marketing sense."
            </span>
          </h2>

          <p className="text-sm sm:text-base text-gray-300 font-sans max-w-2xl mx-auto leading-relaxed">
            Generative AI has commoditized jokes. Anyone can prompt a model to produce 100 funny puns in 10 seconds. But views do not pay salaries. MEMEVERTISING exists to evaluate brand fit, context risk, message clarity, and downstream conversion.
          </p>
        </div>
      </section>

      {/* MISSION SECTION */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
        <div className="space-y-5">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-accent font-mono">
            Our Mission
          </span>
          <h2 className="text-3xl sm:text-4xl font-black font-heading text-brand-primary leading-tight">
            Stop Subsidizing Someone Else’s Entertainment
          </h2>
          <p className="text-sm sm:text-base text-gray-600 font-sans leading-relaxed">
            The modern internet feed is cluttered with brand accounts desperate for validation. They participate in trending audio, copy viral tweets, and celebrate when a post reaches 1 million impressions—only to realize later that customer acquisition did not budge.
          </p>
          <p className="text-sm sm:text-base text-gray-600 font-sans leading-relaxed">
            Our mission is to help marketers transition from <em>fleeting novelty</em> to <em>repeatable strategy</em>. We believe humor is the single most powerful attention catalyst in digital commerce—when anchored to product truth.
          </p>

          <div className="pt-2 flex flex-wrap gap-4">
            <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
              <CheckCircle2 className="w-4 h-4 text-brand-success" />
              <span>Zero Vanity Fluff</span>
            </div>
            <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
              <CheckCircle2 className="w-4 h-4 text-brand-success" />
              <span>Algorithmic Pre-Flight Auditing</span>
            </div>
            <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
              <CheckCircle2 className="w-4 h-4 text-brand-success" />
              <span>Measurable ROI Modeling</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-card border border-gray-200 space-y-6">
          <h3 className="text-xl font-bold font-heading text-brand-primary">
            The Three Fatal Traps of Meme Marketing
          </h3>
          <div className="space-y-4 text-xs sm:text-sm text-gray-600 font-sans">
            <div className="p-4 rounded-2xl bg-red-50/60 border border-red-100 space-y-1">
              <span className="font-bold text-brand-danger">1. The Ghost Product Trap:</span>
              <p>The meme is hilarious, but if you swap out your logo for 20 competitors, the joke remains unchanged. Zero distinct brand memory was created.</p>
            </div>
            <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-100 space-y-1">
              <span className="font-bold text-brand-warning">2. The Dead Trend Trap:</span>
              <p>Corporate legal and approval cycles take 3 weeks to greenlight an ad based on a meme that peaked 14 days ago. Result: cringe instead of connection.</p>
            </div>
            <div className="p-4 rounded-2xl bg-purple-50/60 border border-purple-100 space-y-1">
              <span className="font-bold text-brand-accent">3. The Context Blindness Trap:</span>
              <p>Adopting an edgy template without realizing its subcultural origins carry polarizing connotations that trigger customer backlash.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 5-STAGE FRAMEWORK BREAKDOWN */}
      <section className="space-y-10">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-accent bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
            The Strategic Sequence
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-heading text-brand-primary">
            The 5-Stage Methodology
          </h2>
          <p className="text-xs sm:text-sm text-gray-600 font-sans">
            Explore → Strategize → Create → Evaluate → Optimize
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {frameworkSteps.map((step, idx) => (
            <div 
              key={idx}
              className="bg-white rounded-3xl p-8 shadow-card border border-gray-200 hover:shadow-card-hover hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-3xl font-black font-mono text-gray-300">
                    {step.num}
                  </span>
                  <span className="text-xs font-bold uppercase tracking-wider text-brand-accent bg-purple-50 px-2.5 py-0.5 rounded-full">
                    Stage {step.num}
                  </span>
                </div>
                <h3 className="text-xl font-black font-heading text-brand-primary mb-2">
                  {step.title}
                </h3>
                <p className="text-xs font-bold text-gray-800 mb-3 font-sans">
                  {step.summary}
                </p>
                <p className="text-xs text-gray-500 leading-relaxed font-sans">
                  {step.desc}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-gray-100 flex items-center justify-between text-xs text-brand-accent font-semibold">
                <span>Integrated Tooling</span>
                <span>Active in Platform →</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Bottom CTA Banner */}
      <div className="p-8 sm:p-12 rounded-4xl bg-brand-primary text-white text-center space-y-5 shadow-elevated">
        <h3 className="text-2xl sm:text-3xl font-black font-heading">
          Ready to Make Your Meme Marketable?
        </h3>
        <p className="text-xs sm:text-sm text-gray-400 font-sans max-w-lg mx-auto">
          Start building your campaign in our 7-step wizard and evaluate its true business viability before spending a rupee.
        </p>
        <button
          onClick={() => {
            setActivePage('campaign-builder');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="py-4 px-8 rounded-2xl bg-brand-accent hover:bg-brand-accentHover text-white font-bold text-xs uppercase tracking-wider shadow-glow-accent hover:scale-105 transition-all inline-flex items-center gap-2"
        >
          <span>Launch Campaign Builder</span>
          <ArrowRight className="w-4 h-4 text-brand-secondary" />
        </button>
      </div>

    </div>
  );
}
