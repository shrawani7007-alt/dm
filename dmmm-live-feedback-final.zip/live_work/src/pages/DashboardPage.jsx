import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import M2ScoreCard from '../components/M2ScoreCard';
import RiskCheckCard from '../components/RiskCheckCard';
import RoiLabCard from '../components/RoiLabCard';
import AbTestLabCard from '../components/AbTestLabCard';
import CampaignReportModal from '../components/CampaignReportModal';
import FeedbackDashboard from '../components/FeedbackDashboard';
import { 
  Sparkles, Crown, PlusCircle, Library, BookOpen, BarChart3, 
  Trash2, ExternalLink, Sliders, ShieldAlert, Zap, Clock, CheckCircle2, 
  ArrowRight, FileText, Lock, UserCheck 
} from 'lucide-react';

export default function DashboardPage({ setActivePage }) {
  const { 
    user, isPro, savedCampaigns, deleteCampaign, setCurrentCampaign, 
    setWizardDraft, openCheckout, openProPaywall, addToast 
  } = useApp();

  const [activeProTab, setActiveProTab] = useState('m2score'); // 'm2score' | 'risk' | 'roi' | 'abtest'
  const [selectedCampaignForReport, setSelectedCampaignForReport] = useState(null);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [activeDashboardSection, setActiveDashboardSection] = useState('overview');

  // If user is not logged in, provide a handsome guest workspace demo state
  const userName = user?.name || 'Alex Rivera (Demo Marketer)';
  const userEmail = user?.email || 'alex.rivera@growthmarketing.io';

  const handleOpenCampaign = (campaign) => {
    setCurrentCampaign(campaign);
    setWizardDraft({
      product: campaign.product,
      objective: campaign.objective,
      audience: campaign.audience,
      personality: campaign.personality,
      platform: campaign.platform,
      format: campaign.format,
      step: 7
    });
    setActivePage('campaign-builder');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    addToast(`Opened "${campaign.product}" in Campaign Builder.`, 'info');
  };

  const handleViewReport = (campaign) => {
    setSelectedCampaignForReport(campaign);
    setReportModalOpen(true);
  };

  return (
    <div className="space-y-12 pb-24 pt-6 sm:pt-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* DASHBOARD SECTION SWITCHER */}
      <section className="bg-white rounded-3xl p-2 shadow-card border border-gray-200 flex flex-col sm:flex-row gap-2">
        <button
          onClick={() => setActiveDashboardSection('overview')}
          className={`flex-1 py-3 px-5 rounded-2xl text-sm font-black transition-all ${activeDashboardSection === 'overview' ? 'bg-brand-primary text-white shadow-sm' : 'text-gray-600 hover:bg-gray-50'}`}
        >
          Campaign Dashboard
        </button>
        <button
          onClick={() => setActiveDashboardSection('feedback')}
          className={`flex-1 py-3 px-5 rounded-2xl text-sm font-black transition-all ${activeDashboardSection === 'feedback' ? 'bg-brand-accent text-white shadow-sm' : 'text-gray-600 hover:bg-gray-50'}`}
        >
          Feedback & Analysis
        </button>
      </section>

      {activeDashboardSection === 'feedback' ? (
        <FeedbackDashboard />
      ) : (
        <>
      {/* Top User Profile Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-card border border-gray-200 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-brand-primary text-white flex items-center justify-center font-bold font-heading text-2xl shadow-sm">
            {userName.charAt(0).toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl sm:text-3xl font-black font-heading text-brand-primary">
                {userName}
              </h1>
              {isPro ? (
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-gradient-to-r from-purple-900 to-brand-primary text-white text-xs font-bold shadow-sm border border-purple-300/40">
                  <Crown className="w-3.5 h-3.5 text-brand-secondary fill-current" />
                  PRO STRATEGY ACCOUNT
                </span>
              ) : (
                <span className="px-3 py-1 rounded-full bg-gray-100 text-gray-700 text-xs font-bold">
                  FREE EXPLORER TIER
                </span>
              )}
            </div>
            <p className="text-xs text-gray-500 font-sans mt-0.5">
              {userEmail} • Verified Marketing Workspace
            </p>
          </div>
        </div>

        {/* Upgrade / Account Action */}
        <div>
          {isPro ? (
            <div className="p-3 rounded-2xl bg-purple-50 border border-purple-100 text-xs text-purple-900 font-medium flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-brand-accent flex-shrink-0" />
              <span>Full Analytics & Report Exports Active</span>
            </div>
          ) : (
            <button
              onClick={openCheckout}
              className="py-3 px-6 rounded-2xl bg-brand-secondary hover:bg-brand-secondaryHover text-brand-primary font-black text-xs uppercase tracking-wider shadow-sm flex items-center gap-2 transition-all hover:scale-105"
            >
              <Sparkles className="w-4 h-4" />
              Upgrade to Pro (₹999/mo)
            </button>
          )}
        </div>
      </div>

      {/* QUICK ACTIONS */}
      <section className="space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 font-heading">
          Quick Workflow Actions
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <button
            onClick={() => {
              setActivePage('campaign-builder');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="p-5 rounded-2xl bg-brand-primary hover:bg-brand-accent text-white shadow-sm transition-all text-left group"
          >
            <PlusCircle className="w-6 h-6 text-brand-secondary mb-3 group-hover:scale-110 transition-transform" />
            <h4 className="text-sm font-bold font-heading">Create Campaign</h4>
            <p className="text-xs text-gray-300 mt-0.5">Build new meme ad draft</p>
          </button>

          <button
            onClick={() => {
              setActivePage('meme-library');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="p-5 rounded-2xl bg-white hover:bg-purple-50/50 border border-gray-200 text-gray-900 shadow-sm transition-all text-left group"
          >
            <Library className="w-6 h-6 text-brand-accent mb-3 group-hover:scale-110 transition-transform" />
            <h4 className="text-sm font-bold font-heading">Explore Meme Library</h4>
            <p className="text-xs text-gray-500 mt-0.5">8 proven formats & specs</p>
          </button>

          <button
            onClick={() => {
              setActivePage('brand-vault');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="p-5 rounded-2xl bg-white hover:bg-purple-50/50 border border-gray-200 text-gray-900 shadow-sm transition-all text-left group"
          >
            <BookOpen className="w-6 h-6 text-amber-500 mb-3 group-hover:scale-110 transition-transform" />
            <h4 className="text-sm font-bold font-heading">Brand Vault</h4>
            <p className="text-xs text-gray-500 mt-0.5">Case studies & tactics</p>
          </button>

          <button
            onClick={() => {
              if (!isPro) {
                openProPaywall();
              } else {
                setActivePage('campaign-builder');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }
            }}
            className="p-5 rounded-2xl bg-white hover:bg-purple-50/50 border border-gray-200 text-gray-900 shadow-sm transition-all text-left group"
          >
            <BarChart3 className="w-6 h-6 text-emerald-500 mb-3 group-hover:scale-110 transition-transform" />
            <h4 className="text-sm font-bold font-heading flex items-center justify-between">
              <span>Evaluate Campaign</span>
              {!isPro && <Lock className="w-3.5 h-3.5 text-gray-400" />}
            </h4>
            <p className="text-xs text-gray-500 mt-0.5">Audit viability & risk</p>
          </button>
        </div>
      </section>

      {/* SAVED & DRAFT CAMPAIGNS */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold font-heading text-brand-primary">
              Saved & Active Campaigns
            </h3>
            <p className="text-xs text-gray-500">
              Persisted locally in your workspace browser session
            </p>
          </div>
          <span className="text-xs font-mono font-bold text-gray-400">
            {savedCampaigns.length} campaigns saved
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {savedCampaigns.map((camp) => (
            <div
              key={camp.id}
              className="bg-white rounded-3xl p-6 shadow-card border border-gray-200 hover:shadow-card-hover transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-purple-50 text-brand-accent">
                    {camp.format} • {camp.platform}
                  </span>
                  <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                    camp.status === 'Ready' 
                      ? 'bg-emerald-100 text-emerald-800' 
                      : 'bg-amber-100 text-amber-800'
                  }`}>
                    {camp.status || 'Draft'}
                  </span>
                </div>

                <h4 className="text-lg font-bold font-heading text-brand-primary mb-1">
                  {camp.product}
                </h4>

                <p className="text-xs text-gray-600 font-sans line-clamp-2 italic mb-3">
                  "{camp.concept || camp.headline}"
                </p>

                <div className="text-[11px] text-gray-500 space-y-1 py-2.5 border-t border-gray-100">
                  <div className="flex justify-between">
                    <span>Audience:</span>
                    <strong className="text-gray-800">{camp.audience}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>M² Score:</span>
                    <strong className="text-brand-accent">{camp.m2Score?.overall || 8.2} / 10</strong>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="pt-4 border-t border-gray-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => handleOpenCampaign(camp)}
                  className="flex-1 py-2 px-3 rounded-xl bg-brand-primary hover:bg-brand-accent text-white text-xs font-bold transition-colors flex items-center justify-center gap-1"
                >
                  <span>Open / Edit</span>
                  <ArrowRight className="w-3 h-3 text-brand-secondary" />
                </button>

                <button
                  onClick={() => handleViewReport(camp)}
                  className="p-2 rounded-xl border border-gray-200 hover:bg-gray-50 text-gray-700"
                  title="View PDF Report"
                  aria-label="View PDF Report"
                >
                  <FileText className="w-4 h-4" />
                </button>

                <button
                  onClick={() => deleteCampaign(camp.id)}
                  className="p-2 rounded-xl border border-gray-200 hover:bg-red-50 text-gray-400 hover:text-brand-danger transition-colors"
                  title="Delete Campaign"
                  aria-label="Delete Campaign"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* PRO EVALUATION & ANALYTICS PREVIEW SECTION */}
      <section className="space-y-6 pt-4 border-t border-gray-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-md bg-brand-secondary text-brand-primary">
                <Sparkles className="w-4 h-4 fill-current" />
              </span>
              <h3 className="text-xl font-bold font-heading text-brand-primary">
                Strategic Intelligence Tools
              </h3>
            </div>
            <p className="text-xs text-gray-500 mt-0.5">
              {isPro ? 'Live Pro Analytics Workspace' : 'Previewing Locked Pro Suite'}
            </p>
          </div>

          {/* Tool Tab Switcher */}
          <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-gray-100 text-xs font-bold overflow-x-auto">
            <button
              onClick={() => setActiveProTab('m2score')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                activeProTab === 'm2score' ? 'bg-white text-brand-primary shadow-xs' : 'text-gray-600 hover:text-black'
              }`}
            >
              M² Score
            </button>
            <button
              onClick={() => setActiveProTab('risk')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                activeProTab === 'risk' ? 'bg-white text-brand-primary shadow-xs' : 'text-gray-600 hover:text-black'
              }`}
            >
              Risk Check
            </button>
            <button
              onClick={() => setActiveProTab('roi')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                activeProTab === 'roi' ? 'bg-white text-brand-primary shadow-xs' : 'text-gray-600 hover:text-black'
              }`}
            >
              ROI Lab
            </button>
            <button
              onClick={() => setActiveProTab('abtest')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                activeProTab === 'abtest' ? 'bg-white text-brand-primary shadow-xs' : 'text-gray-600 hover:text-black'
              }`}
            >
              A/B Testing
            </button>
          </div>
        </div>

        {/* Pro Component Panels */}
        <div>
          {activeProTab === 'm2score' && (
            <M2ScoreCard campaign={savedCampaigns[0]} locked={!isPro} />
          )}
          {activeProTab === 'risk' && (
            <RiskCheckCard campaign={savedCampaigns[0]} locked={!isPro} />
          )}
          {activeProTab === 'roi' && (
            <RoiLabCard locked={!isPro} />
          )}
          {activeProTab === 'abtest' && (
            <AbTestLabCard campaign={savedCampaigns[0]} locked={!isPro} />
          )}
        </div>
      </section>

        </>
      )}

      {/* PDF Report Modal */}
      {selectedCampaignForReport && (
        <CampaignReportModal
          campaign={selectedCampaignForReport}
          isOpen={reportModalOpen}
          onClose={() => {
            setReportModalOpen(false);
            setSelectedCampaignForReport(null);
          }}
        />
      )}

    </div>
  );
}
