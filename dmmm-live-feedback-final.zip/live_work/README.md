# DMMM — Meme Marketing

React + Vite project for VS Code.

## Run in VS Code

1. Install **Node.js 20.19+** (Node 22 LTS is also suitable).
2. Open this folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Run:

```bash
npm install
npm run dev
```

5. Open the local URL printed by Vite, usually `http://localhost:5173`.

## Production build

```bash
npm run build
npm run preview
```

### Important

`node_modules` is intentionally not included in this project archive. Dependencies contain platform-specific native binaries, so they must be installed on the computer where the project will run. This avoids the `Cannot find native binding` / `vite: Permission denied` errors caused by copying `node_modules` between systems.


## Engagement data

The social cards use an **AI-generated engagement simulation** so the demo has realistic-looking historical/current timestamps, comments, likes, views, and shares without pretending to pull data from real users or social platforms. Likes, comments, views, and shares are kept at a minimum of 20. New user interactions are stored locally in the browser.

## Publish with GitHub Pages

1. Create a new repository on GitHub.
2. Upload/push this project to the repository's `main` branch.
3. GitHub Actions will run the included `.github/workflows/deploy.yml`.
4. In GitHub, open **Settings → Pages** and set **Source** to **GitHub Actions** if GitHub asks for a source.
5. After the workflow finishes, GitHub will show your public site URL under **Settings → Pages**.

The Vite configuration already uses relative asset paths, so the same build works from a GitHub Pages repository URL.
