/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          bg: '#F8F9FA',
          primary: '#111111',
          accent: '#7C3AED',
          accentHover: '#6D28D9',
          accentLight: '#EDE9FE',
          secondary: '#FACC15',
          secondaryHover: '#EAB308',
          secondaryLight: '#FEF9C3',
          success: '#22C55E',
          warning: '#F97316',
          danger: '#EF4444',
          surface: '#FFFFFF',
          card: '#FFFFFF',
          border: '#E5E7EB',
          subtle: '#6B7280',
          darkMuted: '#1F2937',
        }
      },
      fontFamily: {
        heading: ['"Space Grotesk"', 'Poppins', 'sans-serif'],
        sans: ['Inter', 'sans-serif'],
      },
      borderRadius: {
        '2xl': '16px',
        '3xl': '24px',
        '4xl': '32px',
      },
      boxShadow: {
        'card': '0 4px 20px -2px rgba(0, 0, 0, 0.05), 0 2px 6px -1px rgba(0, 0, 0, 0.02)',
        'card-hover': '0 12px 30px -4px rgba(124, 58, 237, 0.12), 0 4px 12px -2px rgba(0, 0, 0, 0.05)',
        'elevated': '0 20px 40px -10px rgba(0, 0, 0, 0.12)',
        'glow-accent': '0 0 25px rgba(124, 58, 237, 0.35)',
        'glow-yellow': '0 0 25px rgba(250, 204, 21, 0.4)',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards',
        'slide-up': 'slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards',
        'pulse-subtle': 'pulseSubtle 2.5s infinite ease-in-out',
        'float': 'float 3s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(16px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        pulseSubtle: {
          '0%, 100%': { opacity: '1', transform: 'scale(1)' },
          '50%': { opacity: '0.92', transform: 'scale(1.02)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-6px)' },
        },
      }
    },
  },
  plugins: [],
}
