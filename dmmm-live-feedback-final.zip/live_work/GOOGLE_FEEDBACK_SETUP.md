# DMMM Feedback: Google Sheets + Gmail setup

The feedback system is designed to work like a lightweight Google Form while keeping the UI inside DMMM.

## What it does

- Saves every submission to a Google Sheet.
- Sends an email to `sleepinghippo777@gmail.com` after every submission.
- Each email includes the new response and total analysis so far.
- The Dashboard can load the full response set from the Google Sheet.
- If the Google endpoint is not configured, the site falls back to browser-local storage.

## 1. Create the response spreadsheet

1. Open Google Sheets.
2. Create a blank spreadsheet, e.g. `DMMM Feedback Responses`.
3. Open **Extensions → Apps Script**.
4. Delete the starter code.
5. Copy everything from `google-apps-script/Code.gs` in this project into Apps Script.
6. Click **Save**.

## 2. Deploy the Apps Script

1. In Apps Script click **Deploy → New deployment**.
2. Select **Web app** as the deployment type.
3. Set **Execute as**: Me.
4. Set **Who has access**: Anyone.
5. Click **Deploy**.
6. Approve Google's authorization prompts.
7. Copy the Web app URL ending in `/exec`.

The script sends notification mail to `sleepinghippo777@gmail.com` using the Google account that owns/executes the Apps Script. You do not put a Gmail password or API key in the website.

## 3. Connect the website

Open:

`src/utils/feedbackConfig.js`

Change:

```js
export const FEEDBACK_WEB_APP_URL = '';
```

to:

```js
export const FEEDBACK_WEB_APP_URL = 'YOUR_APPS_SCRIPT_WEB_APP_URL';
```

Keep:

```js
export const FEEDBACK_OWNER_EMAIL = 'sleepinghippo777@gmail.com';
```

Then run:

```powershell
npm.cmd install
npm.cmd run dev
```

## 4. Test

Submit one response from the website.

You should see:

1. A new row in Google Sheets.
2. An email at `sleepinghippo777@gmail.com`.
3. The email contains the response plus total Yes/Maybe/No analysis.
4. Dashboard → Feedback Center → Refresh loads the cloud responses.

## Important

Google may show an authorization warning when you first deploy a personal Apps Script. Review the permissions and continue if you trust the script. Never put a Gmail password, SMTP password, or private API credential in React/Vite frontend code.
