const FEEDBACK_SHEET = 'Responses';
const VISITS_SHEET = 'Visits';
const OWNER_EMAIL = 'sleepinghippo777@gmail.com';

function getSheet_(name, headers) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  if (sheet.getLastRow() === 0) { sheet.appendRow(headers); sheet.setFrozenRows(1); }
  return sheet;
}

function getFeedbackSheet_() { return getSheet_(FEEDBACK_SHEET, ['ID','Created At','Campaign','Respondent Email','Purchase Interest','Memorability','Brand Fit']); }
function getVisitsSheet_() { return getSheet_(VISITS_SHEET, ['ID','Created At','Visitor ID','Session ID','Page','Referrer']); }

function doGet(e) {
  const mode = e?.parameter?.mode || '';
  let data;
  if (mode === 'responses') data = { responses: getResponses_() };
  else if (mode === 'visits') data = { visits: getVisits_() };
  else data = { ok: true, message: 'DMMM live analytics endpoint is running.' };
  return jsonp_(data, e?.parameter?.callback);
}

function doPost(e) {
  const p = e?.parameter || {};
  if (p.mode === 'visit') {
    recordVisit_(p);
    return ContentService.createTextOutput('VISIT_OK');
  }
  recordFeedback_(p);
  return ContentService.createTextOutput('FEEDBACK_OK');
}

function recordFeedback_(p) {
  const sheet = getFeedbackSheet_();
  const id = Utilities.getUuid();
  const createdAt = p.createdAt || new Date().toISOString();
  sheet.appendRow([id, createdAt, p.campaign || 'Featured Meme Campaign', p.respondentEmail || '', p.purchaseInterest || '', p.memorability || '', p.brandFit || '']);
  sendNotification_(p, calculateAnalysis_(sheet));
}

function recordVisit_(p) {
  const sheet = getVisitsSheet_();
  sheet.appendRow([Utilities.getUuid(), p.createdAt || new Date().toISOString(), p.visitorId || '', p.sessionId || '', p.page || '#home', p.referrer || '']);
}

function getResponses_() {
  const sheet = getFeedbackSheet_();
  const values = sheet.getDataRange().getValues();
  if (values.length <= 1) return [];
  return values.slice(1).reverse().map(r => ({
    id: String(r[0]), createdAt: toIso_(r[1]), campaign: String(r[2] || ''), respondentEmail: String(r[3] || ''),
    purchaseInterest: String(r[4] || ''), memorability: String(r[5] || ''), brandFit: String(r[6] || '')
  }));
}

function getVisits_() {
  const sheet = getVisitsSheet_();
  const values = sheet.getDataRange().getValues();
  if (values.length <= 1) return [];
  return values.slice(1).reverse().map(r => ({ id: String(r[0]), createdAt: toIso_(r[1]), visitorId: String(r[2] || ''), sessionId: String(r[3] || ''), page: String(r[4] || ''), referrer: String(r[5] || '') }));
}

function toIso_(value) { return value instanceof Date ? value.toISOString() : String(value || ''); }

function calculateAnalysis_(sheet) {
  const rows = sheet.getDataRange().getValues().slice(1);
  const countValue = (index, value) => rows.filter(r => String(r[index]) === value).length;
  const total = rows.length, yes = countValue(4,'Yes'), maybe = countValue(4,'Maybe'), no = countValue(4,'No');
  return { total, yes, maybe, no, yesPct: total ? Math.round(yes / total * 100) : 0 };
}

function sendNotification_(response, analysis) {
  const subject = `DMMM feedback received — ${analysis.total} total response${analysis.total === 1 ? '' : 's'}`;
  const respondent = response.respondentEmail ? escapeHtml_(response.respondentEmail) : 'Not provided';
  const html = `<div style="font-family:Arial,sans-serif;max-width:680px;margin:auto;color:#111"><div style="background:#151515;color:white;padding:28px"><div style="font-size:11px;letter-spacing:2px;color:#d7ff5f;font-weight:bold">MEMEVERTISING</div><h1 style="margin:8px 0 0">New feedback received</h1></div><div style="padding:28px;border:1px solid #eee"><h2>Response</h2><p><b>Campaign:</b> ${escapeHtml_(response.campaign || 'Featured Meme Campaign')}</p><p><b>Respondent email:</b> ${respondent}</p><p><b>Purchase interest:</b> ${escapeHtml_(response.purchaseInterest)}</p><p><b>Memorability:</b> ${escapeHtml_(response.memorability)}</p><p><b>Brand fit:</b> ${escapeHtml_(response.brandFit)}</p><hr><h2>Total analysis</h2><table cellpadding="10" style="border-collapse:collapse;width:100%;background:#f7f7f7"><tr><td><b>Total responses</b></td><td>${analysis.total}</td></tr><tr><td><b>Purchase: Yes</b></td><td>${analysis.yes} (${analysis.yesPct}%)</td></tr><tr><td><b>Purchase: Maybe</b></td><td>${analysis.maybe}</td></tr><tr><td><b>Purchase: No</b></td><td>${analysis.no}</td></tr></table><p style="color:#777;font-size:12px">Automatic DMMM notification.</p></div></div>`;
  MailApp.sendEmail({ to: OWNER_EMAIL, subject, htmlBody: html, body: `New DMMM feedback. Total: ${analysis.total}. Yes: ${analysis.yes} (${analysis.yesPct}%), Maybe: ${analysis.maybe}, No: ${analysis.no}.` });
}

function jsonp_(data, callback) {
  const safe = String(callback || '').replace(/[^a-zA-Z0-9_$.]/g, '');
  const json = JSON.stringify(data);
  if (!safe) return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
  return ContentService.createTextOutput(`${safe}(${json})`).setMimeType(ContentService.MimeType.JAVASCRIPT);
}

function escapeHtml_(value) { return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
