# DMMM Live Feedback + Visitor Tracking

This version stores feedback and anonymous website-view events in Google Sheets and sends an email to `sleepinghippo777@gmail.com` whenever a feedback form is submitted.

## 1. Create the Google Sheet

Create a blank Google Sheet. Open **Extensions → Apps Script** and replace the script with `google-apps-script/Code.gs` from this project.

## 2. Deploy the Apps Script

In Apps Script:

1. Save the project.
2. Run `doGet` once if Google asks you to authorize the project.
3. Click **Deploy → New deployment**.
4. Select **Web app**.
5. Execute as: **Me**.
6. Who has access: **Anyone**.
7. Deploy and authorize the requested permissions.
8. Copy the Web app URL ending in `/exec`.

The script creates two sheets automatically:
- `Responses` — feedback submissions.
- `Visits` — anonymous website-view events.

Every feedback submission sends an email to `sleepinghippo777@gmail.com` containing the individual response and the current aggregate analysis.

## 3. Connect the website

Open:

`src/utils/feedbackConfig.js`

Set:

```js
export const FEEDBACK_WEB_APP_URL = 'PASTE_YOUR_WEB_APP_EXEC_URL_HERE';
```

Do not put a Gmail password, API key, or private Google credential in the React app.

## 4. Run locally

```powershell
npm.cmd install
npm.cmd run dev
```

## 5. Deploy to GitHub Pages

The existing GitHub Actions workflow builds the Vite app. Commit and push the project after adding the Apps Script URL.

## What is tracked

Visitor tracking is intentionally anonymous: the site stores a random visitor ID, session ID, timestamp, page, and referrer. It does **not** identify a person by name. If a visitor voluntarily enters an email in the feedback form, that email is stored with that feedback and is included in the notification.

The dashboard polls the cloud data every 10 seconds, so new feedback and visitor records appear without manually reloading the page.
